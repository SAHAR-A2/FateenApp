"""Firebase ID token verification for the FATEEN backend.

STATUS: WIRED IN, BUT REQUIRES A CREDENTIAL TO ACTUALLY VERIFY ANYTHING.
`Depends(require_authenticated_user)` IS attached to
POST /api/v1/products/barcode/{barcode}/compatibility and
POST /api/v1/products/barcode/{barcode}/alternatives in
app/api/products.py, and `firebase-admin` IS in requirements.txt/installed.
So the *code path* is live. What is still missing is deployment
configuration:

  - `_get_firebase_app()` only reads the credential from
    `GOOGLE_APPLICATION_CREDENTIALS` (a path to a Firebase service-account
    JSON file). There is no other supported env var -- do not reference
    `FIREBASE_CREDENTIALS_JSON` elsewhere, it is not implemented here.
  - If `GOOGLE_APPLICATION_CREDENTIALS` is unset (as in this project's
    `.env` today), `_get_firebase_app()` returns None,
    `verify_firebase_token()` then always returns None, and
    `require_authenticated_user` raises 401 for every request, including
    ones with a perfectly valid Firebase ID token. In that state the two
    routes above are effectively unusable, not "open" -- fail-closed, not
    fail-open -- but still broken from the Flutter app's point of view.

Required step to make compatibility/alternatives actually work end to end:
  1. Create a Firebase service-account key for the project referenced in
     `lib/firebase_options.dart` and set `GOOGLE_APPLICATION_CREDENTIALS`
     to its path in the backend's deployment environment/secrets --
     never commit it, never put it in Flutter.
  2. Test against that real Firebase project (valid token accepted,
     missing/expired/invalid token rejected with 401) before relying on
     it in production.

Until step 1 is done, POST .../compatibility and POST .../alternatives
will reject every request with 401 regardless of the token sent, as
documented in the FATEEN Architecture Audit report and in
lib/services/api_client.dart's class-level security note.
"""
import logging
import os
from typing import Optional

from fastapi import Header, HTTPException

logger = logging.getLogger("fateen.core.auth")

_firebase_app = None


def _get_firebase_app():
    """Lazily initializes the firebase_admin app. Returns None (never
    raises) if firebase_admin isn't installed or no credential is
    configured, so importing this module never breaks the app in an
    environment where auth enforcement hasn't been turned on yet.
    """
    global _firebase_app
    if _firebase_app is not None:
        return _firebase_app

    credential_path = os.environ.get("GOOGLE_APPLICATION_CREDENTIALS")
    if not credential_path:
        logger.warning(
            "Firebase auth not configured (GOOGLE_APPLICATION_CREDENTIALS "
            "not set) -- require_authenticated_user will reject all "
            "requests until this is configured."
        )
        return None

    try:
        import firebase_admin
        from firebase_admin import credentials

        cred = credentials.Certificate(credential_path)
        _firebase_app = firebase_admin.initialize_app(cred)
        return _firebase_app
    except ImportError:
        logger.error(
            "firebase_admin is not installed (pip install firebase-admin) "
            "-- cannot verify Firebase ID tokens."
        )
        return None
    except Exception:
        logger.exception("Failed to initialize firebase_admin app")
        return None


def verify_firebase_token(token: str) -> Optional[str]:
    """Verifies a Firebase ID token and returns the Firebase UID, or None
    if verification is not configured/available or the token is invalid.
    Never raises -- callers decide what "no verified identity" means for
    their route.
    """
    app = _get_firebase_app()
    if app is None:
        return None

    try:
        from firebase_admin import auth as firebase_auth

        decoded = firebase_auth.verify_id_token(token, app=app)
        return decoded.get("uid")
    except Exception:
        logger.warning("Firebase ID token verification failed", exc_info=True)
        return None


async def require_authenticated_user(
    authorization: Optional[str] = Header(default=None),
) -> str:
    """FastAPI dependency: NOT CURRENTLY ATTACHED TO ANY ROUTE (see module
    docstring). When wired in, raises 401 for a missing/invalid token and
    otherwise returns the verified Firebase UID.
    """
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing bearer token")

    token = authorization.removeprefix("Bearer ").strip()
    uid = verify_firebase_token(token)
    if uid is None:
        raise HTTPException(status_code=401, detail="Invalid or unverifiable token")

    return uid
