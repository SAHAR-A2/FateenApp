from app.db.connection import get_connection


def get_products_count() -> int:
    with get_connection() as conn:
        row = conn.execute(
            "SELECT COUNT(*) AS count FROM public.products WHERE deleted_at IS NULL"
        ).fetchone()

    return row["count"]


def _escape_ilike(term: str) -> str:
    """Escape ILIKE wildcard characters so a search term is matched
    literally, not as a pattern (prevents a user-supplied '%' or '_' from
    changing the query's meaning)."""
    return term.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")


# Shared by search_products / get_alternative_candidates_by_* so the
# "representative barcode for a product" rule (prefer PRIMARY_BARCODE,
# only consider active/effective-dated, non-deleted rows) is defined once.
_REPRESENTATIVE_BARCODE_SUBQUERY = """
        (
            SELECT b.barcode
            FROM public.product_barcodes pb
            JOIN public.barcodes b
                ON b.id = pb.barcode_id
            JOIN public.relationship_types rt
                ON rt.id = pb.relationship_type_id
            WHERE pb.product_id = p.id
              AND pb.deleted_at IS NULL
              AND b.deleted_at IS NULL
              AND (pb.effective_from IS NULL OR pb.effective_from <= NOW())
              AND (pb.effective_to IS NULL OR pb.effective_to > NOW())
            ORDER BY (rt.code = 'PRIMARY_BARCODE') DESC
            LIMIT 1
        ) AS barcode
"""


def search_products(query: str, limit: int = 25) -> list[dict]:
    """Search active, non-deleted products by name (case-insensitive,
    substring match). Returns rows shaped for ProductSearchResult.

    A representative barcode is included where available, preferring a
    PRIMARY_BARCODE relationship if one exists.
    """
    pattern = f"%{_escape_ilike(query)}%"

    sql = f"""
    SELECT
        p.internal_code,
        p.name,
        p.description,
        p.confidence_level,
        ls.code AS lifecycle_status,
        {_REPRESENTATIVE_BARCODE_SUBQUERY}
    FROM public.products p
    JOIN public.lifecycle_statuses ls
        ON ls.id = p.status_id
    WHERE p.deleted_at IS NULL
      AND p.name ILIKE %s ESCAPE '\\'
    ORDER BY p.name
    LIMIT %s
    """

    with get_connection() as conn:
        return conn.execute(sql, (pattern, limit)).fetchall()


def get_alternative_candidates_by_category(
    category_id, exclude_internal_code: str, limit: int = 15
) -> list[dict]:
    """Candidate retrieval for the alternatives feature: other active
    products in the same product_category_id. This only decides which
    products get evaluated by the compatibility service -- it never
    decides safety by itself.
    """
    sql = f"""
    SELECT
        p.internal_code,
        p.name,
        {_REPRESENTATIVE_BARCODE_SUBQUERY}
    FROM public.products p
    WHERE p.deleted_at IS NULL
      AND p.product_category_id = %s
      AND p.internal_code <> %s
    ORDER BY p.name
    LIMIT %s
    """
    with get_connection() as conn:
        return conn.execute(sql, (category_id, exclude_internal_code, limit)).fetchall()


def get_alternative_candidates_by_name_token(
    token: str, exclude_internal_code: str, limit: int = 15
) -> list[dict]:
    """Fallback candidate retrieval when the original product has no
    product_category_id recorded: a plain name-token match. Used ONLY to
    decide which products are worth evaluating -- the actual safety
    decision for each candidate still goes through the same
    compatibility_service as everything else. Not a medical/ranking rule.
    """
    pattern = f"%{_escape_ilike(token)}%"
    sql = f"""
    SELECT
        p.internal_code,
        p.name,
        {_REPRESENTATIVE_BARCODE_SUBQUERY}
    FROM public.products p
    WHERE p.deleted_at IS NULL
      AND p.name ILIKE %s ESCAPE '\\'
      AND p.internal_code <> %s
    ORDER BY p.name
    LIMIT %s
    """
    with get_connection() as conn:
        return conn.execute(sql, (pattern, exclude_internal_code, limit)).fetchall()
