--
-- PostgreSQL database dump
--

\restrict xElkaETu8VG1Nv6myK7LjxD8EtlEBcZuFStWll8HfNB8TIizEfkFf6YQPVWt9Ky

-- Dumped from database version 17.10 (Debian 17.10-1.pgdg13+1)
-- Dumped by pg_dump version 17.10 (Debian 17.10-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: approval_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.approval_status AS ENUM (
    'pending_review',
    'in_review',
    'changes_requested',
    'approved',
    'rejected',
    'cancelled'
);


--
-- Name: candidate_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.candidate_status AS ENUM (
    'discovered',
    'enriched',
    'normalized',
    'pending_review',
    'approved',
    'merged',
    'discarded'
);


--
-- Name: confidence_band; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.confidence_band AS ENUM (
    'very_low',
    'low',
    'medium',
    'high',
    'very_high'
);


--
-- Name: entity_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.entity_status AS ENUM (
    'draft',
    'active',
    'inactive',
    'deprecated',
    'archived'
);


--
-- Name: review_decision; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.review_decision AS ENUM (
    'approved',
    'rejected',
    'changes_requested',
    'escalated'
);


--
-- Name: review_tier; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.review_tier AS ENUM (
    'automated',
    'standard',
    'elevated',
    'expert',
    'consensus'
);


--
-- Name: translation_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.translation_status AS ENUM (
    'draft',
    'in_progress',
    'pending_review',
    'approved',
    'rejected'
);


--
-- Name: unit_dimension; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.unit_dimension AS ENUM (
    'mass',
    'volume',
    'energy',
    'temperature',
    'count',
    'ratio',
    'amount',
    'other'
);


--
-- Name: update_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.update_type AS ENUM (
    'created',
    'modified',
    'published',
    'unpublished',
    'deprecated',
    'archived',
    'merged',
    'split'
);


--
-- Name: version_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.version_status AS ENUM (
    'draft',
    'pending_approval',
    'approved',
    'rejected',
    'superseded'
);


--
-- Name: capture_entity_history(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.capture_entity_history() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
DECLARE
    hist_table      text;
    prev_id         uuid;
    ct              update_type;
    snapshot        jsonb;
    snap_hash       text;
    row_checksum    text;
    col             record;
    target_col      text;
    ins_cols        text[] := '{}';
    sel_fields      text[] := '{}';
    has_updated_by  boolean := false;
    status_code     citext;
BEGIN
    IF TG_TABLE_SCHEMA IS DISTINCT FROM current_schema() THEN
        RETURN COALESCE(NEW, OLD);
    END IF;

    hist_table := TG_TABLE_NAME || '_history';

    SELECT EXISTS (
        SELECT 1
        FROM information_schema.columns
        WHERE table_schema = current_schema()
          AND table_name = TG_TABLE_NAME
          AND column_name = 'updated_by'
    ) INTO has_updated_by;

    -- Classify the change.
    IF TG_OP = 'INSERT' THEN
        ct := 'created';
    ELSIF OLD.deleted_at IS NULL AND NEW.deleted_at IS NOT NULL THEN
        ct := 'archived';
    ELSIF OLD.deleted_at IS NOT NULL AND NEW.deleted_at IS NULL THEN
        ct := 'modified';
    ELSE
        SELECT code INTO status_code FROM lifecycle_statuses WHERE id = NEW.status_id;
        IF status_code = 'ARCHIVED' THEN
            ct := 'archived';
        ELSIF status_code = 'DEPRECATED' THEN
            ct := 'deprecated';
        ELSE
            ct := 'modified';
        END IF;
    END IF;

    -- Avoid duplicate snapshots: an UPDATE that changed nothing except the
    -- trigger-maintained updated_at stamp must not mint a new version.
    IF TG_OP = 'UPDATE' AND (to_jsonb(NEW) - 'updated_at') = (to_jsonb(OLD) - 'updated_at') THEN
        RETURN NEW;
    END IF;

    -- Preserve the version chain: bump the entity counter only when the
    -- application does not manage version_number itself.
    IF TG_OP = 'UPDATE' AND NEW.version_number = OLD.version_number THEN
        NEW.version_number := OLD.version_number + 1;
    END IF;

    -- Materialise the snapshot and map actor columns to their history names.
    -- created_by -> changed_by (COALESCE(updated_by, created_by) when the
    -- entity carries updated_by); updated_by/reviewed_by are never captured.
    -- NOTE: jsonb_set's new_value must never be SQL NULL (that would make the
    -- whole snapshot NULL); to_jsonb(expr) returns SQL NULL for a NULL input,
    -- so a missing actor is mapped to JSON null via COALESCE.
    snapshot := to_jsonb(NEW) - 'updated_at';
    IF snapshot ? 'created_by' THEN
        IF has_updated_by THEN
            snapshot := snapshot - 'created_by' - 'updated_by';
            snapshot := jsonb_set(snapshot, '{changed_by}', COALESCE(to_jsonb(COALESCE(NEW.updated_by, NEW.created_by)), 'null'::jsonb));
        ELSE
            snapshot := snapshot - 'created_by';
            snapshot := jsonb_set(snapshot, '{changed_by}', COALESCE(to_jsonb(NEW.created_by), 'null'::jsonb));
        END IF;
    END IF;

    -- Build the snapshot column list from the entity columns that exist
    -- (possibly renamed) in the history table. version_number is excluded:
    -- it is inserted via the history header (original_entity_id /
    -- version_number / previous_version_id / change_type / hashes), not as a
    -- snapshot column, so it must not appear twice in the INSERT.
    FOR col IN
        SELECT column_name
        FROM information_schema.columns
        WHERE table_schema = current_schema()
          AND table_name = TG_TABLE_NAME
          AND column_name NOT IN ('id', 'version_number', 'updated_at', 'updated_by', 'reviewed_by')
        ORDER BY ordinal_position
    LOOP
        target_col := CASE col.column_name
            WHEN 'created_by' THEN 'changed_by'
            WHEN 'approved_by' THEN 'approved_by'
            ELSE col.column_name
        END;

        IF EXISTS (
            SELECT 1
            FROM information_schema.columns
            WHERE table_schema = current_schema()
              AND table_name = hist_table
              AND column_name = target_col
        ) THEN
            ins_cols   := ins_cols || quote_ident(target_col);
            sel_fields := sel_fields || format('(r).%I', target_col);
        END IF;
    END LOOP;

    -- previous_version_id = the latest history row for this entity.
    EXECUTE format(
        'SELECT id FROM %I WHERE original_entity_id = %L ORDER BY version_number DESC LIMIT 1',
        hist_table, NEW.id
    ) INTO prev_id;

    snap_hash    := encode(digest(snapshot::text, 'sha256'), 'hex');
    row_checksum := encode(
        digest(snap_hash || '|' || NEW.id::text || '|' || NEW.version_number::text || '|' || ct::text, 'sha256'),
        'hex'
    );

    -- Values are passed as a single bound parameter; nothing from NEW is ever
    -- textually embedded in the executed statement.
    EXECUTE format(
        'INSERT INTO %I (original_entity_id, version_number, previous_version_id, change_type, snapshot_hash, checksum, %s) '
        'SELECT %L, %L, %L, %L, %L, %L, %s '
        'FROM (SELECT jsonb_populate_record(NULL::%I, $1) AS r) s',
        hist_table,
        array_to_string(ins_cols, ', '),
        NEW.id,
        NEW.version_number,
        prev_id,
        ct,
        snap_hash,
        row_checksum,
        array_to_string(sel_fields, ', '),
        hist_table
    ) USING snapshot;

    RETURN NEW;
END;
$_$;


--
-- Name: FUNCTION capture_entity_history(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.capture_entity_history() IS 'Automatically records an immutable snapshot into {table}_history on INSERT/UPDATE of a tracked entity; preserves the version chain, prevents duplicate snapshots, and never recurses.';


--
-- Name: check_product_allergies(text, text[]); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.check_product_allergies(p_barcode text, p_allergen_codes text[]) RETURNS TABLE(scanned_barcode text, product_code public.citext, product_name text, matched_allergens text[], decision text)
    LANGUAGE sql STABLE
    AS $$SELECT b.barcode::text, p.internal_code, p.name, ARRAY_AGG(DISTINCT a.internal_code::text ORDER BY a.internal_code::text) FILTER (WHERE a.internal_code::text = ANY(p_allergen_codes)) AS matched_allergens, CASE WHEN COUNT(DISTINCT a.id) FILTER (WHERE a.internal_code::text = ANY(p_allergen_codes)) > 0 THEN 'UNSAFE' ELSE 'SAFE' END FROM public.barcodes b JOIN public.product_barcodes pb ON pb.barcode_id = b.id JOIN public.products p ON p.id = pb.product_id LEFT JOIN public.product_ingredients pi ON pi.product_id = p.id AND pi.status_id = 1 AND pi.deleted_at IS NULL LEFT JOIN public.ingredient_allergens ia ON ia.ingredient_id = pi.ingredient_id AND ia.status_id = 1 AND ia.deleted_at IS NULL LEFT JOIN public.allergens a ON a.id = ia.allergen_id WHERE b.barcode::text = p_barcode AND b.deleted_at IS NULL AND pb.status_id = 1 AND pb.deleted_at IS NULL AND p.status_id = 1 AND p.deleted_at IS NULL GROUP BY b.barcode, p.internal_code, p.name$$;


--
-- Name: check_product_allergy(text, public.citext); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.check_product_allergy(p_barcode text, p_allergen_code public.citext) RETURNS TABLE(scanned_barcode text, product_code public.citext, product_name text, allergen_code public.citext, allergen_name text, decision text)
    LANGUAGE sql STABLE
    AS $$SELECT b.barcode::text, p.internal_code, p.name, a.internal_code, a.name, CASE WHEN EXISTS (SELECT 1 FROM public.product_allergens pa JOIN public.relationship_types rt ON rt.id = pa.relationship_type_id WHERE pa.product_id = p.id AND pa.allergen_id = a.id AND rt.code = 'CONTAINS_ALLERGEN' AND pa.status_id = 1 AND pa.deleted_at IS NULL) THEN 'UNSAFE' WHEN EXISTS (SELECT 1 FROM public.product_allergens pa JOIN public.relationship_types rt ON rt.id = pa.relationship_type_id WHERE pa.product_id = p.id AND pa.allergen_id = a.id AND rt.code = 'MAY_CONTAIN_ALLERGEN' AND pa.status_id = 1 AND pa.deleted_at IS NULL) THEN 'CAUTION' WHEN EXISTS (SELECT 1 FROM public.product_ingredients pi JOIN public.ingredient_allergens ia ON ia.ingredient_id = pi.ingredient_id JOIN public.relationship_types rt ON rt.id = pi.relationship_type_id WHERE pi.product_id = p.id AND ia.allergen_id = a.id AND rt.code IN ('CONTAINS_INGREDIENT', 'MAY_CONTAIN_INGREDIENT') AND pi.status_id = 1 AND ia.status_id = 1 AND pi.deleted_at IS NULL AND ia.deleted_at IS NULL) THEN 'UNSAFE' ELSE 'SAFE' END FROM public.barcodes b JOIN public.product_barcodes pb ON pb.barcode_id = b.id JOIN public.products p ON p.id = pb.product_id JOIN public.allergens a ON a.internal_code = p_allergen_code WHERE b.barcode::text = p_barcode AND b.deleted_at IS NULL AND pb.status_id = 1 AND pb.deleted_at IS NULL AND p.status_id = 1 AND p.deleted_at IS NULL$$;


--
-- Name: prevent_history_mutation(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.prevent_history_mutation() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    RAISE EXCEPTION
        'immutable history: % on % is not permitted (history rows are INSERT-only)',
        TG_OP,
        TG_TABLE_NAME;
END;
$$;


--
-- Name: FUNCTION prevent_history_mutation(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.prevent_history_mutation() IS 'Raises an exception on UPDATE/DELETE of immutable history rows.';


--
-- Name: set_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at := now();
    RETURN NEW;
END;
$$;


--
-- Name: FUNCTION set_updated_at(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.set_updated_at() IS 'Sets updated_at = now() on UPDATE; wired to every audit-carrying table.';


--
-- Name: validate_entity_relationship_endpoints(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_entity_relationship_endpoints() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    subject_ok boolean;
    object_ok  boolean;
BEGIN
    subject_ok := CASE NEW.subject_entity_type
        WHEN 'companies'    THEN EXISTS (SELECT 1 FROM companies    WHERE id = NEW.subject_id)
        WHEN 'brands'       THEN EXISTS (SELECT 1 FROM brands       WHERE id = NEW.subject_id)
        WHEN 'products'     THEN EXISTS (SELECT 1 FROM products     WHERE id = NEW.subject_id)
        WHEN 'ingredients'  THEN EXISTS (SELECT 1 FROM ingredients  WHERE id = NEW.subject_id)
        WHEN 'allergens'    THEN EXISTS (SELECT 1 FROM allergens    WHERE id = NEW.subject_id)
        WHEN 'health_flags' THEN EXISTS (SELECT 1 FROM health_flags WHERE id = NEW.subject_id)
        ELSE NULL
    END;

    IF subject_ok IS NULL THEN
        RAISE EXCEPTION 'entity_relationships: unknown subject_entity_type %', NEW.subject_entity_type;
    END IF;
    IF NOT subject_ok THEN
        RAISE EXCEPTION 'entity_relationships: subject entity % does not exist (id %)',
            NEW.subject_entity_type, NEW.subject_id;
    END IF;

    object_ok := CASE NEW.object_entity_type
        WHEN 'companies'    THEN EXISTS (SELECT 1 FROM companies    WHERE id = NEW.object_id)
        WHEN 'brands'       THEN EXISTS (SELECT 1 FROM brands       WHERE id = NEW.object_id)
        WHEN 'products'     THEN EXISTS (SELECT 1 FROM products     WHERE id = NEW.object_id)
        WHEN 'ingredients'  THEN EXISTS (SELECT 1 FROM ingredients  WHERE id = NEW.object_id)
        WHEN 'allergens'    THEN EXISTS (SELECT 1 FROM allergens    WHERE id = NEW.object_id)
        WHEN 'health_flags' THEN EXISTS (SELECT 1 FROM health_flags WHERE id = NEW.object_id)
        ELSE NULL
    END;

    IF object_ok IS NULL THEN
        RAISE EXCEPTION 'entity_relationships: unknown object_entity_type %', NEW.object_entity_type;
    END IF;
    IF NOT object_ok THEN
        RAISE EXCEPTION 'entity_relationships: object entity % does not exist (id %)',
            NEW.object_entity_type, NEW.object_id;
    END IF;

    RETURN NEW;
END;
$$;


--
-- Name: FUNCTION validate_entity_relationship_endpoints(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.validate_entity_relationship_endpoints() IS 'Rejects entity_relationships rows whose subject or object endpoint does not exist in its declared entity table (database-level polymorphic reference validation).';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: allergen_translations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.allergen_translations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    allergen_id uuid NOT NULL,
    language_id uuid NOT NULL,
    name text NOT NULL,
    short_name text,
    display_name text NOT NULL,
    search_name text,
    description text,
    translation_status public.translation_status DEFAULT 'draft'::public.translation_status NOT NULL,
    version_number integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT allergen_translations_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE allergen_translations; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.allergen_translations IS 'Per-language translations of allergens (unique per allergen and language).';


--
-- Name: COLUMN allergen_translations.name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.allergen_translations.name IS 'Translated canonical name of the allergen.';


--
-- Name: COLUMN allergen_translations.display_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.allergen_translations.display_name IS 'User-facing label for the allergen in this language.';


--
-- Name: COLUMN allergen_translations.search_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.allergen_translations.search_name IS 'Normalized search variant (e.g. transliteration); NULL when not needed.';


--
-- Name: COLUMN allergen_translations.translation_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.allergen_translations.translation_status IS 'Governed quality lifecycle of this translation row.';


--
-- Name: allergen_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.allergen_types (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    code public.citext NOT NULL,
    name text NOT NULL,
    description text,
    display_order integer DEFAULT 0 NOT NULL,
    status_id bigint NOT NULL,
    version_number integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT allergen_types_display_order_check CHECK ((display_order >= 0)),
    CONSTRAINT allergen_types_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE allergen_types; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.allergen_types IS 'Governed registry of allergen classes (business knowledge, not ENUM).';


--
-- Name: COLUMN allergen_types.code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.allergen_types.code IS 'Stable machine reference (snake_case), e.g. gluten, tree_nuts, sesame.';


--
-- Name: COLUMN allergen_types.version_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.allergen_types.version_number IS 'Monotonic governance/version counter; starts at 1, increments on governed change.';


--
-- Name: allergens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.allergens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    allergen_type_id uuid,
    internal_code public.citext NOT NULL,
    name text NOT NULL,
    description text,
    status_id bigint NOT NULL,
    source_id uuid,
    confidence_level numeric DEFAULT 0.5 NOT NULL,
    verified_at timestamp with time zone,
    approved_at timestamp with time zone,
    deprecated_at timestamp with time zone,
    version_number integer DEFAULT 1 NOT NULL,
    created_by uuid,
    approved_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT allergens_confidence_level_check CHECK (((confidence_level >= (0)::numeric) AND (confidence_level <= (1)::numeric))),
    CONSTRAINT allergens_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE allergens; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.allergens IS 'Canonical registry of specific allergens (governed, provenance-tracked entity).';


--
-- Name: COLUMN allergens.allergen_type_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.allergens.allergen_type_id IS 'Allergen class (foreign key to allergen_types); NULL when not yet classified.';


--
-- Name: COLUMN allergens.internal_code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.allergens.internal_code IS 'Stable internal machine reference (unique, citext).';


--
-- Name: COLUMN allergens.confidence_level; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.allergens.confidence_level IS 'Numeric fact confidence in [0,1]; the confidence_band ENUM is derived, never stored.';


--
-- Name: COLUMN allergens.version_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.allergens.version_number IS 'Monotonic governance/version counter; starts at 1, increments on governed change.';


--
-- Name: COLUMN allergens.created_by; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.allergens.created_by IS 'UUID of the actor that created the row; FK to the future auth service (none yet).';


--
-- Name: COLUMN allergens.approved_by; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.allergens.approved_by IS 'UUID of the actor that approved the row; FK to the future auth service (none yet).';


--
-- Name: allergens_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.allergens_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    original_entity_id uuid NOT NULL,
    version_number integer NOT NULL,
    previous_version_id uuid,
    change_set_id uuid,
    change_type public.update_type NOT NULL,
    change_reason text,
    changed_by uuid,
    approved_by uuid,
    source_id uuid,
    confidence_level numeric DEFAULT 0.5 NOT NULL,
    allergen_type_id uuid,
    internal_code public.citext NOT NULL,
    name text NOT NULL,
    description text,
    status_id bigint NOT NULL,
    verified_at timestamp with time zone,
    approved_at timestamp with time zone,
    deprecated_at timestamp with time zone,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    effective_from timestamp with time zone DEFAULT now() NOT NULL,
    effective_to timestamp with time zone,
    superseded_at timestamp with time zone,
    snapshot_hash text NOT NULL,
    checksum text NOT NULL,
    version_status public.version_status DEFAULT 'draft'::public.version_status NOT NULL,
    CONSTRAINT allergens_history_confidence_level_check CHECK (((confidence_level >= (0)::numeric) AND (confidence_level <= (1)::numeric))),
    CONSTRAINT allergens_history_effective_window_check CHECK (((effective_to IS NULL) OR (effective_to >= effective_from))),
    CONSTRAINT allergens_history_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE allergens_history; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.allergens_history IS 'Immutable version-history of allergens (INSERT-only; one row per version).';


--
-- Name: COLUMN allergens_history.original_entity_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.allergens_history.original_entity_id IS 'Canonical allergen this version belongs to (foreign key to allergens, applied in 0022).';


--
-- Name: COLUMN allergens_history.previous_version_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.allergens_history.previous_version_id IS 'Self-reference to the immediately prior version row; NULL for the first version.';


--
-- Name: COLUMN allergens_history.change_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.allergens_history.change_type IS 'Nature of the change recorded by this version (existing update_type ENUM).';


--
-- Name: COLUMN allergens_history.allergen_type_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.allergens_history.allergen_type_id IS 'Allergen class at this version (foreign key to allergen_types, applied in 0022).';


--
-- Name: COLUMN allergens_history.snapshot_hash; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.allergens_history.snapshot_hash IS 'SHA-256 of the snapshot columns (application-computed) to verify a stored version matches the original state.';


--
-- Name: COLUMN allergens_history.checksum; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.allergens_history.checksum IS 'Checksum of the full history row for tamper evidence.';


--
-- Name: COLUMN allergens_history.version_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.allergens_history.version_status IS 'Version lifecycle: draft -> pending_approval -> approved -> superseded (existing version_status ENUM).';


--
-- Name: audit_context; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_context (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    correlation_id uuid NOT NULL,
    transaction_id uuid NOT NULL,
    actor uuid,
    role_id uuid,
    source text,
    ip_address inet,
    user_agent text,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: TABLE audit_context; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.audit_context IS 'Per-operation audit context (one row per correlation/transaction pair).';


--
-- Name: COLUMN audit_context.correlation_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.audit_context.correlation_id IS 'End-to-end request/correlation identifier (unique with transaction_id).';


--
-- Name: COLUMN audit_context.transaction_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.audit_context.transaction_id IS 'Database transaction identifier within the operation (unique with correlation_id).';


--
-- Name: COLUMN audit_context.actor; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.audit_context.actor IS 'UUID of the acting principal; FK to the future auth service (none yet, ADR-005).';


--
-- Name: COLUMN audit_context.role_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.audit_context.role_id IS 'Authorized role of the actor (foreign key to role_types, applied in 0022).';


--
-- Name: COLUMN audit_context.ip_address; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.audit_context.ip_address IS 'Requesting host IP; nullable placeholder, never business data.';


--
-- Name: COLUMN audit_context.user_agent; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.audit_context.user_agent IS 'Requesting client user agent; nullable placeholder, never business data.';


--
-- Name: audit_event_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_event_types (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    code public.citext NOT NULL,
    name text NOT NULL,
    description text,
    display_order integer DEFAULT 0 NOT NULL,
    status_id bigint NOT NULL,
    version_number integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT audit_event_types_display_order_check CHECK ((display_order >= 0)),
    CONSTRAINT audit_event_types_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE audit_event_types; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.audit_event_types IS 'Governed registry of audit event classes (created, updated, merged, ...).';


--
-- Name: COLUMN audit_event_types.code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.audit_event_types.code IS 'Stable machine reference (snake_case), e.g. created, status_changed, merged.';


--
-- Name: COLUMN audit_event_types.version_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.audit_event_types.version_number IS 'Monotonic governance/version counter; starts at 1, increments on governed change.';


--
-- Name: audit_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    audit_log_id uuid NOT NULL,
    event_type_id uuid NOT NULL,
    entity_type text NOT NULL,
    entity_id uuid,
    previous_version integer,
    new_version integer NOT NULL,
    event_time timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: TABLE audit_events; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.audit_events IS 'Normalized per-version event details (one row per version record written).';


--
-- Name: COLUMN audit_events.audit_log_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.audit_events.audit_log_id IS 'Owning feed entry (foreign key to audit_log, applied in 0022).';


--
-- Name: COLUMN audit_events.event_type_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.audit_events.event_type_id IS 'Per-version action class (foreign key to audit_event_types, applied in 0022).';


--
-- Name: COLUMN audit_events.entity_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.audit_events.entity_type IS 'Canonical entity/table the version belongs to (text discriminator, no FK).';


--
-- Name: COLUMN audit_events.entity_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.audit_events.entity_id IS 'Canonical entity id the version belongs to.';


--
-- Name: COLUMN audit_events.previous_version; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.audit_events.previous_version IS 'Version number before this version (NULL on create).';


--
-- Name: COLUMN audit_events.new_version; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.audit_events.new_version IS 'Version number recorded by this event.';


--
-- Name: COLUMN audit_events.event_time; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.audit_events.event_time IS 'When the version event was recorded (server clock).';


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    change_set_id uuid,
    event_type_id uuid NOT NULL,
    entity_type text NOT NULL,
    entity_id uuid,
    previous_version integer,
    new_version integer NOT NULL,
    actor uuid,
    role_id uuid,
    source text,
    ip_address inet,
    user_agent text,
    correlation_id uuid,
    transaction_id uuid,
    logged_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: TABLE audit_log; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.audit_log IS 'Append-only audit event feed (self-contained per-change narrative).';


--
-- Name: COLUMN audit_log.change_set_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.audit_log.change_set_id IS 'Owning logical change (foreign key to change_sets, applied in 0022).';


--
-- Name: COLUMN audit_log.event_type_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.audit_log.event_type_id IS 'Classified action, the mission "action" field (foreign key to audit_event_types, applied in 0022).';


--
-- Name: COLUMN audit_log.entity_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.audit_log.entity_type IS 'Canonical entity/table the change acted on (the mission "entity" field; text discriminator, no FK).';


--
-- Name: COLUMN audit_log.entity_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.audit_log.entity_id IS 'Entity id the change acted on (the mission "entity_id" field).';


--
-- Name: COLUMN audit_log.previous_version; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.audit_log.previous_version IS 'Version number of the entity before the change (NULL on create).';


--
-- Name: COLUMN audit_log.new_version; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.audit_log.new_version IS 'Version number of the entity after the change.';


--
-- Name: COLUMN audit_log.actor; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.audit_log.actor IS 'UUID of the acting principal; FK to the future auth service (none yet, ADR-005).';


--
-- Name: COLUMN audit_log.role_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.audit_log.role_id IS 'Authorized role of the actor (foreign key to role_types, applied in 0022).';


--
-- Name: COLUMN audit_log.ip_address; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.audit_log.ip_address IS 'Requesting host IP; nullable placeholder, never business data.';


--
-- Name: COLUMN audit_log.user_agent; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.audit_log.user_agent IS 'Requesting client user agent; nullable placeholder, never business data.';


--
-- Name: COLUMN audit_log.logged_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.audit_log.logged_at IS 'When the feed entry was recorded (server clock).';


--
-- Name: barcode_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.barcode_types (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    code public.citext NOT NULL,
    name text NOT NULL,
    digit_length smallint,
    description text,
    display_order integer DEFAULT 0 NOT NULL,
    status_id bigint NOT NULL,
    version_number integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT barcode_types_digit_length_check CHECK (((digit_length IS NULL) OR (digit_length > 0))),
    CONSTRAINT barcode_types_display_order_check CHECK ((display_order >= 0)),
    CONSTRAINT barcode_types_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE barcode_types; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.barcode_types IS 'Governed registry of barcode symbologies.';


--
-- Name: COLUMN barcode_types.digit_length; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.barcode_types.digit_length IS 'Fixed numeric payload length for GTIN family; NULL for 2D/matrix types.';


--
-- Name: COLUMN barcode_types.version_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.barcode_types.version_number IS 'Monotonic governance/version counter; starts at 1, increments on governed change.';


--
-- Name: barcodes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.barcodes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    barcode public.citext NOT NULL,
    barcode_type_id uuid NOT NULL,
    verification_status_id uuid NOT NULL,
    source_id uuid,
    status_id bigint NOT NULL,
    issued_country_id uuid,
    confidence_level numeric DEFAULT 0.5 NOT NULL,
    version_number integer DEFAULT 1 NOT NULL,
    created_by uuid,
    updated_by uuid,
    reviewed_by uuid,
    approved_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT barcodes_barcode_not_empty_check CHECK ((barcode OPERATOR(public.<>) ''::public.citext)),
    CONSTRAINT barcodes_confidence_level_check CHECK (((confidence_level >= (0)::numeric) AND (confidence_level <= (1)::numeric))),
    CONSTRAINT barcodes_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE barcodes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.barcodes IS 'Canonical registry of globally unique barcodes with lifecycle and verification statuses.';


--
-- Name: COLUMN barcodes.barcode; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.barcodes.barcode IS 'Globally unique code value (unique, case-insensitive citext).';


--
-- Name: COLUMN barcodes.barcode_type_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.barcodes.barcode_type_id IS 'Symbology of the code (foreign key to barcode_types: gtin_13, qr, ...).';


--
-- Name: COLUMN barcodes.verification_status_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.barcodes.verification_status_id IS 'Trust status of the code, orthogonal to lifecycle (foreign key to verification_statuses).';


--
-- Name: COLUMN barcodes.source_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.barcodes.source_id IS 'Provenance of the barcode record (foreign key to data_sources).';


--
-- Name: COLUMN barcodes.status_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.barcodes.status_id IS 'Lifecycle of the barcode (foreign key to lifecycle_statuses; ADR-008). No active boolean is stored.';


--
-- Name: COLUMN barcodes.issued_country_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.barcodes.issued_country_id IS 'Issuing jurisdiction / GS1 prefix country, NULL when unknown (foreign key to countries).';


--
-- Name: COLUMN barcodes.confidence_level; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.barcodes.confidence_level IS 'Fact confidence of this barcode record in [0,1]; the confidence_band ENUM is derived, never stored.';


--
-- Name: COLUMN barcodes.version_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.barcodes.version_number IS 'Monotonic governance/version counter; starts at 1, increments on governed change.';


--
-- Name: barcodes_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.barcodes_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    original_entity_id uuid NOT NULL,
    version_number integer NOT NULL,
    previous_version_id uuid,
    change_set_id uuid,
    change_type public.update_type NOT NULL,
    change_reason text,
    changed_by uuid,
    approved_by uuid,
    source_id uuid,
    confidence_level numeric DEFAULT 0.5 NOT NULL,
    barcode public.citext NOT NULL,
    barcode_type_id uuid NOT NULL,
    verification_status_id uuid NOT NULL,
    issued_country_id uuid,
    status_id bigint NOT NULL,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    effective_from timestamp with time zone DEFAULT now() NOT NULL,
    effective_to timestamp with time zone,
    superseded_at timestamp with time zone,
    snapshot_hash text NOT NULL,
    checksum text NOT NULL,
    version_status public.version_status DEFAULT 'draft'::public.version_status NOT NULL,
    CONSTRAINT barcodes_history_barcode_not_empty_check CHECK ((barcode OPERATOR(public.<>) ''::public.citext)),
    CONSTRAINT barcodes_history_confidence_level_check CHECK (((confidence_level >= (0)::numeric) AND (confidence_level <= (1)::numeric))),
    CONSTRAINT barcodes_history_effective_window_check CHECK (((effective_to IS NULL) OR (effective_to >= effective_from))),
    CONSTRAINT barcodes_history_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE barcodes_history; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.barcodes_history IS 'Immutable version-history of barcodes (INSERT-only; one row per version).';


--
-- Name: COLUMN barcodes_history.original_entity_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.barcodes_history.original_entity_id IS 'Canonical barcode this version belongs to (foreign key to barcodes, applied in 0027).';


--
-- Name: COLUMN barcodes_history.previous_version_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.barcodes_history.previous_version_id IS 'Self-reference to the immediately prior version row; NULL for the first version.';


--
-- Name: COLUMN barcodes_history.change_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.barcodes_history.change_type IS 'Nature of the change recorded by this version (existing update_type ENUM).';


--
-- Name: COLUMN barcodes_history.verification_status_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.barcodes_history.verification_status_id IS 'Verification state of the barcode at this version (foreign key to verification_statuses, applied in 0027).';


--
-- Name: COLUMN barcodes_history.snapshot_hash; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.barcodes_history.snapshot_hash IS 'SHA-256 of the snapshot columns (application-computed) to verify a stored version matches the original state.';


--
-- Name: COLUMN barcodes_history.checksum; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.barcodes_history.checksum IS 'Checksum of the full history row for tamper evidence.';


--
-- Name: COLUMN barcodes_history.version_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.barcodes_history.version_status IS 'Version lifecycle: draft -> pending_approval -> approved -> superseded (existing version_status ENUM).';


--
-- Name: brand_search_index; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.brand_search_index (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    brand_id uuid NOT NULL,
    search_name text NOT NULL,
    search_text text NOT NULL,
    search_tokens text[] DEFAULT '{}'::text[] NOT NULL,
    language_codes public.citext[] DEFAULT '{}'::public.citext[] NOT NULL,
    search_rank numeric DEFAULT 0 NOT NULL,
    generated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT brand_search_index_search_rank_check CHECK ((search_rank >= (0)::numeric))
);


--
-- Name: TABLE brand_search_index; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.brand_search_index IS 'Derived, rebuildable search index for brands (read model; no FK to brands).';


--
-- Name: COLUMN brand_search_index.brand_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.brand_search_index.brand_id IS 'Logical reference to brands.id; NO foreign key - the search layer is disposable and rebuildable.';


--
-- Name: COLUMN brand_search_index.search_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.brand_search_index.search_name IS 'Normalized primary searchable name (application-built from canonical name/translations).';


--
-- Name: COLUMN brand_search_index.search_text; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.brand_search_index.search_text IS 'Normalized concatenated searchable text: description, owning company, internal code.';


--
-- Name: COLUMN brand_search_index.search_tokens; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.brand_search_index.search_tokens IS 'Language-independent normalized search tokens (folded, accent-stripped).';


--
-- Name: COLUMN brand_search_index.language_codes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.brand_search_index.language_codes IS 'Languages covered by the searchable text (citext codes, e.g. {ar,en}).';


--
-- Name: COLUMN brand_search_index.search_rank; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.brand_search_index.search_rank IS 'Ranking helper >= 0; higher means the result is promoted.';


--
-- Name: COLUMN brand_search_index.generated_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.brand_search_index.generated_at IS 'Timestamp when this search row was generated or refreshed (rebuild tracking).';


--
-- Name: brand_translations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.brand_translations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    brand_id uuid NOT NULL,
    language_id uuid NOT NULL,
    name text NOT NULL,
    short_name text,
    display_name text NOT NULL,
    search_name text,
    description text,
    translation_status public.translation_status DEFAULT 'draft'::public.translation_status NOT NULL,
    version_number integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT brand_translations_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE brand_translations; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.brand_translations IS 'Per-language translations of brands (unique per brand and language).';


--
-- Name: COLUMN brand_translations.name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.brand_translations.name IS 'Translated canonical name of the brand.';


--
-- Name: COLUMN brand_translations.display_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.brand_translations.display_name IS 'User-facing label for the brand in this language.';


--
-- Name: COLUMN brand_translations.search_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.brand_translations.search_name IS 'Normalized search variant (e.g. transliteration); NULL when not needed.';


--
-- Name: COLUMN brand_translations.translation_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.brand_translations.translation_status IS 'Governed quality lifecycle of this translation row.';


--
-- Name: brands; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.brands (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    internal_code public.citext NOT NULL,
    name text NOT NULL,
    description text,
    status_id bigint NOT NULL,
    source_id uuid,
    confidence_level numeric DEFAULT 0.5 NOT NULL,
    verified_at timestamp with time zone,
    approved_at timestamp with time zone,
    deprecated_at timestamp with time zone,
    version_number integer DEFAULT 1 NOT NULL,
    created_by uuid,
    approved_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT brands_confidence_level_check CHECK (((confidence_level >= (0)::numeric) AND (confidence_level <= (1)::numeric))),
    CONSTRAINT brands_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE brands; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.brands IS 'Canonical registry of brands, each owned by exactly one company.';


--
-- Name: COLUMN brands.company_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.brands.company_id IS 'Owning company (foreign key to companies).';


--
-- Name: COLUMN brands.internal_code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.brands.internal_code IS 'Stable internal machine reference (unique, citext).';


--
-- Name: COLUMN brands.confidence_level; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.brands.confidence_level IS 'Numeric fact confidence in [0,1]; the confidence_band ENUM is derived, never stored.';


--
-- Name: COLUMN brands.version_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.brands.version_number IS 'Monotonic governance/version counter; starts at 1, increments on governed change.';


--
-- Name: COLUMN brands.created_by; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.brands.created_by IS 'UUID of the actor that created the row; FK to the future auth service (none yet).';


--
-- Name: COLUMN brands.approved_by; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.brands.approved_by IS 'UUID of the actor that approved the row; FK to the future auth service (none yet).';


--
-- Name: brands_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.brands_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    original_entity_id uuid NOT NULL,
    version_number integer NOT NULL,
    previous_version_id uuid,
    change_set_id uuid,
    change_type public.update_type NOT NULL,
    change_reason text,
    changed_by uuid,
    approved_by uuid,
    source_id uuid,
    confidence_level numeric DEFAULT 0.5 NOT NULL,
    company_id uuid NOT NULL,
    internal_code public.citext NOT NULL,
    name text NOT NULL,
    description text,
    status_id bigint NOT NULL,
    verified_at timestamp with time zone,
    approved_at timestamp with time zone,
    deprecated_at timestamp with time zone,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    effective_from timestamp with time zone DEFAULT now() NOT NULL,
    effective_to timestamp with time zone,
    superseded_at timestamp with time zone,
    snapshot_hash text NOT NULL,
    checksum text NOT NULL,
    version_status public.version_status DEFAULT 'draft'::public.version_status NOT NULL,
    CONSTRAINT brands_history_confidence_level_check CHECK (((confidence_level >= (0)::numeric) AND (confidence_level <= (1)::numeric))),
    CONSTRAINT brands_history_effective_window_check CHECK (((effective_to IS NULL) OR (effective_to >= effective_from))),
    CONSTRAINT brands_history_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE brands_history; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.brands_history IS 'Immutable version-history of brands (INSERT-only; one row per version).';


--
-- Name: COLUMN brands_history.original_entity_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.brands_history.original_entity_id IS 'Canonical brand this version belongs to (foreign key to brands, applied in 0022).';


--
-- Name: COLUMN brands_history.previous_version_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.brands_history.previous_version_id IS 'Self-reference to the immediately prior version row; NULL for the first version.';


--
-- Name: COLUMN brands_history.change_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.brands_history.change_type IS 'Nature of the change recorded by this version (existing update_type ENUM).';


--
-- Name: COLUMN brands_history.company_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.brands_history.company_id IS 'Owning company at this version (foreign key to companies, applied in 0022).';


--
-- Name: COLUMN brands_history.snapshot_hash; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.brands_history.snapshot_hash IS 'SHA-256 of the snapshot columns (application-computed) to verify a stored version matches the original state.';


--
-- Name: COLUMN brands_history.checksum; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.brands_history.checksum IS 'Checksum of the full history row for tamper evidence.';


--
-- Name: COLUMN brands_history.version_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.brands_history.version_status IS 'Version lifecycle: draft -> pending_approval -> approved -> superseded (existing version_status ENUM).';


--
-- Name: change_sets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.change_sets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    correlation_id uuid NOT NULL,
    transaction_id uuid NOT NULL,
    description text,
    applied_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: TABLE change_sets; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.change_sets IS 'Logical grouping of version records produced by one governed change.';


--
-- Name: COLUMN change_sets.correlation_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.change_sets.correlation_id IS 'Owner operation correlation id (composite foreign key to audit_context, applied in 0022).';


--
-- Name: COLUMN change_sets.transaction_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.change_sets.transaction_id IS 'Owner operation transaction id (composite foreign key to audit_context, applied in 0022).';


--
-- Name: COLUMN change_sets.description; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.change_sets.description IS 'Human-readable description of the logical change (why the versions were written).';


--
-- Name: COLUMN change_sets.applied_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.change_sets.applied_at IS 'When the change was committed (server clock).';


--
-- Name: companies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.companies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    internal_code public.citext NOT NULL,
    name text NOT NULL,
    description text,
    status_id bigint NOT NULL,
    source_id uuid,
    confidence_level numeric DEFAULT 0.5 NOT NULL,
    verified_at timestamp with time zone,
    approved_at timestamp with time zone,
    deprecated_at timestamp with time zone,
    version_number integer DEFAULT 1 NOT NULL,
    created_by uuid,
    approved_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    slug text,
    priority integer DEFAULT 50 NOT NULL,
    priority_score double precision,
    expected_product_count integer,
    discovered_product_count integer DEFAULT 0 NOT NULL,
    verified_product_count integer DEFAULT 0 NOT NULL,
    failed_product_count integer DEFAULT 0 NOT NULL,
    conflict_count integer DEFAULT 0 NOT NULL,
    missing_data_count integer DEFAULT 0 NOT NULL,
    barcode_coverage_pct double precision,
    ingredient_coverage_pct double precision,
    allergen_coverage_pct double precision,
    nutrition_coverage_pct double precision,
    evidence_coverage_pct double precision,
    last_scan_at timestamp with time zone,
    next_scan_at timestamp with time zone,
    country text DEFAULT 'SA'::text NOT NULL,
    market text DEFAULT 'packaged_food'::text NOT NULL,
    scan_status text DEFAULT 'pending'::text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb,
    CONSTRAINT companies_confidence_level_check CHECK (((confidence_level >= (0)::numeric) AND (confidence_level <= (1)::numeric))),
    CONSTRAINT companies_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE companies; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.companies IS 'Canonical registry of companies (manufacturers, distributors, retailers).';


--
-- Name: COLUMN companies.internal_code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.companies.internal_code IS 'Stable internal machine reference (unique, citext).';


--
-- Name: COLUMN companies.confidence_level; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.companies.confidence_level IS 'Numeric fact confidence in [0,1]; the confidence_band ENUM is derived, never stored.';


--
-- Name: COLUMN companies.version_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.companies.version_number IS 'Monotonic governance/version counter; starts at 1, increments on governed change.';


--
-- Name: COLUMN companies.created_by; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.companies.created_by IS 'UUID of the actor that created the row; FK to the future auth service (none yet).';


--
-- Name: COLUMN companies.approved_by; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.companies.approved_by IS 'UUID of the actor that approved the row; FK to the future auth service (none yet).';


--
-- Name: companies_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.companies_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    original_entity_id uuid NOT NULL,
    version_number integer NOT NULL,
    previous_version_id uuid,
    change_set_id uuid,
    change_type public.update_type NOT NULL,
    change_reason text,
    changed_by uuid,
    approved_by uuid,
    source_id uuid,
    confidence_level numeric DEFAULT 0.5 NOT NULL,
    internal_code public.citext NOT NULL,
    name text NOT NULL,
    description text,
    status_id bigint NOT NULL,
    verified_at timestamp with time zone,
    approved_at timestamp with time zone,
    deprecated_at timestamp with time zone,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    effective_from timestamp with time zone DEFAULT now() NOT NULL,
    effective_to timestamp with time zone,
    superseded_at timestamp with time zone,
    snapshot_hash text NOT NULL,
    checksum text NOT NULL,
    version_status public.version_status DEFAULT 'draft'::public.version_status NOT NULL,
    CONSTRAINT companies_history_confidence_level_check CHECK (((confidence_level >= (0)::numeric) AND (confidence_level <= (1)::numeric))),
    CONSTRAINT companies_history_effective_window_check CHECK (((effective_to IS NULL) OR (effective_to >= effective_from))),
    CONSTRAINT companies_history_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE companies_history; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.companies_history IS 'Immutable version-history of companies (INSERT-only; one row per version).';


--
-- Name: COLUMN companies_history.original_entity_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.companies_history.original_entity_id IS 'Canonical company this version belongs to (foreign key to companies, applied in 0022).';


--
-- Name: COLUMN companies_history.previous_version_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.companies_history.previous_version_id IS 'Self-reference to the immediately prior version row; NULL for the first version.';


--
-- Name: COLUMN companies_history.change_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.companies_history.change_type IS 'Nature of the change recorded by this version (existing update_type ENUM).';


--
-- Name: COLUMN companies_history.snapshot_hash; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.companies_history.snapshot_hash IS 'SHA-256 of the snapshot columns (application-computed) to verify a stored version matches the original state.';


--
-- Name: COLUMN companies_history.checksum; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.companies_history.checksum IS 'Checksum of the full history row for tamper evidence.';


--
-- Name: COLUMN companies_history.version_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.companies_history.version_status IS 'Version lifecycle: draft -> pending_approval -> approved -> superseded (existing version_status ENUM).';


--
-- Name: company_search_index; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_search_index (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    search_name text NOT NULL,
    search_text text NOT NULL,
    search_tokens text[] DEFAULT '{}'::text[] NOT NULL,
    language_codes public.citext[] DEFAULT '{}'::public.citext[] NOT NULL,
    search_rank numeric DEFAULT 0 NOT NULL,
    generated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT company_search_index_search_rank_check CHECK ((search_rank >= (0)::numeric))
);


--
-- Name: TABLE company_search_index; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.company_search_index IS 'Derived, rebuildable search index for companies (read model; no FK to companies).';


--
-- Name: COLUMN company_search_index.company_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.company_search_index.company_id IS 'Logical reference to companies.id; NO foreign key - the search layer is disposable and rebuildable.';


--
-- Name: COLUMN company_search_index.search_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.company_search_index.search_name IS 'Normalized primary searchable name (application-built from canonical name/translations).';


--
-- Name: COLUMN company_search_index.search_text; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.company_search_index.search_text IS 'Normalized concatenated searchable text: description, country, internal code.';


--
-- Name: COLUMN company_search_index.search_tokens; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.company_search_index.search_tokens IS 'Language-independent normalized search tokens (folded, accent-stripped).';


--
-- Name: COLUMN company_search_index.language_codes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.company_search_index.language_codes IS 'Languages covered by the searchable text (citext codes, e.g. {ar,en}).';


--
-- Name: COLUMN company_search_index.search_rank; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.company_search_index.search_rank IS 'Ranking helper >= 0; higher means the result is promoted.';


--
-- Name: COLUMN company_search_index.generated_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.company_search_index.generated_at IS 'Timestamp when this search row was generated or refreshed (rebuild tracking).';


--
-- Name: company_translations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_translations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    language_id uuid NOT NULL,
    name text NOT NULL,
    short_name text,
    display_name text NOT NULL,
    search_name text,
    description text,
    translation_status public.translation_status DEFAULT 'draft'::public.translation_status NOT NULL,
    version_number integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT company_translations_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE company_translations; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.company_translations IS 'Per-language translations of companies (unique per company and language).';


--
-- Name: COLUMN company_translations.name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.company_translations.name IS 'Translated canonical name of the company.';


--
-- Name: COLUMN company_translations.display_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.company_translations.display_name IS 'User-facing label for the company in this language.';


--
-- Name: COLUMN company_translations.search_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.company_translations.search_name IS 'Normalized search variant (e.g. transliteration); NULL when not needed.';


--
-- Name: COLUMN company_translations.translation_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.company_translations.translation_status IS 'Governed quality lifecycle of this translation row.';


--
-- Name: condition_nutrition_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.condition_nutrition_rules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    condition_id uuid NOT NULL,
    nutrition_type_code text NOT NULL,
    operator text NOT NULL,
    threshold_value double precision NOT NULL,
    unit_code text NOT NULL,
    severity text DEFAULT 'warning'::text NOT NULL,
    description text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: countries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.countries (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    code public.citext NOT NULL,
    alpha_3 public.citext NOT NULL,
    numeric_code text NOT NULL,
    name text NOT NULL,
    is_gcc_member boolean DEFAULT false NOT NULL,
    status_id bigint NOT NULL,
    version_number integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT countries_alpha_3_check CHECK ((alpha_3 OPERATOR(public.~) '^[A-Za-z]{3}$'::public.citext)),
    CONSTRAINT countries_code_check CHECK ((code OPERATOR(public.~) '^[A-Za-z]{2}$'::public.citext)),
    CONSTRAINT countries_numeric_code_check CHECK ((numeric_code ~ '^[0-9]{3}$'::text)),
    CONSTRAINT countries_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE countries; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.countries IS 'Governed registry of countries (ISO 3166-1), Saudi-first with GCC/global scope.';


--
-- Name: COLUMN countries.code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.countries.code IS 'ISO 3166-1 alpha-2 country code.';


--
-- Name: COLUMN countries.alpha_3; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.countries.alpha_3 IS 'ISO 3166-1 alpha-3 country code.';


--
-- Name: COLUMN countries.numeric_code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.countries.numeric_code IS 'ISO 3166-1 numeric three-digit country code.';


--
-- Name: COLUMN countries.is_gcc_member; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.countries.is_gcc_member IS 'True for Gulf Cooperation Council member states; feeds the GCC expansion phase.';


--
-- Name: COLUMN countries.version_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.countries.version_number IS 'Monotonic governance/version counter; starts at 1, increments on governed change.';


--
-- Name: coverage_snapshots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.coverage_snapshots (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    scan_job_id uuid,
    total_products integer DEFAULT 0 NOT NULL,
    products_with_barcode integer DEFAULT 0 NOT NULL,
    products_with_ingredients integer DEFAULT 0 NOT NULL,
    products_with_allergens integer DEFAULT 0 NOT NULL,
    products_with_nutrition integer DEFAULT 0 NOT NULL,
    products_with_evidence integer DEFAULT 0 NOT NULL,
    products_with_halal integer DEFAULT 0 NOT NULL,
    barcode_coverage_pct double precision,
    ingredient_coverage_pct double precision,
    allergen_coverage_pct double precision,
    nutrition_coverage_pct double precision,
    evidence_coverage_pct double precision,
    halal_coverage_pct double precision,
    overall_coverage_pct double precision,
    snapshot_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: data_conflicts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.data_conflicts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    entity_type text NOT NULL,
    entity_id uuid NOT NULL,
    entity_name text,
    field_name text NOT NULL,
    value_a text NOT NULL,
    value_b text NOT NULL,
    source_a_id uuid,
    source_b_id uuid,
    confidence_a double precision,
    confidence_b double precision,
    resolution text DEFAULT 'unresolved'::text,
    resolution_note text,
    resolved_by text,
    resolved_at timestamp with time zone,
    status text DEFAULT 'detected'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: data_sources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.data_sources (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    code public.citext NOT NULL,
    name text NOT NULL,
    description text,
    source_type_id uuid NOT NULL,
    priority_id uuid NOT NULL,
    country_id uuid,
    is_verified boolean DEFAULT false NOT NULL,
    status_id bigint NOT NULL,
    version_number integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT data_sources_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE data_sources; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.data_sources IS 'Governed registry of concrete data sources feeding the knowledge base.';


--
-- Name: COLUMN data_sources.source_type_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.data_sources.source_type_id IS 'Category of the source (foreign key to source_types).';


--
-- Name: COLUMN data_sources.priority_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.data_sources.priority_id IS 'Trust priority for conflict resolution (foreign key to source_priorities).';


--
-- Name: COLUMN data_sources.country_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.data_sources.country_id IS 'Jurisdictional scope; NULL means global/unspecified (foreign key to countries).';


--
-- Name: COLUMN data_sources.is_verified; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.data_sources.is_verified IS 'True for institutionally trusted sources that may bypass per-record human review.';


--
-- Name: COLUMN data_sources.version_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.data_sources.version_number IS 'Monotonic governance/version counter; starts at 1, increments on governed change.';


--
-- Name: data_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.data_versions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    entity_type text NOT NULL,
    entity_id uuid NOT NULL,
    version_number integer DEFAULT 1 NOT NULL,
    data_snapshot jsonb NOT NULL,
    source_config_id uuid,
    change_summary text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: discovery_candidates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.discovery_candidates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    scan_job_id uuid,
    name text NOT NULL,
    brand text,
    barcode text,
    category text,
    country text DEFAULT 'SA'::text NOT NULL,
    market text DEFAULT 'packaged_food'::text NOT NULL,
    source_url text,
    source_reference text,
    source_retrieved_at timestamp with time zone,
    raw_data jsonb DEFAULT '{}'::jsonb,
    status text DEFAULT 'discovered'::text NOT NULL,
    normalized_name text,
    normalized_brand text,
    normalized_barcode text,
    matched_product_id uuid,
    match_confidence double precision,
    validation_errors jsonb DEFAULT '[]'::jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: entity_relationships; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.entity_relationships (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    subject_entity_type text NOT NULL,
    subject_id uuid NOT NULL,
    object_entity_type text NOT NULL,
    object_id uuid NOT NULL,
    relationship_type_id uuid NOT NULL,
    source_id uuid,
    evidence_type_id uuid,
    confidence_level numeric DEFAULT 0.5 NOT NULL,
    effective_from timestamp with time zone,
    effective_to timestamp with time zone,
    verified_at timestamp with time zone,
    approved_at timestamp with time zone,
    status_id bigint NOT NULL,
    version_number integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT entity_relationships_confidence_level_check CHECK (((confidence_level >= (0)::numeric) AND (confidence_level <= (1)::numeric))),
    CONSTRAINT entity_relationships_effective_period_check CHECK (((effective_to IS NULL) OR (effective_from IS NULL) OR (effective_to >= effective_from))),
    CONSTRAINT entity_relationships_no_self_loop_check CHECK (((subject_entity_type <> object_entity_type) OR (subject_id <> object_id))),
    CONSTRAINT entity_relationships_object_entity_type_check CHECK ((object_entity_type = ANY (ARRAY['companies'::text, 'brands'::text, 'products'::text, 'ingredients'::text, 'allergens'::text, 'health_flags'::text]))),
    CONSTRAINT entity_relationships_subject_entity_type_check CHECK ((subject_entity_type = ANY (ARRAY['companies'::text, 'brands'::text, 'products'::text, 'ingredients'::text, 'allergens'::text, 'health_flags'::text]))),
    CONSTRAINT entity_relationships_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE entity_relationships; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.entity_relationships IS 'Polymorphic knowledge-graph edges between canonical core entities.';


--
-- Name: COLUMN entity_relationships.subject_entity_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.entity_relationships.subject_entity_type IS 'Entity kind of the edge subject; restricted to the canonical core entities.';


--
-- Name: COLUMN entity_relationships.subject_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.entity_relationships.subject_id IS 'UUID of the subject entity; integrity enforced at the application/trigger layer (polymorphic endpoint).';


--
-- Name: COLUMN entity_relationships.object_entity_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.entity_relationships.object_entity_type IS 'Entity kind of the edge object; restricted to the canonical core entities.';


--
-- Name: COLUMN entity_relationships.object_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.entity_relationships.object_id IS 'UUID of the object entity; integrity enforced at the application/trigger layer (polymorphic endpoint).';


--
-- Name: COLUMN entity_relationships.relationship_type_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.entity_relationships.relationship_type_id IS 'Edge type (foreign key to relationship_types); the governed edge vocabulary.';


--
-- Name: COLUMN entity_relationships.version_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.entity_relationships.version_number IS 'Monotonic governance/version counter; starts at 1, increments on governed change.';


--
-- Name: entity_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.entity_versions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    entity_type text NOT NULL,
    entity_id uuid NOT NULL,
    version_number integer NOT NULL,
    history_table text NOT NULL,
    history_row_id uuid NOT NULL,
    version_status public.version_status DEFAULT 'draft'::public.version_status NOT NULL,
    change_set_id uuid,
    previous_version_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT entity_versions_history_table_check CHECK ((history_table <> ''::text)),
    CONSTRAINT entity_versions_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE entity_versions; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.entity_versions IS 'Generic registry of every published version across all history tables.';


--
-- Name: COLUMN entity_versions.entity_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.entity_versions.entity_type IS 'Canonical entity/table the version belongs to (text discriminator, no FK).';


--
-- Name: COLUMN entity_versions.entity_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.entity_versions.entity_id IS 'Canonical entity id the version belongs to.';


--
-- Name: COLUMN entity_versions.version_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.entity_versions.version_number IS 'Version number within that entity (unique with entity_type and entity_id).';


--
-- Name: COLUMN entity_versions.history_table; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.entity_versions.history_table IS 'Name of the history table holding the immutable snapshot (text discriminator, no FK).';


--
-- Name: COLUMN entity_versions.history_row_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.entity_versions.history_row_id IS 'Id of the immutable history row (tamper-evidence pointer for hash verification).';


--
-- Name: COLUMN entity_versions.version_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.entity_versions.version_status IS 'Version lifecycle: draft -> pending_approval -> approved -> superseded (existing version_status ENUM).';


--
-- Name: COLUMN entity_versions.previous_version_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.entity_versions.previous_version_id IS 'Self-reference to the immediately prior version registry row (applied in 0022).';


--
-- Name: evidence_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.evidence_types (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    code public.citext NOT NULL,
    name text NOT NULL,
    description text,
    display_order integer DEFAULT 0 NOT NULL,
    status_id bigint NOT NULL,
    version_number integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT evidence_types_display_order_check CHECK ((display_order >= 0)),
    CONSTRAINT evidence_types_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE evidence_types; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.evidence_types IS 'Governed registry of evidence kinds that back governed facts.';


--
-- Name: COLUMN evidence_types.code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.evidence_types.code IS 'Stable machine reference (snake_case), e.g. scientific_study, label_image.';


--
-- Name: COLUMN evidence_types.version_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.evidence_types.version_number IS 'Monotonic governance/version counter; starts at 1, increments on governed change.';


--
-- Name: halal_evidence; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.halal_evidence (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    status text DEFAULT 'UNKNOWN'::text NOT NULL,
    confidence double precision DEFAULT 0.0 NOT NULL,
    source_config_id uuid,
    evidence_type text,
    authority text,
    reasoning text,
    raw_evidence text,
    retrieved_at timestamp with time zone DEFAULT now() NOT NULL,
    is_current boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: health_conditions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.health_conditions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    code text NOT NULL,
    description text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: health_flag_translations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.health_flag_translations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    health_flag_id uuid NOT NULL,
    language_id uuid NOT NULL,
    name text NOT NULL,
    short_name text,
    display_name text NOT NULL,
    search_name text,
    description text,
    translation_status public.translation_status DEFAULT 'draft'::public.translation_status NOT NULL,
    version_number integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT health_flag_translations_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE health_flag_translations; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.health_flag_translations IS 'Per-language translations of health flags (unique per flag and language).';


--
-- Name: COLUMN health_flag_translations.name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.health_flag_translations.name IS 'Translated canonical name of the health flag.';


--
-- Name: COLUMN health_flag_translations.display_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.health_flag_translations.display_name IS 'User-facing label for the health flag in this language.';


--
-- Name: COLUMN health_flag_translations.search_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.health_flag_translations.search_name IS 'Normalized search variant (e.g. transliteration); NULL when not needed.';


--
-- Name: COLUMN health_flag_translations.translation_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.health_flag_translations.translation_status IS 'Governed quality lifecycle of this translation row.';


--
-- Name: health_flag_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.health_flag_types (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    code public.citext NOT NULL,
    name text NOT NULL,
    description text,
    display_order integer DEFAULT 0 NOT NULL,
    status_id bigint NOT NULL,
    version_number integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT health_flag_types_display_order_check CHECK ((display_order >= 0)),
    CONSTRAINT health_flag_types_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE health_flag_types; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.health_flag_types IS 'Governed registry of health/risk flag classes (business knowledge, not ENUM).';


--
-- Name: COLUMN health_flag_types.code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.health_flag_types.code IS 'Stable machine reference (snake_case), e.g. allergen, recall.';


--
-- Name: COLUMN health_flag_types.version_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.health_flag_types.version_number IS 'Monotonic governance/version counter; starts at 1, increments on governed change.';


--
-- Name: health_flags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.health_flags (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    health_flag_type_id uuid,
    internal_code public.citext NOT NULL,
    name text NOT NULL,
    description text,
    status_id bigint NOT NULL,
    source_id uuid,
    confidence_level numeric DEFAULT 0.5 NOT NULL,
    verified_at timestamp with time zone,
    approved_at timestamp with time zone,
    deprecated_at timestamp with time zone,
    version_number integer DEFAULT 1 NOT NULL,
    created_by uuid,
    approved_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT health_flags_confidence_level_check CHECK (((confidence_level >= (0)::numeric) AND (confidence_level <= (1)::numeric))),
    CONSTRAINT health_flags_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE health_flags; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.health_flags IS 'Canonical registry of concrete health/risk flags and claims.';


--
-- Name: COLUMN health_flags.health_flag_type_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.health_flags.health_flag_type_id IS 'Health/risk flag class (foreign key to health_flag_types); NULL when not yet classified.';


--
-- Name: COLUMN health_flags.internal_code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.health_flags.internal_code IS 'Stable internal machine reference (unique, citext).';


--
-- Name: COLUMN health_flags.confidence_level; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.health_flags.confidence_level IS 'Numeric fact confidence in [0,1]; the confidence_band ENUM is derived, never stored.';


--
-- Name: COLUMN health_flags.version_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.health_flags.version_number IS 'Monotonic governance/version counter; starts at 1, increments on governed change.';


--
-- Name: COLUMN health_flags.created_by; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.health_flags.created_by IS 'UUID of the actor that created the row; FK to the future auth service (none yet).';


--
-- Name: COLUMN health_flags.approved_by; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.health_flags.approved_by IS 'UUID of the actor that approved the row; FK to the future auth service (none yet).';


--
-- Name: health_flags_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.health_flags_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    original_entity_id uuid NOT NULL,
    version_number integer NOT NULL,
    previous_version_id uuid,
    change_set_id uuid,
    change_type public.update_type NOT NULL,
    change_reason text,
    changed_by uuid,
    approved_by uuid,
    source_id uuid,
    confidence_level numeric DEFAULT 0.5 NOT NULL,
    health_flag_type_id uuid,
    internal_code public.citext NOT NULL,
    name text NOT NULL,
    description text,
    status_id bigint NOT NULL,
    verified_at timestamp with time zone,
    approved_at timestamp with time zone,
    deprecated_at timestamp with time zone,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    effective_from timestamp with time zone DEFAULT now() NOT NULL,
    effective_to timestamp with time zone,
    superseded_at timestamp with time zone,
    snapshot_hash text NOT NULL,
    checksum text NOT NULL,
    version_status public.version_status DEFAULT 'draft'::public.version_status NOT NULL,
    CONSTRAINT health_flags_history_confidence_level_check CHECK (((confidence_level >= (0)::numeric) AND (confidence_level <= (1)::numeric))),
    CONSTRAINT health_flags_history_effective_window_check CHECK (((effective_to IS NULL) OR (effective_to >= effective_from))),
    CONSTRAINT health_flags_history_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE health_flags_history; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.health_flags_history IS 'Immutable version-history of health_flags (INSERT-only; one row per version).';


--
-- Name: COLUMN health_flags_history.original_entity_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.health_flags_history.original_entity_id IS 'Canonical health flag this version belongs to (foreign key to health_flags, applied in 0022).';


--
-- Name: COLUMN health_flags_history.previous_version_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.health_flags_history.previous_version_id IS 'Self-reference to the immediately prior version row; NULL for the first version.';


--
-- Name: COLUMN health_flags_history.change_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.health_flags_history.change_type IS 'Nature of the change recorded by this version (existing update_type ENUM).';


--
-- Name: COLUMN health_flags_history.health_flag_type_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.health_flags_history.health_flag_type_id IS 'Health/risk flag class at this version (foreign key to health_flag_types, applied in 0022).';


--
-- Name: COLUMN health_flags_history.snapshot_hash; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.health_flags_history.snapshot_hash IS 'SHA-256 of the snapshot columns (application-computed) to verify a stored version matches the original state.';


--
-- Name: COLUMN health_flags_history.checksum; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.health_flags_history.checksum IS 'Checksum of the full history row for tamper evidence.';


--
-- Name: COLUMN health_flags_history.version_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.health_flags_history.version_status IS 'Version lifecycle: draft -> pending_approval -> approved -> superseded (existing version_status ENUM).';


--
-- Name: image_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.image_types (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    code public.citext NOT NULL,
    name text NOT NULL,
    description text,
    display_order integer DEFAULT 0 NOT NULL,
    status_id bigint NOT NULL,
    version_number integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT image_types_display_order_check CHECK ((display_order >= 0)),
    CONSTRAINT image_types_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE image_types; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.image_types IS 'Governed registry of product image categories.';


--
-- Name: COLUMN image_types.version_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.image_types.version_number IS 'Monotonic governance/version counter; starts at 1, increments on governed change.';


--
-- Name: images; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.images (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    image_type_id uuid NOT NULL,
    source_id uuid,
    language_id uuid,
    storage_uri text NOT NULL,
    content_hash text NOT NULL,
    mime_type text NOT NULL,
    width integer,
    height integer,
    file_size bigint DEFAULT 0 NOT NULL,
    status_id bigint NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    version_number integer DEFAULT 1 NOT NULL,
    created_by uuid,
    updated_by uuid,
    reviewed_by uuid,
    approved_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT images_dimension_height_check CHECK (((height IS NULL) OR (height > 0))),
    CONSTRAINT images_dimension_width_check CHECK (((width IS NULL) OR (width > 0))),
    CONSTRAINT images_file_size_check CHECK ((file_size >= 0)),
    CONSTRAINT images_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE images; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.images IS 'Canonical registry of governed media records (references, not file storage).';


--
-- Name: COLUMN images.image_type_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.images.image_type_id IS 'Classification of the image (foreign key to image_types): primary, front, back, nutrition panel, ...';


--
-- Name: COLUMN images.source_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.images.source_id IS 'Provenance of the media record (foreign key to data_sources).';


--
-- Name: COLUMN images.language_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.images.language_id IS 'Language scope of the media (foreign key to languages); NULL = language-neutral.';


--
-- Name: COLUMN images.storage_uri; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.images.storage_uri IS 'Reference to the stored object in the object store (unique; never the bytes themselves).';


--
-- Name: COLUMN images.content_hash; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.images.content_hash IS 'Content fingerprint (SHA-256) used for deduplication (unique); the history header column checksum is reserved for row tamper-evidence.';


--
-- Name: COLUMN images.mime_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.images.mime_type IS 'Media type of the stored object (e.g. image/jpeg).';


--
-- Name: COLUMN images.file_size; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.images.file_size IS 'Size of the stored object in bytes.';


--
-- Name: COLUMN images.status_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.images.status_id IS 'Lifecycle of the media record (foreign key to lifecycle_statuses; ADR-008).';


--
-- Name: COLUMN images.metadata; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.images.metadata IS 'Optional JSONB metadata (EXIF/OCR/context); additive, never queried relationally.';


--
-- Name: COLUMN images.version_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.images.version_number IS 'Monotonic governance/version counter; starts at 1, increments on governed change.';


--
-- Name: images_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.images_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    original_entity_id uuid NOT NULL,
    version_number integer NOT NULL,
    previous_version_id uuid,
    change_set_id uuid,
    change_type public.update_type NOT NULL,
    change_reason text,
    changed_by uuid,
    approved_by uuid,
    source_id uuid,
    confidence_level numeric DEFAULT 0.5 NOT NULL,
    image_type_id uuid NOT NULL,
    language_id uuid,
    storage_uri text NOT NULL,
    content_hash text NOT NULL,
    mime_type text NOT NULL,
    width integer,
    height integer,
    file_size bigint DEFAULT 0 NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    status_id bigint NOT NULL,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    effective_from timestamp with time zone DEFAULT now() NOT NULL,
    effective_to timestamp with time zone,
    superseded_at timestamp with time zone,
    snapshot_hash text NOT NULL,
    checksum text NOT NULL,
    version_status public.version_status DEFAULT 'draft'::public.version_status NOT NULL,
    CONSTRAINT images_history_confidence_level_check CHECK (((confidence_level >= (0)::numeric) AND (confidence_level <= (1)::numeric))),
    CONSTRAINT images_history_dimension_height_check CHECK (((height IS NULL) OR (height > 0))),
    CONSTRAINT images_history_dimension_width_check CHECK (((width IS NULL) OR (width > 0))),
    CONSTRAINT images_history_effective_window_check CHECK (((effective_to IS NULL) OR (effective_to >= effective_from))),
    CONSTRAINT images_history_file_size_check CHECK ((file_size >= 0)),
    CONSTRAINT images_history_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE images_history; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.images_history IS 'Immutable version-history of images (INSERT-only; one row per version).';


--
-- Name: COLUMN images_history.original_entity_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.images_history.original_entity_id IS 'Canonical image this version belongs to (foreign key to images, applied in 0027).';


--
-- Name: COLUMN images_history.previous_version_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.images_history.previous_version_id IS 'Self-reference to the immediately prior version row; NULL for the first version.';


--
-- Name: COLUMN images_history.change_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.images_history.change_type IS 'Nature of the change recorded by this version (existing update_type ENUM).';


--
-- Name: COLUMN images_history.content_hash; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.images_history.content_hash IS 'Content fingerprint of the image at this version (SHA-256).';


--
-- Name: COLUMN images_history.snapshot_hash; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.images_history.snapshot_hash IS 'SHA-256 of the snapshot columns (application-computed) to verify a stored version matches the original state.';


--
-- Name: COLUMN images_history.checksum; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.images_history.checksum IS 'Checksum of the full history row for tamper evidence.';


--
-- Name: COLUMN images_history.version_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.images_history.version_status IS 'Version lifecycle: draft -> pending_approval -> approved -> superseded (existing version_status ENUM).';


--
-- Name: ingredient_aliases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ingredient_aliases (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    ingredient_id uuid NOT NULL,
    alias text NOT NULL,
    language_id uuid,
    relationship_type_id uuid NOT NULL,
    source_id uuid,
    evidence_type_id uuid,
    confidence_level numeric DEFAULT 0.5 NOT NULL,
    effective_from timestamp with time zone,
    effective_to timestamp with time zone,
    verified_at timestamp with time zone,
    approved_at timestamp with time zone,
    status_id bigint NOT NULL,
    version_number integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT ingredient_aliases_alias_not_blank_check CHECK ((alias <> ''::text)),
    CONSTRAINT ingredient_aliases_confidence_level_check CHECK (((confidence_level >= (0)::numeric) AND (confidence_level <= (1)::numeric))),
    CONSTRAINT ingredient_aliases_effective_period_check CHECK (((effective_to IS NULL) OR (effective_from IS NULL) OR (effective_to >= effective_from))),
    CONSTRAINT ingredient_aliases_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE ingredient_aliases; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ingredient_aliases IS 'Alternate accepted names for an ingredient, for matching and search.';


--
-- Name: COLUMN ingredient_aliases.alias; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ingredient_aliases.alias IS 'Alternate accepted name (e.g. E621, monosodium glutamate); never blank.';


--
-- Name: COLUMN ingredient_aliases.language_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ingredient_aliases.language_id IS 'Language of a transliteration alias; NULL means language-neutral.';


--
-- Name: COLUMN ingredient_aliases.relationship_type_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ingredient_aliases.relationship_type_id IS 'Alias kind: synonym, e_number, transliteration, ... (relationship_types).';


--
-- Name: COLUMN ingredient_aliases.version_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ingredient_aliases.version_number IS 'Monotonic governance/version counter; starts at 1, increments on governed change.';


--
-- Name: ingredient_allergens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ingredient_allergens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    ingredient_id uuid NOT NULL,
    allergen_id uuid NOT NULL,
    relationship_type_id uuid NOT NULL,
    source_id uuid,
    evidence_type_id uuid,
    confidence_level numeric DEFAULT 0.5 NOT NULL,
    effective_from timestamp with time zone,
    effective_to timestamp with time zone,
    verified_at timestamp with time zone,
    approved_at timestamp with time zone,
    status_id bigint NOT NULL,
    version_number integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT ingredient_allergens_confidence_level_check CHECK (((confidence_level >= (0)::numeric) AND (confidence_level <= (1)::numeric))),
    CONSTRAINT ingredient_allergens_effective_period_check CHECK (((effective_to IS NULL) OR (effective_from IS NULL) OR (effective_to >= effective_from))),
    CONSTRAINT ingredient_allergens_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE ingredient_allergens; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ingredient_allergens IS 'Ingredient-to-allergen relationship (declared and precautionary).';


--
-- Name: COLUMN ingredient_allergens.relationship_type_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ingredient_allergens.relationship_type_id IS 'Assertion kind: contains_allergen vs. may_contain_allergen (relationship_types).';


--
-- Name: COLUMN ingredient_allergens.version_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ingredient_allergens.version_number IS 'Monotonic governance/version counter; starts at 1, increments on governed change.';


--
-- Name: ingredient_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ingredient_categories (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    code public.citext NOT NULL,
    name text NOT NULL,
    description text,
    parent_id uuid,
    display_order integer DEFAULT 0 NOT NULL,
    status_id bigint NOT NULL,
    version_number integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT ingredient_categories_display_order_check CHECK ((display_order >= 0)),
    CONSTRAINT ingredient_categories_parent_not_self_check CHECK (((parent_id IS NULL) OR (parent_id <> id))),
    CONSTRAINT ingredient_categories_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE ingredient_categories; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ingredient_categories IS 'Governed hierarchical taxonomy of ingredient categories (self-referencing parent_id).';


--
-- Name: COLUMN ingredient_categories.code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ingredient_categories.code IS 'Stable machine reference (snake_case).';


--
-- Name: COLUMN ingredient_categories.parent_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ingredient_categories.parent_id IS 'Optional parent category (self-reference); NULL for taxonomy roots.';


--
-- Name: COLUMN ingredient_categories.version_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ingredient_categories.version_number IS 'Monotonic governance/version counter; starts at 1, increments on governed change.';


--
-- Name: ingredient_categories_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ingredient_categories_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    original_entity_id uuid NOT NULL,
    version_number integer NOT NULL,
    previous_version_id uuid,
    change_set_id uuid,
    change_type public.update_type NOT NULL,
    change_reason text,
    changed_by uuid,
    approved_by uuid,
    source_id uuid,
    confidence_level numeric DEFAULT 0.5 NOT NULL,
    code public.citext NOT NULL,
    name text NOT NULL,
    description text,
    parent_id uuid,
    display_order integer DEFAULT 0 NOT NULL,
    status_id bigint NOT NULL,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    effective_from timestamp with time zone DEFAULT now() NOT NULL,
    effective_to timestamp with time zone,
    superseded_at timestamp with time zone,
    snapshot_hash text NOT NULL,
    checksum text NOT NULL,
    version_status public.version_status DEFAULT 'draft'::public.version_status NOT NULL,
    CONSTRAINT ingredient_categories_history_confidence_level_check CHECK (((confidence_level >= (0)::numeric) AND (confidence_level <= (1)::numeric))),
    CONSTRAINT ingredient_categories_history_display_order_check CHECK ((display_order >= 0)),
    CONSTRAINT ingredient_categories_history_effective_window_check CHECK (((effective_to IS NULL) OR (effective_to >= effective_from))),
    CONSTRAINT ingredient_categories_history_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE ingredient_categories_history; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ingredient_categories_history IS 'Immutable version-history of ingredient_categories (INSERT-only; one row per version).';


--
-- Name: COLUMN ingredient_categories_history.original_entity_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ingredient_categories_history.original_entity_id IS 'Canonical ingredient category this version belongs to (foreign key to ingredient_categories, applied in 0022).';


--
-- Name: COLUMN ingredient_categories_history.previous_version_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ingredient_categories_history.previous_version_id IS 'Self-reference to the immediately prior version row; NULL for the first version.';


--
-- Name: COLUMN ingredient_categories_history.change_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ingredient_categories_history.change_type IS 'Nature of the change recorded by this version (existing update_type ENUM).';


--
-- Name: COLUMN ingredient_categories_history.parent_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ingredient_categories_history.parent_id IS 'Taxonomy parent at this version (self-reference to ingredient_categories, applied in 0022); NULL for taxonomy roots.';


--
-- Name: COLUMN ingredient_categories_history.snapshot_hash; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ingredient_categories_history.snapshot_hash IS 'SHA-256 of the snapshot columns (application-computed) to verify a stored version matches the original state.';


--
-- Name: COLUMN ingredient_categories_history.checksum; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ingredient_categories_history.checksum IS 'Checksum of the full history row for tamper evidence.';


--
-- Name: COLUMN ingredient_categories_history.version_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ingredient_categories_history.version_status IS 'Version lifecycle: draft -> pending_approval -> approved -> superseded (existing version_status ENUM).';


--
-- Name: ingredient_health_flags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ingredient_health_flags (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    ingredient_id uuid NOT NULL,
    health_flag_id uuid NOT NULL,
    relationship_type_id uuid NOT NULL,
    source_id uuid,
    evidence_type_id uuid,
    confidence_level numeric DEFAULT 0.5 NOT NULL,
    effective_from timestamp with time zone,
    effective_to timestamp with time zone,
    verified_at timestamp with time zone,
    approved_at timestamp with time zone,
    status_id bigint NOT NULL,
    version_number integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT ingredient_health_flags_confidence_level_check CHECK (((confidence_level >= (0)::numeric) AND (confidence_level <= (1)::numeric))),
    CONSTRAINT ingredient_health_flags_effective_period_check CHECK (((effective_to IS NULL) OR (effective_from IS NULL) OR (effective_to >= effective_from))),
    CONSTRAINT ingredient_health_flags_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE ingredient_health_flags; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ingredient_health_flags IS 'Ingredient-to-health-flag relationship (claims, warnings, risks).';


--
-- Name: COLUMN ingredient_health_flags.relationship_type_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ingredient_health_flags.relationship_type_id IS 'Kind of flag assertion (has_health_flag, warns_about, ...).';


--
-- Name: COLUMN ingredient_health_flags.version_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ingredient_health_flags.version_number IS 'Monotonic governance/version counter; starts at 1, increments on governed change.';


--
-- Name: ingredient_search_index; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ingredient_search_index (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    ingredient_id uuid NOT NULL,
    search_name text NOT NULL,
    search_text text NOT NULL,
    search_tokens text[] DEFAULT '{}'::text[] NOT NULL,
    language_codes public.citext[] DEFAULT '{}'::public.citext[] NOT NULL,
    search_rank numeric DEFAULT 0 NOT NULL,
    generated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ingredient_search_index_search_rank_check CHECK ((search_rank >= (0)::numeric))
);


--
-- Name: TABLE ingredient_search_index; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ingredient_search_index IS 'Derived, rebuildable search index for ingredients (read model; no FK to ingredients).';


--
-- Name: COLUMN ingredient_search_index.ingredient_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ingredient_search_index.ingredient_id IS 'Logical reference to ingredients.id; NO foreign key - the search layer is disposable and rebuildable.';


--
-- Name: COLUMN ingredient_search_index.search_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ingredient_search_index.search_name IS 'Normalized primary searchable name (application-built from canonical name/translations).';


--
-- Name: COLUMN ingredient_search_index.search_text; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ingredient_search_index.search_text IS 'Normalized concatenated searchable text: description, category, aliases.';


--
-- Name: COLUMN ingredient_search_index.search_tokens; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ingredient_search_index.search_tokens IS 'Language-independent normalized search tokens (folded, accent-stripped).';


--
-- Name: COLUMN ingredient_search_index.language_codes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ingredient_search_index.language_codes IS 'Languages covered by the searchable text (citext codes, e.g. {ar,en}).';


--
-- Name: COLUMN ingredient_search_index.search_rank; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ingredient_search_index.search_rank IS 'Ranking helper >= 0; higher means the result is promoted.';


--
-- Name: COLUMN ingredient_search_index.generated_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ingredient_search_index.generated_at IS 'Timestamp when this search row was generated or refreshed (rebuild tracking).';


--
-- Name: ingredient_translations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ingredient_translations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    ingredient_id uuid NOT NULL,
    language_id uuid NOT NULL,
    name text NOT NULL,
    short_name text,
    display_name text NOT NULL,
    search_name text,
    description text,
    translation_status public.translation_status DEFAULT 'draft'::public.translation_status NOT NULL,
    version_number integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT ingredient_translations_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE ingredient_translations; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ingredient_translations IS 'Per-language translations of ingredients (unique per ingredient and language).';


--
-- Name: COLUMN ingredient_translations.name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ingredient_translations.name IS 'Translated canonical name of the ingredient.';


--
-- Name: COLUMN ingredient_translations.display_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ingredient_translations.display_name IS 'User-facing label for the ingredient in this language.';


--
-- Name: COLUMN ingredient_translations.search_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ingredient_translations.search_name IS 'Normalized search variant (e.g. transliteration); NULL when not needed.';


--
-- Name: COLUMN ingredient_translations.translation_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ingredient_translations.translation_status IS 'Governed quality lifecycle of this translation row.';


--
-- Name: ingredients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ingredients (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    internal_code public.citext NOT NULL,
    name text NOT NULL,
    description text,
    status_id bigint NOT NULL,
    source_id uuid,
    confidence_level numeric DEFAULT 0.5 NOT NULL,
    verified_at timestamp with time zone,
    approved_at timestamp with time zone,
    deprecated_at timestamp with time zone,
    version_number integer DEFAULT 1 NOT NULL,
    created_by uuid,
    approved_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT ingredients_confidence_level_check CHECK (((confidence_level >= (0)::numeric) AND (confidence_level <= (1)::numeric))),
    CONSTRAINT ingredients_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE ingredients; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ingredients IS 'Canonical registry of ingredients (governed, provenance-tracked core entity).';


--
-- Name: COLUMN ingredients.internal_code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ingredients.internal_code IS 'Stable internal machine reference (unique, citext).';


--
-- Name: COLUMN ingredients.confidence_level; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ingredients.confidence_level IS 'Numeric fact confidence in [0,1]; the confidence_band ENUM is derived, never stored.';


--
-- Name: COLUMN ingredients.version_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ingredients.version_number IS 'Monotonic governance/version counter; starts at 1, increments on governed change.';


--
-- Name: COLUMN ingredients.created_by; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ingredients.created_by IS 'UUID of the actor that created the row; FK to the future auth service (none yet).';


--
-- Name: COLUMN ingredients.approved_by; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ingredients.approved_by IS 'UUID of the actor that approved the row; FK to the future auth service (none yet).';


--
-- Name: ingredients_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ingredients_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    original_entity_id uuid NOT NULL,
    version_number integer NOT NULL,
    previous_version_id uuid,
    change_set_id uuid,
    change_type public.update_type NOT NULL,
    change_reason text,
    changed_by uuid,
    approved_by uuid,
    source_id uuid,
    confidence_level numeric DEFAULT 0.5 NOT NULL,
    internal_code public.citext NOT NULL,
    name text NOT NULL,
    description text,
    status_id bigint NOT NULL,
    verified_at timestamp with time zone,
    approved_at timestamp with time zone,
    deprecated_at timestamp with time zone,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    effective_from timestamp with time zone DEFAULT now() NOT NULL,
    effective_to timestamp with time zone,
    superseded_at timestamp with time zone,
    snapshot_hash text NOT NULL,
    checksum text NOT NULL,
    version_status public.version_status DEFAULT 'draft'::public.version_status NOT NULL,
    CONSTRAINT ingredients_history_confidence_level_check CHECK (((confidence_level >= (0)::numeric) AND (confidence_level <= (1)::numeric))),
    CONSTRAINT ingredients_history_effective_window_check CHECK (((effective_to IS NULL) OR (effective_to >= effective_from))),
    CONSTRAINT ingredients_history_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE ingredients_history; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ingredients_history IS 'Immutable version-history of ingredients (INSERT-only; one row per version).';


--
-- Name: COLUMN ingredients_history.original_entity_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ingredients_history.original_entity_id IS 'Canonical ingredient this version belongs to (foreign key to ingredients, applied in 0022).';


--
-- Name: COLUMN ingredients_history.previous_version_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ingredients_history.previous_version_id IS 'Self-reference to the immediately prior version row; NULL for the first version.';


--
-- Name: COLUMN ingredients_history.change_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ingredients_history.change_type IS 'Nature of the change recorded by this version (existing update_type ENUM).';


--
-- Name: COLUMN ingredients_history.snapshot_hash; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ingredients_history.snapshot_hash IS 'SHA-256 of the snapshot columns (application-computed) to verify a stored version matches the original state.';


--
-- Name: COLUMN ingredients_history.checksum; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ingredients_history.checksum IS 'Checksum of the full history row for tamper evidence.';


--
-- Name: COLUMN ingredients_history.version_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ingredients_history.version_status IS 'Version lifecycle: draft -> pending_approval -> approved -> superseded (existing version_status ENUM).';


--
-- Name: languages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.languages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    code public.citext NOT NULL,
    name text NOT NULL,
    native_name text NOT NULL,
    is_rtl boolean DEFAULT false NOT NULL,
    status_id bigint NOT NULL,
    version_number integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT languages_code_check CHECK (((char_length((code)::text) >= 2) AND (char_length((code)::text) <= 10))),
    CONSTRAINT languages_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE languages; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.languages IS 'Governed registry of supported platform languages (Arabic + English day one).';


--
-- Name: COLUMN languages.code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.languages.code IS 'ISO 639-1 two-letter code where available; BCP-47 tag for variants.';


--
-- Name: COLUMN languages.name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.languages.name IS 'Canonical English working name; display translations arrive with the i18n milestone.';


--
-- Name: COLUMN languages.native_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.languages.native_name IS 'Endonym of the language in its own script (e.g. العربية).';


--
-- Name: COLUMN languages.is_rtl; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.languages.is_rtl IS 'True for right-to-left scripts.';


--
-- Name: COLUMN languages.version_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.languages.version_number IS 'Monotonic governance/version counter; starts at 1, increments on governed change.';


--
-- Name: lifecycle_statuses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lifecycle_statuses (
    id bigint NOT NULL,
    code public.citext NOT NULL,
    name text NOT NULL,
    description text,
    display_order integer DEFAULT 0 NOT NULL,
    version_number integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT lifecycle_statuses_display_order_check CHECK ((display_order >= 0)),
    CONSTRAINT lifecycle_statuses_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE lifecycle_statuses; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.lifecycle_statuses IS 'Shared non-destructive lifecycle vocabulary (ACTIVE, DEPRECATED, ARCHIVED); the status authority for every lookup table.';


--
-- Name: COLUMN lifecycle_statuses.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.lifecycle_statuses.id IS 'BIGINT identity key (Architecture Authority directive; exception to the UUID convention, ADR-008).';


--
-- Name: COLUMN lifecycle_statuses.code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.lifecycle_statuses.code IS 'Stable machine reference: ACTIVE, DEPRECATED, ARCHIVED; future states are data inserts.';


--
-- Name: COLUMN lifecycle_statuses.version_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.lifecycle_statuses.version_number IS 'Monotonic governance/version counter; starts at 1, increments on governed change.';


--
-- Name: lifecycle_statuses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.lifecycle_statuses ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.lifecycle_statuses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: measurement_bases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.measurement_bases (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    code public.citext NOT NULL,
    name text NOT NULL,
    description text,
    display_order integer DEFAULT 0 NOT NULL,
    status_id bigint NOT NULL,
    version_number integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT measurement_bases_display_order_check CHECK ((display_order >= 0)),
    CONSTRAINT measurement_bases_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE measurement_bases; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.measurement_bases IS 'Governed registry of nutrition measurement bases (per_100g, per_serving, per_package, ...).';


--
-- Name: COLUMN measurement_bases.code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.measurement_bases.code IS 'Stable machine reference (snake_case, unique); seed vocabulary belongs to Phase 8.';


--
-- Name: COLUMN measurement_bases.name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.measurement_bases.name IS 'Canonical English name of the measurement basis.';


--
-- Name: COLUMN measurement_bases.display_order; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.measurement_bases.display_order IS 'Stable ordering for reference pickers; non-negative.';


--
-- Name: COLUMN measurement_bases.status_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.measurement_bases.status_id IS 'Lifecycle of the basis (foreign key to lifecycle_statuses; ADR-008).';


--
-- Name: COLUMN measurement_bases.version_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.measurement_bases.version_number IS 'Monotonic governance/version counter; starts at 1, increments on governed change.';


--
-- Name: nutrition_type_translations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nutrition_type_translations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    nutrition_type_id uuid NOT NULL,
    language_id uuid NOT NULL,
    name text NOT NULL,
    short_name text,
    display_name text NOT NULL,
    search_name text,
    description text,
    translation_status public.translation_status DEFAULT 'draft'::public.translation_status NOT NULL,
    version_number integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT nutrition_type_translations_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE nutrition_type_translations; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.nutrition_type_translations IS 'Per-language translations of nutrition fact types (unique per type and language).';


--
-- Name: COLUMN nutrition_type_translations.name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.nutrition_type_translations.name IS 'Translated canonical name of the nutrition fact type.';


--
-- Name: COLUMN nutrition_type_translations.display_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.nutrition_type_translations.display_name IS 'User-facing label for the nutrition fact type in this language.';


--
-- Name: COLUMN nutrition_type_translations.search_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.nutrition_type_translations.search_name IS 'Normalized search variant; NULL when not needed.';


--
-- Name: COLUMN nutrition_type_translations.translation_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.nutrition_type_translations.translation_status IS 'Governed quality lifecycle of this translation row.';


--
-- Name: nutrition_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nutrition_types (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    code public.citext NOT NULL,
    name text NOT NULL,
    description text,
    display_order integer DEFAULT 0 NOT NULL,
    status_id bigint NOT NULL,
    version_number integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT nutrition_types_display_order_check CHECK ((display_order >= 0)),
    CONSTRAINT nutrition_types_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE nutrition_types; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.nutrition_types IS 'Governed registry of nutrition fact types (business knowledge, not ENUM).';


--
-- Name: COLUMN nutrition_types.code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.nutrition_types.code IS 'Stable machine reference (snake_case), e.g. energy, protein, sodium.';


--
-- Name: COLUMN nutrition_types.version_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.nutrition_types.version_number IS 'Monotonic governance/version counter; starts at 1, increments on governed change.';


--
-- Name: nutrition_types_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nutrition_types_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    original_entity_id uuid NOT NULL,
    version_number integer NOT NULL,
    previous_version_id uuid,
    change_set_id uuid,
    change_type public.update_type NOT NULL,
    change_reason text,
    changed_by uuid,
    approved_by uuid,
    source_id uuid,
    confidence_level numeric DEFAULT 0.5 NOT NULL,
    code public.citext NOT NULL,
    name text NOT NULL,
    description text,
    display_order integer DEFAULT 0 NOT NULL,
    status_id bigint NOT NULL,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    effective_from timestamp with time zone DEFAULT now() NOT NULL,
    effective_to timestamp with time zone,
    superseded_at timestamp with time zone,
    snapshot_hash text NOT NULL,
    checksum text NOT NULL,
    version_status public.version_status DEFAULT 'draft'::public.version_status NOT NULL,
    CONSTRAINT nutrition_types_history_confidence_level_check CHECK (((confidence_level >= (0)::numeric) AND (confidence_level <= (1)::numeric))),
    CONSTRAINT nutrition_types_history_display_order_check CHECK ((display_order >= 0)),
    CONSTRAINT nutrition_types_history_effective_window_check CHECK (((effective_to IS NULL) OR (effective_to >= effective_from))),
    CONSTRAINT nutrition_types_history_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE nutrition_types_history; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.nutrition_types_history IS 'Immutable version-history of nutrition_types (INSERT-only; one row per version).';


--
-- Name: COLUMN nutrition_types_history.original_entity_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.nutrition_types_history.original_entity_id IS 'Canonical nutrition type this version belongs to (foreign key to nutrition_types, applied in 0022).';


--
-- Name: COLUMN nutrition_types_history.previous_version_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.nutrition_types_history.previous_version_id IS 'Self-reference to the immediately prior version row; NULL for the first version.';


--
-- Name: COLUMN nutrition_types_history.change_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.nutrition_types_history.change_type IS 'Nature of the change recorded by this version (existing update_type ENUM).';


--
-- Name: COLUMN nutrition_types_history.code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.nutrition_types_history.code IS 'Governed machine code at this version (snake_case); not unique in history because several versions share one entity code.';


--
-- Name: COLUMN nutrition_types_history.snapshot_hash; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.nutrition_types_history.snapshot_hash IS 'SHA-256 of the snapshot columns (application-computed) to verify a stored version matches the original state.';


--
-- Name: COLUMN nutrition_types_history.checksum; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.nutrition_types_history.checksum IS 'Checksum of the full history row for tamper evidence.';


--
-- Name: COLUMN nutrition_types_history.version_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.nutrition_types_history.version_status IS 'Version lifecycle: draft -> pending_approval -> approved -> superseded (existing version_status ENUM).';


--
-- Name: package_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.package_types (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    code public.citext NOT NULL,
    name text NOT NULL,
    description text,
    display_order integer DEFAULT 0 NOT NULL,
    status_id bigint NOT NULL,
    version_number integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT package_types_display_order_check CHECK ((display_order >= 0)),
    CONSTRAINT package_types_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE package_types; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.package_types IS 'Governed registry of packaging types.';


--
-- Name: COLUMN package_types.display_order; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.package_types.display_order IS 'Stable ordering for reference pickers; non-negative.';


--
-- Name: COLUMN package_types.version_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.package_types.version_number IS 'Monotonic governance/version counter; starts at 1, increments on governed change.';


--
-- Name: permission_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permission_types (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    code public.citext NOT NULL,
    name text NOT NULL,
    description text,
    display_order integer DEFAULT 0 NOT NULL,
    status_id bigint NOT NULL,
    version_number integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT permission_types_display_order_check CHECK ((display_order >= 0)),
    CONSTRAINT permission_types_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE permission_types; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.permission_types IS 'Governed registry of permission classes (read, write, approve, manage, ...).';


--
-- Name: COLUMN permission_types.code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.permission_types.code IS 'Stable machine reference (snake_case), e.g. read, write, approve, audit.';


--
-- Name: COLUMN permission_types.version_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.permission_types.version_number IS 'Monotonic governance/version counter; starts at 1, increments on governed change.';


--
-- Name: product_allergens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_allergens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    allergen_id uuid NOT NULL,
    relationship_type_id uuid NOT NULL,
    source_id uuid,
    evidence_type_id uuid,
    confidence_level numeric DEFAULT 0.5 NOT NULL,
    effective_from timestamp with time zone,
    effective_to timestamp with time zone,
    verified_at timestamp with time zone,
    approved_at timestamp with time zone,
    status_id bigint NOT NULL,
    version_number integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT product_allergens_confidence_level_check CHECK (((confidence_level >= (0)::numeric) AND (confidence_level <= (1)::numeric))),
    CONSTRAINT product_allergens_effective_period_check CHECK (((effective_to IS NULL) OR (effective_from IS NULL) OR (effective_to >= effective_from))),
    CONSTRAINT product_allergens_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE product_allergens; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.product_allergens IS 'Product-to-allergen exposure relationship (declared and precautionary).';


--
-- Name: COLUMN product_allergens.relationship_type_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_allergens.relationship_type_id IS 'Assertion kind: contains_allergen vs. may_contain_allergen (relationship_types).';


--
-- Name: COLUMN product_allergens.effective_from; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_allergens.effective_from IS 'Start of validity for this assertion; NULL = from creation.';


--
-- Name: COLUMN product_allergens.effective_to; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_allergens.effective_to IS 'End of validity for this assertion; NULL = currently effective.';


--
-- Name: COLUMN product_allergens.version_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_allergens.version_number IS 'Monotonic governance/version counter; starts at 1, increments on governed change.';


--
-- Name: product_barcodes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_barcodes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    barcode_id uuid NOT NULL,
    relationship_type_id uuid NOT NULL,
    source_id uuid,
    evidence_type_id uuid,
    confidence_level numeric DEFAULT 0.5 NOT NULL,
    effective_from timestamp with time zone,
    effective_to timestamp with time zone,
    verified_at timestamp with time zone,
    approved_at timestamp with time zone,
    status_id bigint NOT NULL,
    version_number integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT product_barcodes_confidence_level_check CHECK (((confidence_level >= (0)::numeric) AND (confidence_level <= (1)::numeric))),
    CONSTRAINT product_barcodes_effective_period_check CHECK (((effective_to IS NULL) OR (effective_from IS NULL) OR (effective_to >= effective_from))),
    CONSTRAINT product_barcodes_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE product_barcodes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.product_barcodes IS 'Product-to-barcode association relationship (many barcodes per product).';


--
-- Name: COLUMN product_barcodes.product_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_barcodes.product_id IS 'Owning product (foreign key to products).';


--
-- Name: COLUMN product_barcodes.barcode_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_barcodes.barcode_id IS 'Connected canonical barcode (foreign key to barcodes); the barcode row is never duplicated.';


--
-- Name: COLUMN product_barcodes.relationship_type_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_barcodes.relationship_type_id IS 'Kind of association (foreign key to relationship_types: primary_barcode, pack_size_variant, ...).';


--
-- Name: COLUMN product_barcodes.effective_from; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_barcodes.effective_from IS 'Start of validity for this association; NULL = from creation.';


--
-- Name: COLUMN product_barcodes.effective_to; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_barcodes.effective_to IS 'End of validity for this association; NULL = currently effective.';


--
-- Name: COLUMN product_barcodes.version_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_barcodes.version_number IS 'Monotonic governance/version counter; starts at 1, increments on governed change.';


--
-- Name: product_barcodes_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_barcodes_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    original_entity_id uuid NOT NULL,
    version_number integer NOT NULL,
    previous_version_id uuid,
    change_set_id uuid,
    change_type public.update_type NOT NULL,
    change_reason text,
    changed_by uuid,
    approved_by uuid,
    source_id uuid,
    confidence_level numeric DEFAULT 0.5 NOT NULL,
    product_id uuid NOT NULL,
    barcode_id uuid NOT NULL,
    relationship_type_id uuid NOT NULL,
    evidence_type_id uuid,
    effective_from timestamp with time zone,
    effective_to timestamp with time zone,
    verified_at timestamp with time zone,
    approved_at timestamp with time zone,
    status_id bigint NOT NULL,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    superseded_at timestamp with time zone,
    snapshot_hash text NOT NULL,
    checksum text NOT NULL,
    version_status public.version_status DEFAULT 'draft'::public.version_status NOT NULL,
    CONSTRAINT product_barcodes_history_confidence_level_check CHECK (((confidence_level >= (0)::numeric) AND (confidence_level <= (1)::numeric))),
    CONSTRAINT product_barcodes_history_effective_window_check CHECK (((effective_to IS NULL) OR (effective_to >= effective_from))),
    CONSTRAINT product_barcodes_history_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE product_barcodes_history; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.product_barcodes_history IS 'Immutable version-history of product_barcodes associations (INSERT-only; one row per version).';


--
-- Name: COLUMN product_barcodes_history.original_entity_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_barcodes_history.original_entity_id IS 'Product-to-barcode association this version belongs to (foreign key to product_barcodes, applied in 0034).';


--
-- Name: COLUMN product_barcodes_history.previous_version_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_barcodes_history.previous_version_id IS 'Self-reference to the immediately prior version row; NULL for the first version.';


--
-- Name: COLUMN product_barcodes_history.change_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_barcodes_history.change_type IS 'Nature of the change recorded by this version (existing update_type ENUM).';


--
-- Name: COLUMN product_barcodes_history.snapshot_hash; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_barcodes_history.snapshot_hash IS 'SHA-256 of the snapshot columns, computed by capture_entity_history() at capture time.';


--
-- Name: COLUMN product_barcodes_history.checksum; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_barcodes_history.checksum IS 'Checksum of the full history row for tamper evidence, computed by capture_entity_history().';


--
-- Name: COLUMN product_barcodes_history.version_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_barcodes_history.version_status IS 'Version lifecycle: draft -> pending_approval -> approved -> superseded (existing version_status ENUM).';


--
-- Name: product_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_categories (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    code public.citext NOT NULL,
    name text NOT NULL,
    description text,
    parent_id uuid,
    display_order integer DEFAULT 0 NOT NULL,
    status_id bigint NOT NULL,
    version_number integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT product_categories_display_order_check CHECK ((display_order >= 0)),
    CONSTRAINT product_categories_parent_not_self_check CHECK (((parent_id IS NULL) OR (parent_id <> id))),
    CONSTRAINT product_categories_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE product_categories; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.product_categories IS 'Governed hierarchical taxonomy of product categories (self-referencing parent_id).';


--
-- Name: COLUMN product_categories.code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_categories.code IS 'Stable machine reference (snake_case).';


--
-- Name: COLUMN product_categories.parent_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_categories.parent_id IS 'Optional parent category (self-reference); NULL for taxonomy roots.';


--
-- Name: COLUMN product_categories.version_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_categories.version_number IS 'Monotonic governance/version counter; starts at 1, increments on governed change.';


--
-- Name: product_categories_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_categories_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    original_entity_id uuid NOT NULL,
    version_number integer NOT NULL,
    previous_version_id uuid,
    change_set_id uuid,
    change_type public.update_type NOT NULL,
    change_reason text,
    changed_by uuid,
    approved_by uuid,
    source_id uuid,
    confidence_level numeric DEFAULT 0.5 NOT NULL,
    code public.citext NOT NULL,
    name text NOT NULL,
    description text,
    parent_id uuid,
    display_order integer DEFAULT 0 NOT NULL,
    status_id bigint NOT NULL,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    effective_from timestamp with time zone DEFAULT now() NOT NULL,
    effective_to timestamp with time zone,
    superseded_at timestamp with time zone,
    snapshot_hash text NOT NULL,
    checksum text NOT NULL,
    version_status public.version_status DEFAULT 'draft'::public.version_status NOT NULL,
    CONSTRAINT product_categories_history_confidence_level_check CHECK (((confidence_level >= (0)::numeric) AND (confidence_level <= (1)::numeric))),
    CONSTRAINT product_categories_history_display_order_check CHECK ((display_order >= 0)),
    CONSTRAINT product_categories_history_effective_window_check CHECK (((effective_to IS NULL) OR (effective_to >= effective_from))),
    CONSTRAINT product_categories_history_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE product_categories_history; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.product_categories_history IS 'Immutable version-history of product_categories (INSERT-only; one row per version).';


--
-- Name: COLUMN product_categories_history.original_entity_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_categories_history.original_entity_id IS 'Canonical product category this version belongs to (foreign key to product_categories, applied in 0022).';


--
-- Name: COLUMN product_categories_history.previous_version_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_categories_history.previous_version_id IS 'Self-reference to the immediately prior version row; NULL for the first version.';


--
-- Name: COLUMN product_categories_history.change_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_categories_history.change_type IS 'Nature of the change recorded by this version (existing update_type ENUM).';


--
-- Name: COLUMN product_categories_history.parent_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_categories_history.parent_id IS 'Taxonomy parent at this version (self-reference to product_categories, applied in 0022); NULL for taxonomy roots.';


--
-- Name: COLUMN product_categories_history.snapshot_hash; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_categories_history.snapshot_hash IS 'SHA-256 of the snapshot columns (application-computed) to verify a stored version matches the original state.';


--
-- Name: COLUMN product_categories_history.checksum; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_categories_history.checksum IS 'Checksum of the full history row for tamper evidence.';


--
-- Name: COLUMN product_categories_history.version_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_categories_history.version_status IS 'Version lifecycle: draft -> pending_approval -> approved -> superseded (existing version_status ENUM).';


--
-- Name: product_category_translations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_category_translations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_category_id uuid NOT NULL,
    language_id uuid NOT NULL,
    name text NOT NULL,
    short_name text,
    display_name text NOT NULL,
    search_name text,
    description text,
    translation_status public.translation_status DEFAULT 'draft'::public.translation_status NOT NULL,
    version_number integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT product_category_translations_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE product_category_translations; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.product_category_translations IS 'Per-language translations of product categories (unique per category and language).';


--
-- Name: COLUMN product_category_translations.name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_category_translations.name IS 'Translated canonical name of the product category.';


--
-- Name: COLUMN product_category_translations.display_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_category_translations.display_name IS 'User-facing label for the product category in this language.';


--
-- Name: COLUMN product_category_translations.search_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_category_translations.search_name IS 'Normalized search variant; NULL when not needed.';


--
-- Name: COLUMN product_category_translations.translation_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_category_translations.translation_status IS 'Governed quality lifecycle of this translation row.';


--
-- Name: product_health_evaluations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_health_evaluations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    condition_id uuid NOT NULL,
    evaluation_result text NOT NULL,
    evidence jsonb DEFAULT '[]'::jsonb,
    evaluated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: product_health_flags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_health_flags (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    health_flag_id uuid NOT NULL,
    relationship_type_id uuid NOT NULL,
    source_id uuid,
    evidence_type_id uuid,
    confidence_level numeric DEFAULT 0.5 NOT NULL,
    effective_from timestamp with time zone,
    effective_to timestamp with time zone,
    verified_at timestamp with time zone,
    approved_at timestamp with time zone,
    status_id bigint NOT NULL,
    version_number integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT product_health_flags_confidence_level_check CHECK (((confidence_level >= (0)::numeric) AND (confidence_level <= (1)::numeric))),
    CONSTRAINT product_health_flags_effective_period_check CHECK (((effective_to IS NULL) OR (effective_from IS NULL) OR (effective_to >= effective_from))),
    CONSTRAINT product_health_flags_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE product_health_flags; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.product_health_flags IS 'Product-to-health-flag relationship (claims, warnings, risks).';


--
-- Name: COLUMN product_health_flags.relationship_type_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_health_flags.relationship_type_id IS 'Kind of flag assertion (has_health_flag, warns_about, ...).';


--
-- Name: COLUMN product_health_flags.version_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_health_flags.version_number IS 'Monotonic governance/version counter; starts at 1, increments on governed change.';


--
-- Name: product_images; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_images (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    image_id uuid NOT NULL,
    relationship_type_id uuid NOT NULL,
    source_id uuid,
    evidence_type_id uuid,
    confidence_level numeric DEFAULT 0.5 NOT NULL,
    effective_from timestamp with time zone,
    effective_to timestamp with time zone,
    verified_at timestamp with time zone,
    approved_at timestamp with time zone,
    status_id bigint NOT NULL,
    version_number integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT product_images_confidence_level_check CHECK (((confidence_level >= (0)::numeric) AND (confidence_level <= (1)::numeric))),
    CONSTRAINT product_images_effective_period_check CHECK (((effective_to IS NULL) OR (effective_from IS NULL) OR (effective_to >= effective_from))),
    CONSTRAINT product_images_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE product_images; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.product_images IS 'Product-to-image attachment relationship (many images per product).';


--
-- Name: COLUMN product_images.product_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_images.product_id IS 'Owning product (foreign key to products).';


--
-- Name: COLUMN product_images.image_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_images.image_id IS 'Connected canonical image (foreign key to images); the image row is never duplicated.';


--
-- Name: COLUMN product_images.relationship_type_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_images.relationship_type_id IS 'Kind of attachment (foreign key to relationship_types: primary_image, gallery, ...).';


--
-- Name: COLUMN product_images.effective_from; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_images.effective_from IS 'Start of validity for this attachment; NULL = from creation.';


--
-- Name: COLUMN product_images.effective_to; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_images.effective_to IS 'End of validity for this attachment; NULL = currently effective.';


--
-- Name: COLUMN product_images.version_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_images.version_number IS 'Monotonic governance/version counter; starts at 1, increments on governed change.';


--
-- Name: product_images_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_images_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    original_entity_id uuid NOT NULL,
    version_number integer NOT NULL,
    previous_version_id uuid,
    change_set_id uuid,
    change_type public.update_type NOT NULL,
    change_reason text,
    changed_by uuid,
    approved_by uuid,
    source_id uuid,
    confidence_level numeric DEFAULT 0.5 NOT NULL,
    product_id uuid NOT NULL,
    image_id uuid NOT NULL,
    relationship_type_id uuid NOT NULL,
    evidence_type_id uuid,
    effective_from timestamp with time zone,
    effective_to timestamp with time zone,
    verified_at timestamp with time zone,
    approved_at timestamp with time zone,
    status_id bigint NOT NULL,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    superseded_at timestamp with time zone,
    snapshot_hash text NOT NULL,
    checksum text NOT NULL,
    version_status public.version_status DEFAULT 'draft'::public.version_status NOT NULL,
    CONSTRAINT product_images_history_confidence_level_check CHECK (((confidence_level >= (0)::numeric) AND (confidence_level <= (1)::numeric))),
    CONSTRAINT product_images_history_effective_window_check CHECK (((effective_to IS NULL) OR (effective_to >= effective_from))),
    CONSTRAINT product_images_history_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE product_images_history; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.product_images_history IS 'Immutable version-history of product_images attachments (INSERT-only; one row per version).';


--
-- Name: COLUMN product_images_history.original_entity_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_images_history.original_entity_id IS 'Product-to-image attachment this version belongs to (foreign key to product_images, applied in 0034).';


--
-- Name: COLUMN product_images_history.previous_version_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_images_history.previous_version_id IS 'Self-reference to the immediately prior version row; NULL for the first version.';


--
-- Name: COLUMN product_images_history.change_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_images_history.change_type IS 'Nature of the change recorded by this version (existing update_type ENUM).';


--
-- Name: COLUMN product_images_history.snapshot_hash; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_images_history.snapshot_hash IS 'SHA-256 of the snapshot columns, computed by capture_entity_history() at capture time.';


--
-- Name: COLUMN product_images_history.checksum; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_images_history.checksum IS 'Checksum of the full history row for tamper evidence, computed by capture_entity_history().';


--
-- Name: COLUMN product_images_history.version_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_images_history.version_status IS 'Version lifecycle: draft -> pending_approval -> approved -> superseded (existing version_status ENUM).';


--
-- Name: product_ingredients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_ingredients (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    ingredient_id uuid NOT NULL,
    relationship_type_id uuid NOT NULL,
    amount_value numeric,
    unit_id uuid,
    source_id uuid,
    evidence_type_id uuid,
    confidence_level numeric DEFAULT 0.5 NOT NULL,
    effective_from timestamp with time zone,
    effective_to timestamp with time zone,
    verified_at timestamp with time zone,
    approved_at timestamp with time zone,
    status_id bigint NOT NULL,
    version_number integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT product_ingredients_amount_nonnegative_check CHECK (((amount_value IS NULL) OR (amount_value >= (0)::numeric))),
    CONSTRAINT product_ingredients_amount_unit_pairing_check CHECK ((((amount_value IS NULL) AND (unit_id IS NULL)) OR (amount_value IS NOT NULL))),
    CONSTRAINT product_ingredients_confidence_level_check CHECK (((confidence_level >= (0)::numeric) AND (confidence_level <= (1)::numeric))),
    CONSTRAINT product_ingredients_effective_period_check CHECK (((effective_to IS NULL) OR (effective_from IS NULL) OR (effective_to >= effective_from))),
    CONSTRAINT product_ingredients_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE product_ingredients; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.product_ingredients IS 'Product-to-ingredient membership relationship with optional declared amount.';


--
-- Name: COLUMN product_ingredients.relationship_type_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_ingredients.relationship_type_id IS 'Membership kind (contains_ingredient, may_contain_ingredient, ...).';


--
-- Name: COLUMN product_ingredients.amount_value; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_ingredients.amount_value IS 'Optional declared amount of the ingredient; NULL when the label lists no quantity.';


--
-- Name: COLUMN product_ingredients.unit_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_ingredients.unit_id IS 'Unit of amount_value (foreign key to units); NULL when amount is NULL.';


--
-- Name: COLUMN product_ingredients.effective_from; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_ingredients.effective_from IS 'Start of validity for this relationship; NULL = from creation.';


--
-- Name: COLUMN product_ingredients.effective_to; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_ingredients.effective_to IS 'End of validity for this relationship; NULL = currently effective.';


--
-- Name: COLUMN product_ingredients.version_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_ingredients.version_number IS 'Monotonic governance/version counter; starts at 1, increments on governed change.';


--
-- Name: product_nutrition_values; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_nutrition_values (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    nutrition_type_id uuid NOT NULL,
    relationship_type_id uuid NOT NULL,
    amount_value numeric NOT NULL,
    unit_id uuid NOT NULL,
    source_id uuid,
    evidence_type_id uuid,
    confidence_level numeric DEFAULT 0.5 NOT NULL,
    effective_from timestamp with time zone,
    effective_to timestamp with time zone,
    verified_at timestamp with time zone,
    approved_at timestamp with time zone,
    status_id bigint NOT NULL,
    version_number integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    measurement_basis_id uuid,
    CONSTRAINT product_nutrition_values_amount_nonnegative_check CHECK ((amount_value >= (0)::numeric)),
    CONSTRAINT product_nutrition_values_confidence_level_check CHECK (((confidence_level >= (0)::numeric) AND (confidence_level <= (1)::numeric))),
    CONSTRAINT product_nutrition_values_effective_period_check CHECK (((effective_to IS NULL) OR (effective_from IS NULL) OR (effective_to >= effective_from))),
    CONSTRAINT product_nutrition_values_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE product_nutrition_values; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.product_nutrition_values IS 'Provenance-tracked nutrition fact values per product.';


--
-- Name: COLUMN product_nutrition_values.relationship_type_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_nutrition_values.relationship_type_id IS 'Fact kind (provides_nutrition, ...); reserved for future fact sub-kinds.';


--
-- Name: COLUMN product_nutrition_values.amount_value; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_nutrition_values.amount_value IS 'Numeric amount of the nutrition fact (non-negative).';


--
-- Name: COLUMN product_nutrition_values.unit_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_nutrition_values.unit_id IS 'Unit of amount_value (foreign key to units).';


--
-- Name: COLUMN product_nutrition_values.version_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_nutrition_values.version_number IS 'Monotonic governance/version counter; starts at 1, increments on governed change.';


--
-- Name: product_search_index; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_search_index (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    search_name text NOT NULL,
    search_text text NOT NULL,
    search_tokens text[] DEFAULT '{}'::text[] NOT NULL,
    language_codes public.citext[] DEFAULT '{}'::public.citext[] NOT NULL,
    search_rank numeric DEFAULT 0 NOT NULL,
    generated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT product_search_index_search_rank_check CHECK ((search_rank >= (0)::numeric))
);


--
-- Name: TABLE product_search_index; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.product_search_index IS 'Derived, rebuildable search index for products (read model; no FK to products).';


--
-- Name: COLUMN product_search_index.product_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_search_index.product_id IS 'Logical reference to products.id; NO foreign key - the search layer is disposable and rebuildable.';


--
-- Name: COLUMN product_search_index.search_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_search_index.search_name IS 'Normalized primary searchable name (application-built from canonical name/translations).';


--
-- Name: COLUMN product_search_index.search_text; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_search_index.search_text IS 'Normalized concatenated searchable text: description, category, brand, internal code, aliases.';


--
-- Name: COLUMN product_search_index.search_tokens; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_search_index.search_tokens IS 'Language-independent normalized search tokens (folded, accent-stripped).';


--
-- Name: COLUMN product_search_index.language_codes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_search_index.language_codes IS 'Languages covered by the searchable text (citext codes, e.g. {ar,en}).';


--
-- Name: COLUMN product_search_index.search_rank; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_search_index.search_rank IS 'Ranking helper >= 0; higher means the result is promoted.';


--
-- Name: COLUMN product_search_index.generated_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_search_index.generated_at IS 'Timestamp when this search row was generated or refreshed (rebuild tracking).';


--
-- Name: product_translations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_translations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    language_id uuid NOT NULL,
    name text NOT NULL,
    short_name text,
    display_name text NOT NULL,
    search_name text,
    description text,
    translation_status public.translation_status DEFAULT 'draft'::public.translation_status NOT NULL,
    version_number integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT product_translations_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE product_translations; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.product_translations IS 'Per-language translations of products (unique per product and language).';


--
-- Name: COLUMN product_translations.name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_translations.name IS 'Translated canonical name of the product.';


--
-- Name: COLUMN product_translations.display_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_translations.display_name IS 'User-facing label for the product in this language.';


--
-- Name: COLUMN product_translations.search_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_translations.search_name IS 'Normalized search variant (e.g. transliteration); NULL when not needed.';


--
-- Name: COLUMN product_translations.translation_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_translations.translation_status IS 'Governed quality lifecycle of this translation row.';


--
-- Name: products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.products (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    brand_id uuid,
    product_category_id uuid,
    internal_code public.citext NOT NULL,
    name text NOT NULL,
    description text,
    status_id bigint NOT NULL,
    source_id uuid,
    confidence_level numeric DEFAULT 0.5 NOT NULL,
    verified_at timestamp with time zone,
    approved_at timestamp with time zone,
    deprecated_at timestamp with time zone,
    version_number integer DEFAULT 1 NOT NULL,
    created_by uuid,
    approved_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT products_confidence_level_check CHECK (((confidence_level >= (0)::numeric) AND (confidence_level <= (1)::numeric))),
    CONSTRAINT products_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE products; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.products IS 'Canonical registry of products (governed, provenance-tracked core entity).';


--
-- Name: COLUMN products.brand_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.products.brand_id IS 'Owning brand (foreign key to brands); NULL for generic/unbranded products.';


--
-- Name: COLUMN products.product_category_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.products.product_category_id IS 'Classification node (foreign key to product_categories); NULL when unclassified.';


--
-- Name: COLUMN products.internal_code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.products.internal_code IS 'Stable internal machine reference (unique, citext).';


--
-- Name: COLUMN products.confidence_level; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.products.confidence_level IS 'Numeric fact confidence in [0,1]; the confidence_band ENUM is derived, never stored.';


--
-- Name: COLUMN products.version_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.products.version_number IS 'Monotonic governance/version counter; starts at 1, increments on governed change.';


--
-- Name: COLUMN products.created_by; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.products.created_by IS 'UUID of the actor that created the row; FK to the future auth service (none yet).';


--
-- Name: COLUMN products.approved_by; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.products.approved_by IS 'UUID of the actor that approved the row; FK to the future auth service (none yet).';


--
-- Name: products_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.products_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    original_entity_id uuid NOT NULL,
    version_number integer NOT NULL,
    previous_version_id uuid,
    change_set_id uuid,
    change_type public.update_type NOT NULL,
    change_reason text,
    changed_by uuid,
    approved_by uuid,
    source_id uuid,
    confidence_level numeric DEFAULT 0.5 NOT NULL,
    brand_id uuid,
    product_category_id uuid,
    internal_code public.citext NOT NULL,
    name text NOT NULL,
    description text,
    status_id bigint NOT NULL,
    verified_at timestamp with time zone,
    approved_at timestamp with time zone,
    deprecated_at timestamp with time zone,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    effective_from timestamp with time zone DEFAULT now() NOT NULL,
    effective_to timestamp with time zone,
    superseded_at timestamp with time zone,
    snapshot_hash text NOT NULL,
    checksum text NOT NULL,
    version_status public.version_status DEFAULT 'draft'::public.version_status NOT NULL,
    CONSTRAINT products_history_confidence_level_check CHECK (((confidence_level >= (0)::numeric) AND (confidence_level <= (1)::numeric))),
    CONSTRAINT products_history_effective_window_check CHECK (((effective_to IS NULL) OR (effective_to >= effective_from))),
    CONSTRAINT products_history_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE products_history; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.products_history IS 'Immutable version-history of products (INSERT-only; one row per version).';


--
-- Name: COLUMN products_history.original_entity_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.products_history.original_entity_id IS 'Canonical product this version belongs to (foreign key to products, applied in 0022).';


--
-- Name: COLUMN products_history.previous_version_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.products_history.previous_version_id IS 'Self-reference to the immediately prior version row; NULL for the first version.';


--
-- Name: COLUMN products_history.change_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.products_history.change_type IS 'Nature of the change recorded by this version (existing update_type ENUM).';


--
-- Name: COLUMN products_history.brand_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.products_history.brand_id IS 'Owning brand at this version (foreign key to brands, applied in 0022); NULL for unbranded products.';


--
-- Name: COLUMN products_history.product_category_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.products_history.product_category_id IS 'Classification node at this version (foreign key to product_categories, applied in 0022).';


--
-- Name: COLUMN products_history.snapshot_hash; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.products_history.snapshot_hash IS 'SHA-256 of the snapshot columns (application-computed) to verify a stored version matches the original state.';


--
-- Name: COLUMN products_history.checksum; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.products_history.checksum IS 'Checksum of the full history row for tamper evidence.';


--
-- Name: COLUMN products_history.version_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.products_history.version_status IS 'Version lifecycle: draft -> pending_approval -> approved -> superseded (existing version_status ENUM).';


--
-- Name: regions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.regions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    code public.citext NOT NULL,
    name text NOT NULL,
    description text,
    display_order integer DEFAULT 0 NOT NULL,
    status_id bigint NOT NULL,
    version_number integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT regions_display_order_check CHECK ((display_order >= 0)),
    CONSTRAINT regions_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE regions; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.regions IS 'Governed registry of geopolitical regions (GCC, MENA, Europe, ...) for market scoping.';


--
-- Name: COLUMN regions.code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.regions.code IS 'Stable machine reference (snake_case), e.g. gcc, mena, europe.';


--
-- Name: COLUMN regions.version_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.regions.version_number IS 'Monotonic governance/version counter; starts at 1, increments on governed change.';


--
-- Name: regulatory_authorities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.regulatory_authorities (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    code public.citext NOT NULL,
    name text NOT NULL,
    description text,
    display_order integer DEFAULT 0 NOT NULL,
    status_id bigint NOT NULL,
    version_number integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT regulatory_authorities_display_order_check CHECK ((display_order >= 0)),
    CONSTRAINT regulatory_authorities_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE regulatory_authorities; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.regulatory_authorities IS 'Governed registry of regulatory and standard authorities (sfda, efsa, codex, ...).';


--
-- Name: COLUMN regulatory_authorities.code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.regulatory_authorities.code IS 'Stable machine reference (snake_case), e.g. sfda, gso, efsa, codex_alimentarius.';


--
-- Name: COLUMN regulatory_authorities.version_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.regulatory_authorities.version_number IS 'Monotonic governance/version counter; starts at 1, increments on governed change.';


--
-- Name: relationship_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.relationship_types (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    code public.citext NOT NULL,
    name text NOT NULL,
    description text,
    is_directional boolean DEFAULT true NOT NULL,
    inverse_type_id uuid,
    display_order integer DEFAULT 0 NOT NULL,
    status_id bigint NOT NULL,
    version_number integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT relationship_types_display_order_check CHECK ((display_order >= 0)),
    CONSTRAINT relationship_types_inverse_not_self_check CHECK (((inverse_type_id IS NULL) OR (inverse_type_id <> id))),
    CONSTRAINT relationship_types_symmetric_no_inverse_check CHECK ((is_directional OR (inverse_type_id IS NULL))),
    CONSTRAINT relationship_types_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE relationship_types; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.relationship_types IS 'Governed registry of knowledge-graph relationship types between entities.';


--
-- Name: COLUMN relationship_types.is_directional; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.relationship_types.is_directional IS 'True when subject->object order is meaningful (paired with inverse_type_id).';


--
-- Name: COLUMN relationship_types.inverse_type_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.relationship_types.inverse_type_id IS 'Self-reference to the paired inverse relationship type; NULL when symmetric.';


--
-- Name: COLUMN relationship_types.version_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.relationship_types.version_number IS 'Monotonic governance/version counter; starts at 1, increments on governed change.';


--
-- Name: role_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role_types (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    code public.citext NOT NULL,
    name text NOT NULL,
    description text,
    display_order integer DEFAULT 0 NOT NULL,
    status_id bigint NOT NULL,
    version_number integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT role_types_display_order_check CHECK ((display_order >= 0)),
    CONSTRAINT role_types_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE role_types; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.role_types IS 'Governed registry of platform user roles (admin, editor, reviewer, expert, ...).';


--
-- Name: COLUMN role_types.code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.role_types.code IS 'Stable machine reference (snake_case), e.g. admin, editor, reviewer, expert.';


--
-- Name: COLUMN role_types.version_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.role_types.version_number IS 'Monotonic governance/version counter; starts at 1, increments on governed change.';


--
-- Name: scan_job_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.scan_job_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    scan_job_id uuid NOT NULL,
    candidate_id uuid,
    product_id uuid,
    barcode text,
    status text DEFAULT 'pending'::text NOT NULL,
    action text,
    error_message text,
    processed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: scan_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.scan_jobs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    scan_type text DEFAULT 'full'::text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    started_at timestamp with time zone,
    finished_at timestamp with time zone,
    duration_seconds double precision,
    products_discovered integer DEFAULT 0 NOT NULL,
    products_processed integer DEFAULT 0 NOT NULL,
    products_accepted integer DEFAULT 0 NOT NULL,
    products_rejected integer DEFAULT 0 NOT NULL,
    products_needs_review integer DEFAULT 0 NOT NULL,
    products_created integer DEFAULT 0 NOT NULL,
    products_updated integer DEFAULT 0 NOT NULL,
    products_unchanged integer DEFAULT 0 NOT NULL,
    conflicts_detected integer DEFAULT 0 NOT NULL,
    errors_count integer DEFAULT 0 NOT NULL,
    coverage_pct double precision,
    error_log jsonb DEFAULT '[]'::jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.schema_migrations (
    version text NOT NULL,
    checksum text NOT NULL,
    applied_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: source_priorities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.source_priorities (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    code public.citext NOT NULL,
    name text NOT NULL,
    rank smallint NOT NULL,
    description text,
    status_id bigint NOT NULL,
    version_number integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT source_priorities_rank_check CHECK (((rank >= 1) AND (rank <= 99))),
    CONSTRAINT source_priorities_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE source_priorities; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.source_priorities IS 'Governed trust/priority scale for data sources.';


--
-- Name: COLUMN source_priorities.rank; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.source_priorities.rank IS 'Ascending ordinal: higher rank wins conflicts; bounded to 1..99.';


--
-- Name: COLUMN source_priorities.version_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.source_priorities.version_number IS 'Monotonic governance/version counter; starts at 1, increments on governed change.';


--
-- Name: source_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.source_types (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    code public.citext NOT NULL,
    name text NOT NULL,
    description text,
    display_order integer DEFAULT 0 NOT NULL,
    status_id bigint NOT NULL,
    version_number integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT source_types_display_order_check CHECK ((display_order >= 0)),
    CONSTRAINT source_types_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE source_types; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.source_types IS 'Governed registry of data-source categories.';


--
-- Name: COLUMN source_types.version_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.source_types.version_number IS 'Monotonic governance/version counter; starts at 1, increments on governed change.';


--
-- Name: unit_conversions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.unit_conversions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    from_unit_id uuid NOT NULL,
    to_unit_id uuid NOT NULL,
    conversion_factor double precision NOT NULL,
    measurement_type text NOT NULL,
    is_exact boolean DEFAULT true NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: units; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.units (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    code public.citext NOT NULL,
    name text NOT NULL,
    symbol text NOT NULL,
    dimension public.unit_dimension NOT NULL,
    is_base_unit boolean DEFAULT false NOT NULL,
    status_id bigint NOT NULL,
    version_number integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT units_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE units; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.units IS 'Governed registry of units of measure, grouped by physical dimension.';


--
-- Name: COLUMN units.code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.units.code IS 'Stable machine reference based on the international symbol (e.g. g, kg, kcal).';


--
-- Name: COLUMN units.name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.units.name IS 'Canonical English name (e.g. gram).';


--
-- Name: COLUMN units.symbol; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.units.symbol IS 'Display symbol (may differ from code, e.g. code ug / symbol µg).';


--
-- Name: COLUMN units.dimension; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.units.dimension IS 'Physical dimension of the unit; conversions are only legal within one dimension.';


--
-- Name: COLUMN units.is_base_unit; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.units.is_base_unit IS 'Designates the canonical base unit for a dimension (exactly one per dimension).';


--
-- Name: COLUMN units.version_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.units.version_number IS 'Monotonic governance/version counter; starts at 1, increments on governed change.';


--
-- Name: verification_statuses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.verification_statuses (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    code public.citext NOT NULL,
    name text NOT NULL,
    description text,
    display_order integer DEFAULT 0 NOT NULL,
    status_id bigint NOT NULL,
    version_number integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT verification_statuses_display_order_check CHECK ((display_order >= 0)),
    CONSTRAINT verification_statuses_version_number_check CHECK ((version_number > 0))
);


--
-- Name: TABLE verification_statuses; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.verification_statuses IS 'Governed registry of barcode verification states (trust, not lifecycle).';


--
-- Name: COLUMN verification_statuses.code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.verification_statuses.code IS 'Stable machine reference (snake_case; e.g. unverified, verified).';


--
-- Name: COLUMN verification_statuses.status_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.verification_statuses.status_id IS 'Lifecycle of the vocabulary row itself (foreign key to lifecycle_statuses).';


--
-- Name: COLUMN verification_statuses.version_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.verification_statuses.version_number IS 'Monotonic governance/version counter; starts at 1, increments on governed change.';


--
-- Name: version_metadata; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.version_metadata (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    entity_version_id uuid NOT NULL,
    key public.citext NOT NULL,
    value text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT version_metadata_key_not_empty_check CHECK ((key OPERATOR(public.<>) ''::public.citext))
);


--
-- Name: TABLE version_metadata; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.version_metadata IS 'Key/value extension attributes scoped to one entity_versions entry.';


--
-- Name: COLUMN version_metadata.entity_version_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.version_metadata.entity_version_id IS 'Owning version registry entry (foreign key to entity_versions, applied in 0022).';


--
-- Name: COLUMN version_metadata.key; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.version_metadata.key IS 'Extension attribute key (snake_case, unique per version).';


--
-- Name: COLUMN version_metadata.value; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.version_metadata.value IS 'Extension attribute value (text).';


--
-- Data for Name: allergen_translations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.allergen_translations (id, allergen_id, language_id, name, short_name, display_name, search_name, description, translation_status, version_number, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: allergen_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.allergen_types (id, code, name, description, display_order, status_id, version_number, created_at, updated_at, deleted_at) FROM stdin;
b4ef879c-7d2c-443b-9435-055c9a442fb7	FOOD_ALLERGEN	Food Allergen	\N	0	1	1	2026-08-11 00:13:04.177607+00	2026-08-11 00:13:04.177607+00	\N
8affd3a9-4bd2-49a8-9183-b276c4d24ab2	DIETARY_RESTRICTION	Dietary Restriction	\N	0	1	1	2026-08-11 00:13:04.177607+00	2026-08-11 00:13:04.177607+00	\N
\.


--
-- Data for Name: allergens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.allergens (id, allergen_type_id, internal_code, name, description, status_id, source_id, confidence_level, verified_at, approved_at, deprecated_at, version_number, created_by, approved_by, created_at, updated_at, deleted_at) FROM stdin;
5c302be6-3afe-4ed7-919c-c308158bc54e	b4ef879c-7d2c-443b-9435-055c9a442fb7	MILK	Milk	Milk and milk-derived proteins	1	\N	1.0	\N	\N	\N	1	\N	\N	2026-08-11 00:17:46.400147+00	2026-08-11 00:17:46.400147+00	\N
1ead5274-48ad-4c67-bde1-73fad80eb19e	b4ef879c-7d2c-443b-9435-055c9a442fb7	EGG	Egg	Egg and egg-derived proteins	1	\N	1.0	\N	\N	\N	1	\N	\N	2026-08-11 00:17:46.400147+00	2026-08-11 00:17:46.400147+00	\N
f62d44e1-1646-450a-b8ee-2a6adf6cd7cd	b4ef879c-7d2c-443b-9435-055c9a442fb7	PEANUT	Peanut	Peanut and peanut-derived ingredients	1	\N	1.0	\N	\N	\N	1	\N	\N	2026-08-11 00:17:46.400147+00	2026-08-11 00:17:46.400147+00	\N
796f3f70-b86a-417d-8f17-9f928882d824	b4ef879c-7d2c-443b-9435-055c9a442fb7	TREE_NUTS	Tree Nuts	Tree nuts and derived ingredients	1	\N	1.0	\N	\N	\N	1	\N	\N	2026-08-11 00:17:46.400147+00	2026-08-11 00:17:46.400147+00	\N
2cfdcf5e-487a-4c61-bdbd-e5acbac726d0	b4ef879c-7d2c-443b-9435-055c9a442fb7	WHEAT	Wheat	Wheat and wheat-derived ingredients	1	\N	1.0	\N	\N	\N	1	\N	\N	2026-08-11 00:17:46.400147+00	2026-08-11 00:17:46.400147+00	\N
4bc260bc-d95a-4a8b-84c1-c7c6cdbdfced	b4ef879c-7d2c-443b-9435-055c9a442fb7	SOY	Soy	Soybean and soy-derived ingredients	1	\N	1.0	\N	\N	\N	1	\N	\N	2026-08-11 00:17:46.400147+00	2026-08-11 00:17:46.400147+00	\N
6d0112a9-81c0-4184-b317-f24c886f9ae5	b4ef879c-7d2c-443b-9435-055c9a442fb7	SESAME	Sesame	Sesame and sesame-derived ingredients	1	\N	1.0	\N	\N	\N	1	\N	\N	2026-08-11 00:17:46.400147+00	2026-08-11 00:17:46.400147+00	\N
e3b64b8a-7dbb-42d5-8788-c759084e49a0	b4ef879c-7d2c-443b-9435-055c9a442fb7	FISH	Fish	Fish and fish-derived ingredients	1	\N	1.0	\N	\N	\N	1	\N	\N	2026-08-11 00:17:46.400147+00	2026-08-11 00:17:46.400147+00	\N
bd366d6c-718f-4ee4-ac11-1b2b0dbaa8c2	b4ef879c-7d2c-443b-9435-055c9a442fb7	SHELLFISH	Shellfish	Crustaceans and shellfish	1	\N	1.0	\N	\N	\N	1	\N	\N	2026-08-11 00:17:46.400147+00	2026-08-11 00:17:46.400147+00	\N
d958c1ac-c2c8-47d2-80de-f001c7b44705	b4ef879c-7d2c-443b-9435-055c9a442fb7	MUSTARD	Mustard	Mustard and mustard-derived ingredients	1	\N	1.0	\N	\N	\N	1	\N	\N	2026-08-11 00:17:46.400147+00	2026-08-11 00:17:46.400147+00	\N
\.


--
-- Data for Name: allergens_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.allergens_history (id, original_entity_id, version_number, previous_version_id, change_set_id, change_type, change_reason, changed_by, approved_by, source_id, confidence_level, allergen_type_id, internal_code, name, description, status_id, verified_at, approved_at, deprecated_at, deleted_at, created_at, effective_from, effective_to, superseded_at, snapshot_hash, checksum, version_status) FROM stdin;
8a3edd58-c78f-4e71-8964-2497c756bb2b	5c302be6-3afe-4ed7-919c-c308158bc54e	1	\N	\N	created	\N	\N	\N	\N	1.0	b4ef879c-7d2c-443b-9435-055c9a442fb7	MILK	Milk	Milk and milk-derived proteins	1	\N	\N	\N	\N	2026-08-11 00:17:46.400147+00	2026-08-11 00:17:46.400147+00	\N	\N	293e3577c1c70aeefde7579869d4e8940ba5bf53174812396fb1c46aae8798db	d60628ef0b80fd7ece8afdf176b4b3b7ae2c44f0da95d4bc451b1329ba02a295	draft
ea3d99f6-ead2-49ed-b8e6-efbde72f2e61	1ead5274-48ad-4c67-bde1-73fad80eb19e	1	\N	\N	created	\N	\N	\N	\N	1.0	b4ef879c-7d2c-443b-9435-055c9a442fb7	EGG	Egg	Egg and egg-derived proteins	1	\N	\N	\N	\N	2026-08-11 00:17:46.400147+00	2026-08-11 00:17:46.400147+00	\N	\N	5b166d6a35c37d49f6c2bf20f9290661be87b2e3df9a55606abf264b4c6d5bee	dbb6666df3e2a2c6594b6eb2e77141c36d04cfaf8e4ddb464dcbbefcf424d0e8	draft
52d730c0-743e-4bc2-b79f-cbbf4df255b1	f62d44e1-1646-450a-b8ee-2a6adf6cd7cd	1	\N	\N	created	\N	\N	\N	\N	1.0	b4ef879c-7d2c-443b-9435-055c9a442fb7	PEANUT	Peanut	Peanut and peanut-derived ingredients	1	\N	\N	\N	\N	2026-08-11 00:17:46.400147+00	2026-08-11 00:17:46.400147+00	\N	\N	b6b4f0a5737d9d7b5377d96cf6df8744340c29c82d334bb8cc595f9f23083ce6	2aca87ddc7c53f5c174c04f244ba8f3f60acdb71a7d0a07d161c974605ecfab9	draft
99694312-bd68-4655-837d-ea51ddb159d8	796f3f70-b86a-417d-8f17-9f928882d824	1	\N	\N	created	\N	\N	\N	\N	1.0	b4ef879c-7d2c-443b-9435-055c9a442fb7	TREE_NUTS	Tree Nuts	Tree nuts and derived ingredients	1	\N	\N	\N	\N	2026-08-11 00:17:46.400147+00	2026-08-11 00:17:46.400147+00	\N	\N	887d71528aaf247cd6f5a57a8e9ad1f912e036cbc14b18bf18ebdbc90124c8ad	ab44c22f76d6bd7eb2bcb104b3ee54bb37c5eb1e27044fae400a0da4ce0a8f1f	draft
ebda6f03-7a46-4170-a1b8-74a1196f8170	2cfdcf5e-487a-4c61-bdbd-e5acbac726d0	1	\N	\N	created	\N	\N	\N	\N	1.0	b4ef879c-7d2c-443b-9435-055c9a442fb7	WHEAT	Wheat	Wheat and wheat-derived ingredients	1	\N	\N	\N	\N	2026-08-11 00:17:46.400147+00	2026-08-11 00:17:46.400147+00	\N	\N	5b97b5c773779a81d0b196813f827e37b32f19e73c1173afb07bf6f730f463f4	99c8bf5eb09b4fcb231a712dcbdf5df601adb5cbd91016e074992c1b180f4a13	draft
f36ee98e-cd24-4dc5-8316-75b812dc9cc4	4bc260bc-d95a-4a8b-84c1-c7c6cdbdfced	1	\N	\N	created	\N	\N	\N	\N	1.0	b4ef879c-7d2c-443b-9435-055c9a442fb7	SOY	Soy	Soybean and soy-derived ingredients	1	\N	\N	\N	\N	2026-08-11 00:17:46.400147+00	2026-08-11 00:17:46.400147+00	\N	\N	6b125ae5bd7a94f39248558828b855809775b9f33dad5d99638369d6712ee4b8	92eb388633898dc1d9454c18e5f58bd45c1c56881b7e9093877162b6c37b7e2a	draft
43c7b7f4-2aee-492f-b8ce-931f0eadf47e	6d0112a9-81c0-4184-b317-f24c886f9ae5	1	\N	\N	created	\N	\N	\N	\N	1.0	b4ef879c-7d2c-443b-9435-055c9a442fb7	SESAME	Sesame	Sesame and sesame-derived ingredients	1	\N	\N	\N	\N	2026-08-11 00:17:46.400147+00	2026-08-11 00:17:46.400147+00	\N	\N	1618e14d047f0711839669aa69379538da2de2fd1e19f005df7571466313dfc6	08b5b90b52f8493f44b4277841721dad6b2ac20e7e98d1d08be19cbb08317929	draft
645de3ba-a3fb-4d28-978f-080337ef6e3d	e3b64b8a-7dbb-42d5-8788-c759084e49a0	1	\N	\N	created	\N	\N	\N	\N	1.0	b4ef879c-7d2c-443b-9435-055c9a442fb7	FISH	Fish	Fish and fish-derived ingredients	1	\N	\N	\N	\N	2026-08-11 00:17:46.400147+00	2026-08-11 00:17:46.400147+00	\N	\N	bcfa1f2fd8da634aabb9053c3e58d744d0da4e7c3137fafa739fb0f69281a1cc	0c88d15633494e3036dcdf7828ec30ce73eddb598908ec379c254273a0da9e5e	draft
0235a1f6-c6d0-46da-a7e6-d02d7ac42abf	bd366d6c-718f-4ee4-ac11-1b2b0dbaa8c2	1	\N	\N	created	\N	\N	\N	\N	1.0	b4ef879c-7d2c-443b-9435-055c9a442fb7	SHELLFISH	Shellfish	Crustaceans and shellfish	1	\N	\N	\N	\N	2026-08-11 00:17:46.400147+00	2026-08-11 00:17:46.400147+00	\N	\N	708d59d0418d4a6623102c4aca432a33fc67a1e005e50b3f8cf1f997fa12bcd4	baebcf51f46beb2eeb5ddf91e6fbee472fd9011c95455fb12c93a38585889eaf	draft
67ad95ed-b9a4-4056-886d-bb25594bb89e	d958c1ac-c2c8-47d2-80de-f001c7b44705	1	\N	\N	created	\N	\N	\N	\N	1.0	b4ef879c-7d2c-443b-9435-055c9a442fb7	MUSTARD	Mustard	Mustard and mustard-derived ingredients	1	\N	\N	\N	\N	2026-08-11 00:17:46.400147+00	2026-08-11 00:17:46.400147+00	\N	\N	b857d2ce5628b36776e5a60c4fedff6fe3f43431250d07e6e0430071cb52ed36	3f72d7cd6890f9890b0462707263f89b8bf813cfef622147700b54fa4e8f596d	draft
\.


--
-- Data for Name: audit_context; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_context (id, correlation_id, transaction_id, actor, role_id, source, ip_address, user_agent, started_at, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: audit_event_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_event_types (id, code, name, description, display_order, status_id, version_number, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: audit_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_events (id, audit_log_id, event_type_id, entity_type, entity_id, previous_version, new_version, event_time, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_log (id, change_set_id, event_type_id, entity_type, entity_id, previous_version, new_version, actor, role_id, source, ip_address, user_agent, correlation_id, transaction_id, logged_at, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: barcode_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.barcode_types (id, code, name, digit_length, description, display_order, status_id, version_number, created_at, updated_at, deleted_at) FROM stdin;
dd4b4e39-c36a-42ab-9d26-293f7ab4397f	EAN13	EAN-13	\N	\N	0	1	1	2026-08-11 00:13:06.567188+00	2026-08-11 00:13:06.567188+00	\N
e62722da-881d-4fe6-babc-0183f1b58091	EAN8	EAN-8	\N	\N	0	1	1	2026-08-11 00:13:06.567188+00	2026-08-11 00:13:06.567188+00	\N
d1d5e53d-e6d2-410e-9d23-5a60eb4076dd	UPC_A	UPC-A	\N	\N	0	1	1	2026-08-11 00:13:06.567188+00	2026-08-11 00:13:06.567188+00	\N
f998e118-6203-4c39-9990-ec672bf2e708	UPC_E	UPC-E	\N	\N	0	1	1	2026-08-11 00:13:06.567188+00	2026-08-11 00:13:06.567188+00	\N
46a7907e-b29a-4807-b55e-aa67ff1c8abc	GTIN	GTIN	\N	\N	0	1	1	2026-08-11 00:13:06.567188+00	2026-08-11 00:13:06.567188+00	\N
\.


--
-- Data for Name: barcodes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.barcodes (id, barcode, barcode_type_id, verification_status_id, source_id, status_id, issued_country_id, confidence_level, version_number, created_by, updated_by, reviewed_by, approved_by, created_at, updated_at, deleted_at) FROM stdin;
1735210f-d5ad-476d-9e36-da15f3584a2c	6281000000073	dd4b4e39-c36a-42ab-9d26-293f7ab4397f	ed354cfc-f915-4805-842d-f035d8aacec5	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1	\N	1.0	1	\N	\N	\N	\N	2026-08-12 18:00:11.498008+00	2026-08-12 18:00:11.498008+00	\N
627e6069-b55a-42b1-8ffa-c5b03c67877e	6281000000042	dd4b4e39-c36a-42ab-9d26-293f7ab4397f	ed354cfc-f915-4805-842d-f035d8aacec5	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1	\N	1.0	1	\N	\N	\N	\N	2026-08-12 18:00:11.498008+00	2026-08-12 18:00:11.498008+00	\N
2a491400-4249-4466-afee-36ca917f35ed	6281000000066	dd4b4e39-c36a-42ab-9d26-293f7ab4397f	ed354cfc-f915-4805-842d-f035d8aacec5	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1	\N	1.0	1	\N	\N	\N	\N	2026-08-12 18:00:11.498008+00	2026-08-12 18:00:11.498008+00	\N
e8dc8a10-8560-4e57-851f-05c83c5570ec	6281000000059	dd4b4e39-c36a-42ab-9d26-293f7ab4397f	ed354cfc-f915-4805-842d-f035d8aacec5	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1	\N	1.0	1	\N	\N	\N	\N	2026-08-12 18:00:11.498008+00	2026-08-12 18:00:11.498008+00	\N
5088e20c-e943-4a4b-aa1d-602a4e3dccff	6281000000011	dd4b4e39-c36a-42ab-9d26-293f7ab4397f	ed354cfc-f915-4805-842d-f035d8aacec5	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1	\N	1.0	1	\N	\N	\N	\N	2026-08-12 18:00:11.498008+00	2026-08-12 18:00:11.498008+00	\N
28532d4a-6776-44ec-b86e-3fd3b4f67403	6281000000035	dd4b4e39-c36a-42ab-9d26-293f7ab4397f	ed354cfc-f915-4805-842d-f035d8aacec5	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1	\N	1.0	1	\N	\N	\N	\N	2026-08-12 18:00:11.498008+00	2026-08-12 18:00:11.498008+00	\N
b4b93651-7600-4992-ae9b-2604e917f4aa	6281000000028	dd4b4e39-c36a-42ab-9d26-293f7ab4397f	ed354cfc-f915-4805-842d-f035d8aacec5	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1	\N	1.0	1	\N	\N	\N	\N	2026-08-12 18:00:11.498008+00	2026-08-12 18:00:11.498008+00	\N
\.


--
-- Data for Name: barcodes_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.barcodes_history (id, original_entity_id, version_number, previous_version_id, change_set_id, change_type, change_reason, changed_by, approved_by, source_id, confidence_level, barcode, barcode_type_id, verification_status_id, issued_country_id, status_id, deleted_at, created_at, effective_from, effective_to, superseded_at, snapshot_hash, checksum, version_status) FROM stdin;
8e010e73-7f10-4b17-b60e-9db6b6f882fe	1735210f-d5ad-476d-9e36-da15f3584a2c	1	\N	\N	created	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	6281000000073	dd4b4e39-c36a-42ab-9d26-293f7ab4397f	ed354cfc-f915-4805-842d-f035d8aacec5	\N	1	\N	2026-08-12 18:00:11.498008+00	2026-08-12 18:00:11.498008+00	\N	\N	c24f3ed9a93ea7cf2ad45d897cf3a0633ce54b329f237f2c8fba95043a126324	bb43854eb3350b993d0ee636bdf0588509f6d2e375ec9fef80deb1e57abf4552	draft
3b5ba0cc-9ae4-42ca-befd-055a39660b9d	627e6069-b55a-42b1-8ffa-c5b03c67877e	1	\N	\N	created	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	6281000000042	dd4b4e39-c36a-42ab-9d26-293f7ab4397f	ed354cfc-f915-4805-842d-f035d8aacec5	\N	1	\N	2026-08-12 18:00:11.498008+00	2026-08-12 18:00:11.498008+00	\N	\N	3b2ff3d310008531aaf3ef97370cef303082c032860dbed833f4ba6b78811a48	a31296806fce201c4598561372e2335e2f20763a6deb6e1acc3b8c474ff1831f	draft
24d9b0ab-3415-450b-89dd-4e2602d0ff60	2a491400-4249-4466-afee-36ca917f35ed	1	\N	\N	created	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	6281000000066	dd4b4e39-c36a-42ab-9d26-293f7ab4397f	ed354cfc-f915-4805-842d-f035d8aacec5	\N	1	\N	2026-08-12 18:00:11.498008+00	2026-08-12 18:00:11.498008+00	\N	\N	c4975f96ef6f0633cceba68957f8c83c9372a4b231939b0366da8a9d5c656ee4	1ad4a922e3655196e95a2e11cf001a606eb2ba5e687afe755d0d44a71c26fcf7	draft
106c4ed3-f7c3-4ee3-a7ee-30d0526f5ef9	e8dc8a10-8560-4e57-851f-05c83c5570ec	1	\N	\N	created	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	6281000000059	dd4b4e39-c36a-42ab-9d26-293f7ab4397f	ed354cfc-f915-4805-842d-f035d8aacec5	\N	1	\N	2026-08-12 18:00:11.498008+00	2026-08-12 18:00:11.498008+00	\N	\N	e0f91f02c781cbce1e00644b717d3617fbbe993926800b1534fa699f6acfb8be	21ddbdd2a73f93efd9e1d5e82a76c9781357fdd6a51399d33c7f260e2db4af4c	draft
c0703278-8a31-458c-8b57-f53272ebc607	5088e20c-e943-4a4b-aa1d-602a4e3dccff	1	\N	\N	created	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	6281000000011	dd4b4e39-c36a-42ab-9d26-293f7ab4397f	ed354cfc-f915-4805-842d-f035d8aacec5	\N	1	\N	2026-08-12 18:00:11.498008+00	2026-08-12 18:00:11.498008+00	\N	\N	48e828d54fd651a34da9048ad10da7f58dbffb5da381f8ae72f4c3d4bfd9b9ac	c152c4a2e9a6f2af2af67e7c16c0c8ab040bd68f5e3a98dc1d0a418e296c0b1a	draft
564795d0-4d8d-494c-832b-537006e2c9e2	28532d4a-6776-44ec-b86e-3fd3b4f67403	1	\N	\N	created	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	6281000000035	dd4b4e39-c36a-42ab-9d26-293f7ab4397f	ed354cfc-f915-4805-842d-f035d8aacec5	\N	1	\N	2026-08-12 18:00:11.498008+00	2026-08-12 18:00:11.498008+00	\N	\N	d565d504702851938468f2db61d55badd584ac4617c6985c494581576b0086bc	b14492acd6412f383b438616e15d5e99de58a00a998572a17c8c9fb18e73d964	draft
b9fbdb60-2e91-488b-9f84-fe4d1365c25a	b4b93651-7600-4992-ae9b-2604e917f4aa	1	\N	\N	created	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	6281000000028	dd4b4e39-c36a-42ab-9d26-293f7ab4397f	ed354cfc-f915-4805-842d-f035d8aacec5	\N	1	\N	2026-08-12 18:00:11.498008+00	2026-08-12 18:00:11.498008+00	\N	\N	498593d29138cf5abbee45d9bced2ca0f4972bd35a162936fef5cd845ae175a9	19c46a2d41302f906e65de735a6d2339f96682b673b2f591a2f1401075c1011d	draft
\.


--
-- Data for Name: brand_search_index; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.brand_search_index (id, brand_id, search_name, search_text, search_tokens, language_codes, search_rank, generated_at) FROM stdin;
\.


--
-- Data for Name: brand_translations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.brand_translations (id, brand_id, language_id, name, short_name, display_name, search_name, description, translation_status, version_number, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: brands; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.brands (id, company_id, internal_code, name, description, status_id, source_id, confidence_level, verified_at, approved_at, deprecated_at, version_number, created_by, approved_by, created_at, updated_at, deleted_at) FROM stdin;
0ff81924-4e05-46e2-8c01-075cabded0b7	8ff0eaab-6877-4d36-9c83-412a88d0a577	GENERIC_BRAND	Generic Food Brand	\N	1	\N	0.5	\N	\N	\N	1	\N	\N	2026-08-11 00:29:11.798863+00	2026-08-11 00:29:11.798863+00	\N
a03497f8-562e-4b20-a98c-8ec497c5bccd	e54d9b60-aa2c-49ea-b9af-01b31fec629d	FATEEN_TEST	Fateen Test Brand	\N	1	\N	0.5	\N	\N	\N	1	\N	\N	2026-08-11 00:29:11.798863+00	2026-08-11 00:29:11.798863+00	\N
feec1927-2905-470e-86bd-47f2673dadb8	3f620960-52e2-40f9-a33d-21d3450c7adf	MAGGI	Maggi	\N	1	\N	0.5	\N	\N	\N	1	\N	\N	2026-08-11 00:37:23.412284+00	2026-08-11 00:37:23.412284+00	\N
b9a7338b-4432-4292-85ea-6d3a80e193ff	3f620960-52e2-40f9-a33d-21d3450c7adf	KITKAT	KitKat	\N	1	\N	0.5	\N	\N	\N	1	\N	\N	2026-08-11 00:37:23.412284+00	2026-08-11 00:37:23.412284+00	\N
e98ff5f4-5a2f-4b38-93b9-37d78707f98a	3f620960-52e2-40f9-a33d-21d3450c7adf	NESCAFE	Nescafe	\N	1	\N	0.5	\N	\N	\N	1	\N	\N	2026-08-11 00:37:23.412284+00	2026-08-11 00:37:23.412284+00	\N
aa0999cd-c851-4d26-af94-adc9a2186038	e430d47e-372a-409c-b89c-cd8d61c56748	DOVE	Dove	\N	1	\N	0.5	\N	\N	\N	1	\N	\N	2026-08-11 00:37:23.412284+00	2026-08-11 00:37:23.412284+00	\N
84926a6b-f834-48cb-b8b8-4cbe8cdda5e2	51fea794-41df-405f-87e6-eee26cdd075b	LAYS	Lays	\N	1	\N	0.5	\N	\N	\N	1	\N	\N	2026-08-11 00:37:23.412284+00	2026-08-11 00:37:23.412284+00	\N
ef1810d6-484a-40f1-adc2-a3bbeb5bea8a	51fea794-41df-405f-87e6-eee26cdd075b	PEPSI	Pepsi	\N	1	\N	0.5	\N	\N	\N	1	\N	\N	2026-08-11 00:37:23.412284+00	2026-08-11 00:37:23.412284+00	\N
c0c7d43a-fdd0-4dc3-99d8-fa2fb488337f	1375ba99-37e4-4ae1-ad04-3d31e1149a7e	OREO	Oreo	\N	1	\N	0.5	\N	\N	\N	1	\N	\N	2026-08-11 00:37:23.412284+00	2026-08-11 00:37:23.412284+00	\N
08d101d9-3b50-4a9d-a44b-bcfbb7d660cf	b4c0c793-ce66-4d49-a887-445032ef46bc	ACTIVIA	Activia	\N	1	\N	0.5	\N	\N	\N	1	\N	\N	2026-08-11 00:37:23.412284+00	2026-08-11 00:37:23.412284+00	\N
c4f51fa8-e37d-4198-b211-f7dc81119b4f	b4c0c793-ce66-4d49-a887-445032ef46bc	DANONE	Danone	\N	1	\N	0.5	\N	\N	\N	1	\N	\N	2026-08-11 00:37:23.412284+00	2026-08-11 00:37:23.412284+00	\N
af458dbe-a774-42b0-8a0c-08faaff9d8d2	ba19618f-2a03-4c54-9a56-df5c348b1624	KINDER	Kinder	\N	1	\N	0.5	\N	\N	\N	1	\N	\N	2026-08-11 00:37:23.412284+00	2026-08-11 00:37:23.412284+00	\N
0d92198c-de93-4b67-ba62-bda3bd45f1cd	3f620960-52e2-40f9-a33d-21d3450c7adf	TEST_TRIGGER_BRAND	Test Trigger Brand	\N	1	\N	0.5	\N	\N	\N	1	\N	\N	2026-08-11 00:39:09.624692+00	2026-08-11 00:39:09.624692+00	\N
\.


--
-- Data for Name: brands_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.brands_history (id, original_entity_id, version_number, previous_version_id, change_set_id, change_type, change_reason, changed_by, approved_by, source_id, confidence_level, company_id, internal_code, name, description, status_id, verified_at, approved_at, deprecated_at, deleted_at, created_at, effective_from, effective_to, superseded_at, snapshot_hash, checksum, version_status) FROM stdin;
21218e9b-1bae-4d8e-ad0e-9cfd08a885a1	0ff81924-4e05-46e2-8c01-075cabded0b7	1	\N	\N	created	\N	\N	\N	\N	0.5	8ff0eaab-6877-4d36-9c83-412a88d0a577	GENERIC_BRAND	Generic Food Brand	\N	1	\N	\N	\N	\N	2026-08-11 00:29:11.798863+00	2026-08-11 00:29:11.798863+00	\N	\N	daf5e6c216b8ed40cab632e865e5d0413220da76c5339bb114955372a0530b29	a786717cb0ed1c8c6de0c3f54cdf00aa34253398f4ce1418c4f9daffa4f8d8ae	draft
53b2ace7-9950-48ba-8dec-5db21e83956c	a03497f8-562e-4b20-a98c-8ec497c5bccd	1	\N	\N	created	\N	\N	\N	\N	0.5	e54d9b60-aa2c-49ea-b9af-01b31fec629d	FATEEN_TEST	Fateen Test Brand	\N	1	\N	\N	\N	\N	2026-08-11 00:29:11.798863+00	2026-08-11 00:29:11.798863+00	\N	\N	a5508cc7fc51aa9b888113923dab81a4dd8515fb689f45c2b4fc8a9a43e7008b	343686c6417202eba5c8067031ca1e299a73fc95632e2bc3525d72bf8a7fea93	draft
611aa17f-f082-4d40-81b0-23d54036edc7	feec1927-2905-470e-86bd-47f2673dadb8	1	\N	\N	created	\N	\N	\N	\N	0.5	3f620960-52e2-40f9-a33d-21d3450c7adf	MAGGI	Maggi	\N	1	\N	\N	\N	\N	2026-08-11 00:37:23.412284+00	2026-08-11 00:37:23.412284+00	\N	\N	99a0a9c41a9cb0f48b2440f28acf481e4b15549990e5c19544c42affc494832c	7dc8dd6b05a2eef5404c401295acd9f8304052620fe381995cf8b2712a6f5d8e	draft
a41be16a-b51c-42ef-b8d3-fa18bf29f992	b9a7338b-4432-4292-85ea-6d3a80e193ff	1	\N	\N	created	\N	\N	\N	\N	0.5	3f620960-52e2-40f9-a33d-21d3450c7adf	KITKAT	KitKat	\N	1	\N	\N	\N	\N	2026-08-11 00:37:23.412284+00	2026-08-11 00:37:23.412284+00	\N	\N	d3d2cf7623711d570b5fb819c89d47b354cdec0f9944f0a4ec8c8979ca80099d	60525988f6518c99a3f282f51ee4dc0a88871c4f1c01e0eb247afc42036eee8c	draft
18c74a1f-03ef-4363-9fb2-39c4ef1f079e	e98ff5f4-5a2f-4b38-93b9-37d78707f98a	1	\N	\N	created	\N	\N	\N	\N	0.5	3f620960-52e2-40f9-a33d-21d3450c7adf	NESCAFE	Nescafe	\N	1	\N	\N	\N	\N	2026-08-11 00:37:23.412284+00	2026-08-11 00:37:23.412284+00	\N	\N	6fd5b57af36eeeafbf78a76d9214dc3c5f4403b00a158577301f109a3bb9b05e	79fe475f4ae3995d06b80a25b55d2c88d592720894211fdf2a28cf1ba2de8359	draft
f3ad9b34-4507-4ed2-9f94-ebfa817f8b68	aa0999cd-c851-4d26-af94-adc9a2186038	1	\N	\N	created	\N	\N	\N	\N	0.5	e430d47e-372a-409c-b89c-cd8d61c56748	DOVE	Dove	\N	1	\N	\N	\N	\N	2026-08-11 00:37:23.412284+00	2026-08-11 00:37:23.412284+00	\N	\N	f27098615ea236025cfb934c7f9373a475d13bb975e5575f5fd598be3adbd981	332a0d7aa901a4f28983041c5951ec573f2fdf1603488efb29e2b4a4a65b2aba	draft
43a016cc-7086-4be9-9538-55272e41bdff	84926a6b-f834-48cb-b8b8-4cbe8cdda5e2	1	\N	\N	created	\N	\N	\N	\N	0.5	51fea794-41df-405f-87e6-eee26cdd075b	LAYS	Lays	\N	1	\N	\N	\N	\N	2026-08-11 00:37:23.412284+00	2026-08-11 00:37:23.412284+00	\N	\N	81c02dc0ddde68e4ece44ac14c6ed5bd0573a48472a9764173ecdbac54bf4ddb	0f1d294518ec72c76f9de5138d1315d974aafbeefdb77ba1925de90584bdddd3	draft
c02bc38a-8671-4201-859a-eef53663ad9d	ef1810d6-484a-40f1-adc2-a3bbeb5bea8a	1	\N	\N	created	\N	\N	\N	\N	0.5	51fea794-41df-405f-87e6-eee26cdd075b	PEPSI	Pepsi	\N	1	\N	\N	\N	\N	2026-08-11 00:37:23.412284+00	2026-08-11 00:37:23.412284+00	\N	\N	12912b0b5397b04b66fa8b919d94760b875c9cd507a549546b390e4cd61fa845	dc712dc121804b187d70b81b98ebbdf404b76944c2fd6f718904033849ee9f93	draft
16286585-a760-4bfd-91b4-080dbf2584e2	c0c7d43a-fdd0-4dc3-99d8-fa2fb488337f	1	\N	\N	created	\N	\N	\N	\N	0.5	1375ba99-37e4-4ae1-ad04-3d31e1149a7e	OREO	Oreo	\N	1	\N	\N	\N	\N	2026-08-11 00:37:23.412284+00	2026-08-11 00:37:23.412284+00	\N	\N	14316400ef94928823b482f173460692a60831bb564d356ae383d8ab0d0b1bb0	b338de73dc8a1ab13616dac200ad76c6ceab9a15ea59ace01c1f7f1f88a983fa	draft
01713a18-9477-4754-9d8a-3dcf077675e2	08d101d9-3b50-4a9d-a44b-bcfbb7d660cf	1	\N	\N	created	\N	\N	\N	\N	0.5	b4c0c793-ce66-4d49-a887-445032ef46bc	ACTIVIA	Activia	\N	1	\N	\N	\N	\N	2026-08-11 00:37:23.412284+00	2026-08-11 00:37:23.412284+00	\N	\N	cbb2b4cd2762ec1b0b62868b00675ee69d47aff53da272578af5cf55faac10fa	c6478b2322e2adc89b2091a1e85f07de41f2f2301181249b3c94a849fee4c430	draft
46acb181-50c1-4a84-867b-e76d7f46458b	c4f51fa8-e37d-4198-b211-f7dc81119b4f	1	\N	\N	created	\N	\N	\N	\N	0.5	b4c0c793-ce66-4d49-a887-445032ef46bc	DANONE	Danone	\N	1	\N	\N	\N	\N	2026-08-11 00:37:23.412284+00	2026-08-11 00:37:23.412284+00	\N	\N	a7df213a35cb013e602d5417bd4a91fa2019ed362725d838de3dcd6ca2cd90fc	fba3fb54a88ae2f1ebc01c8ab58854e5334cca357215865272b7ceafef7593c0	draft
cc303136-f68b-4c11-b687-68d4b44d133d	af458dbe-a774-42b0-8a0c-08faaff9d8d2	1	\N	\N	created	\N	\N	\N	\N	0.5	ba19618f-2a03-4c54-9a56-df5c348b1624	KINDER	Kinder	\N	1	\N	\N	\N	\N	2026-08-11 00:37:23.412284+00	2026-08-11 00:37:23.412284+00	\N	\N	f9b482481eb5296654202cf417f7e082b18846e6e9747b0a3c705b51657d6ef0	1ff874626d68c6126255c55674f3e392ae93ab228606131b128d6c78699994b9	draft
11415be4-62d9-4a2d-889d-86156d6d6eec	0d92198c-de93-4b67-ba62-bda3bd45f1cd	1	\N	\N	created	\N	\N	\N	\N	0.5	3f620960-52e2-40f9-a33d-21d3450c7adf	TEST_TRIGGER_BRAND	Test Trigger Brand	\N	1	\N	\N	\N	\N	2026-08-11 00:39:09.624692+00	2026-08-11 00:39:09.624692+00	\N	\N	d4bbab2659a7bef33861cfab3036c90c28f5fbb946c61a906ccf2dc61145598d	156587d8cbecb3225ecc5029af3592e72e633603906506acaedfaaeaca9e9722	draft
\.


--
-- Data for Name: change_sets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.change_sets (id, correlation_id, transaction_id, description, applied_at, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: companies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.companies (id, internal_code, name, description, status_id, source_id, confidence_level, verified_at, approved_at, deprecated_at, version_number, created_by, approved_by, created_at, updated_at, deleted_at, slug, priority, priority_score, expected_product_count, discovered_product_count, verified_product_count, failed_product_count, conflict_count, missing_data_count, barcode_coverage_pct, ingredient_coverage_pct, allergen_coverage_pct, nutrition_coverage_pct, evidence_coverage_pct, last_scan_at, next_scan_at, country, market, scan_status, metadata) FROM stdin;
8ff0eaab-6877-4d36-9c83-412a88d0a577	GENERIC_FOOD_CO	Generic Food Company	\N	1	\N	0.5	\N	\N	\N	2	\N	\N	2026-08-11 00:29:11.151283+00	2026-08-18 01:38:14.161681+00	\N	generic_food_co	50	\N	\N	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	SA	packaged_food	pending	{}
e54d9b60-aa2c-49ea-b9af-01b31fec629d	FATEEN_TEST_CO	Fateen Test Company	\N	1	\N	0.5	\N	\N	\N	2	\N	\N	2026-08-11 00:29:11.151283+00	2026-08-18 01:38:14.161681+00	\N	fateen_test_co	50	\N	\N	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	SA	packaged_food	pending	{}
3f620960-52e2-40f9-a33d-21d3450c7adf	NESTLE	Nestle	\N	1	\N	0.5	\N	\N	\N	2	\N	\N	2026-08-11 00:31:18.814809+00	2026-08-18 01:38:14.161681+00	\N	nestle	50	\N	\N	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	SA	packaged_food	pending	{}
e430d47e-372a-409c-b89c-cd8d61c56748	UNILEVER	Unilever	\N	1	\N	0.5	\N	\N	\N	2	\N	\N	2026-08-11 00:31:18.814809+00	2026-08-18 01:38:14.161681+00	\N	unilever	50	\N	\N	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	SA	packaged_food	pending	{}
51fea794-41df-405f-87e6-eee26cdd075b	PEPSICO	PepsiCo	\N	1	\N	0.5	\N	\N	\N	2	\N	\N	2026-08-11 00:31:18.814809+00	2026-08-18 01:38:14.161681+00	\N	pepsico	50	\N	\N	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	SA	packaged_food	pending	{}
1375ba99-37e4-4ae1-ad04-3d31e1149a7e	MONDELEZ	Mondelez International	\N	1	\N	0.5	\N	\N	\N	2	\N	\N	2026-08-11 00:31:18.814809+00	2026-08-18 01:38:14.161681+00	\N	mondelez	50	\N	\N	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	SA	packaged_food	pending	{}
b4c0c793-ce66-4d49-a887-445032ef46bc	DANONE	Danone	\N	1	\N	0.5	\N	\N	\N	2	\N	\N	2026-08-11 00:31:18.814809+00	2026-08-18 01:38:14.161681+00	\N	danone	50	\N	\N	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	SA	packaged_food	pending	{}
ba19618f-2a03-4c54-9a56-df5c348b1624	MARS	Mars	\N	1	\N	0.5	\N	\N	\N	2	\N	\N	2026-08-11 00:31:18.814809+00	2026-08-18 01:38:14.161681+00	\N	mars	50	\N	\N	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	SA	packaged_food	pending	{}
23d86625-13ba-455e-941f-973baab652ec	KRAFT_HEINZ	Kraft Heinz	\N	1	\N	0.5	\N	\N	\N	2	\N	\N	2026-08-11 00:31:18.814809+00	2026-08-18 01:38:14.161681+00	\N	kraft_heinz	50	\N	\N	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	SA	packaged_food	pending	{}
85bebf98-420b-433e-8745-f66aef1b6ee8	GENERAL_MILLS	General Mills	\N	1	\N	0.5	\N	\N	\N	2	\N	\N	2026-08-11 00:31:18.814809+00	2026-08-18 01:38:14.161681+00	\N	general_mills	50	\N	\N	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	SA	packaged_food	pending	{}
\.


--
-- Data for Name: companies_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.companies_history (id, original_entity_id, version_number, previous_version_id, change_set_id, change_type, change_reason, changed_by, approved_by, source_id, confidence_level, internal_code, name, description, status_id, verified_at, approved_at, deprecated_at, deleted_at, created_at, effective_from, effective_to, superseded_at, snapshot_hash, checksum, version_status) FROM stdin;
b638ad95-9241-462e-bc0d-b875683255b8	8ff0eaab-6877-4d36-9c83-412a88d0a577	1	\N	\N	created	\N	\N	\N	\N	0.5	GENERIC_FOOD_CO	Generic Food Company	\N	1	\N	\N	\N	\N	2026-08-11 00:29:11.151283+00	2026-08-11 00:29:11.151283+00	\N	\N	c4c0547a92b96ead3033704d3bf12f0e385f98e90a4c5484c9f29c4efc9980c0	0a2bfb7e99eae24e486e27bc75cccf9d1c9ddcf90a8751b9ed7cbf784e4ed398	draft
be5a575d-af30-4f9c-92c4-eeb4abf73ba5	e54d9b60-aa2c-49ea-b9af-01b31fec629d	1	\N	\N	created	\N	\N	\N	\N	0.5	FATEEN_TEST_CO	Fateen Test Company	\N	1	\N	\N	\N	\N	2026-08-11 00:29:11.151283+00	2026-08-11 00:29:11.151283+00	\N	\N	ea545195ad907f9a240e862aa733aa9d2fac37110d862bf0e205cedf66112b56	314050191f32c73a2cbcd5a584f43db0a15fe6602aaa78b595ee7667c1023195	draft
9b4015af-ff8d-4b9e-b04a-26b5523a0394	3f620960-52e2-40f9-a33d-21d3450c7adf	1	\N	\N	created	\N	\N	\N	\N	0.5	NESTLE	Nestle	\N	1	\N	\N	\N	\N	2026-08-11 00:31:18.814809+00	2026-08-11 00:31:18.814809+00	\N	\N	dab1891738f355a866138c3fa5e59e149eb5a3136a33208b5e2c14962220183e	a9039477f921570b730426d3903268d9ced09d5fddc804ac13ff20b06520c8ee	draft
de1c7d20-31de-4dae-b127-2dd4d8745fcc	e430d47e-372a-409c-b89c-cd8d61c56748	1	\N	\N	created	\N	\N	\N	\N	0.5	UNILEVER	Unilever	\N	1	\N	\N	\N	\N	2026-08-11 00:31:18.814809+00	2026-08-11 00:31:18.814809+00	\N	\N	f895fe0807a583a409c0ef23a8925b659cd85af756c8e8c1859a627d47df354f	37313e081fd031bacb92ef79ccf78c05408d1ec8383b035caa58c6f74d686cf1	draft
214a8f99-5a84-442e-915f-cbc152d17253	51fea794-41df-405f-87e6-eee26cdd075b	1	\N	\N	created	\N	\N	\N	\N	0.5	PEPSICO	PepsiCo	\N	1	\N	\N	\N	\N	2026-08-11 00:31:18.814809+00	2026-08-11 00:31:18.814809+00	\N	\N	98ecd9fbe748532fbaae4b7af86912060ed5bf61590dcca22783c9cfb9d42f2e	b02cc9385f4386eaad1171ec663ed5835c15aa94c5af96775ff1b481aa30365d	draft
0af20945-3782-439f-bab2-1f9b971ae338	1375ba99-37e4-4ae1-ad04-3d31e1149a7e	1	\N	\N	created	\N	\N	\N	\N	0.5	MONDELEZ	Mondelez International	\N	1	\N	\N	\N	\N	2026-08-11 00:31:18.814809+00	2026-08-11 00:31:18.814809+00	\N	\N	1434241efcd8ccf6cd963e07837515fbd5ec1268ad446522218a2d1856ce89ee	8d714496d8b74869d5376ed6722baae1ad35a1905c2edc61286b7a94257f2572	draft
d2953bc0-35cf-4584-928b-978726f650b7	b4c0c793-ce66-4d49-a887-445032ef46bc	1	\N	\N	created	\N	\N	\N	\N	0.5	DANONE	Danone	\N	1	\N	\N	\N	\N	2026-08-11 00:31:18.814809+00	2026-08-11 00:31:18.814809+00	\N	\N	f14f3a76251a6e828910539375be7a377ed12f9aea7e90285df054e27e2c47a4	4602f5f1d81cea81ac6428bf7874201603897088c01c8148edbdf89b25d405ac	draft
e1430849-8ec5-4d8b-9248-0706f9271b06	ba19618f-2a03-4c54-9a56-df5c348b1624	1	\N	\N	created	\N	\N	\N	\N	0.5	MARS	Mars	\N	1	\N	\N	\N	\N	2026-08-11 00:31:18.814809+00	2026-08-11 00:31:18.814809+00	\N	\N	61b0288dd7dc3d35aed919991d0f01655bf11bba078e93ab380b4a2bf2c18702	6582bb104cde92609efe6ea69236948f208264cf58ddecff293277d4fcf24513	draft
af0c2471-9802-49f6-893d-c5393a773ce0	23d86625-13ba-455e-941f-973baab652ec	1	\N	\N	created	\N	\N	\N	\N	0.5	KRAFT_HEINZ	Kraft Heinz	\N	1	\N	\N	\N	\N	2026-08-11 00:31:18.814809+00	2026-08-11 00:31:18.814809+00	\N	\N	ad812ff5707887a8916056f6188516df5589f7346c3dae9f7d85f919b2f1a439	54f1dc6e3de2022df6e2b4ae192b0ada5de3589492afc8b547c3a563b6f7876d	draft
1a3cccf1-cfc6-4ede-8a78-aad21f296e3d	85bebf98-420b-433e-8745-f66aef1b6ee8	1	\N	\N	created	\N	\N	\N	\N	0.5	GENERAL_MILLS	General Mills	\N	1	\N	\N	\N	\N	2026-08-11 00:31:18.814809+00	2026-08-11 00:31:18.814809+00	\N	\N	0585f54ff66bae707a4d22b186071c67dbbdb7fc1e6f6e2063bf5445ced29cd6	49fa2dec621d86777faf929e56b6936475389dd3173a32edaee7b1efdc81041b	draft
fd3bcfd4-d533-4d5d-9830-371fca808a75	8ff0eaab-6877-4d36-9c83-412a88d0a577	2	b638ad95-9241-462e-bc0d-b875683255b8	\N	modified	\N	\N	\N	\N	0.5	GENERIC_FOOD_CO	Generic Food Company	\N	1	\N	\N	\N	\N	2026-08-11 00:29:11.151283+00	2026-08-18 01:38:14.161681+00	\N	\N	fb40f72eb3c1b044e96bc80e00e5f8e5ea692f6a49566cf9820f6fac97480a15	b48b3e67aa146686822d64fac5562d3e556aeb949c52f7453709e66d3f4bb087	draft
99086cb5-e156-4d13-829f-2bc4ee8f3815	e54d9b60-aa2c-49ea-b9af-01b31fec629d	2	be5a575d-af30-4f9c-92c4-eeb4abf73ba5	\N	modified	\N	\N	\N	\N	0.5	FATEEN_TEST_CO	Fateen Test Company	\N	1	\N	\N	\N	\N	2026-08-11 00:29:11.151283+00	2026-08-18 01:38:14.161681+00	\N	\N	6c05c9bdf912d9ad43cce65e3d1e3120258477e422315986646214f50ed245f6	94854cb183ee8e1fde342a1dd1afb1c187096d4180290a34d3c765a217c29812	draft
41803d4e-09f6-44be-92c0-8346afb9599a	3f620960-52e2-40f9-a33d-21d3450c7adf	2	9b4015af-ff8d-4b9e-b04a-26b5523a0394	\N	modified	\N	\N	\N	\N	0.5	NESTLE	Nestle	\N	1	\N	\N	\N	\N	2026-08-11 00:31:18.814809+00	2026-08-18 01:38:14.161681+00	\N	\N	d87f1401b8687b9440b36058e20f649b19c79f181302d8181428a524052d44bf	15f726ad0d16e35ae04489ddb5ffd03d849ab6588efc3f331d8c2a7bd52e128a	draft
a32adc60-dacd-468d-b8ee-e520f2861948	e430d47e-372a-409c-b89c-cd8d61c56748	2	de1c7d20-31de-4dae-b127-2dd4d8745fcc	\N	modified	\N	\N	\N	\N	0.5	UNILEVER	Unilever	\N	1	\N	\N	\N	\N	2026-08-11 00:31:18.814809+00	2026-08-18 01:38:14.161681+00	\N	\N	0d0b8929ddddce2317ff29689bf2a0f8cb48ff07507d29e25e3ad0c7ec73cfc5	d46b61aa8784cc6c2232f81f1fc08059da986df12965dca5fa4a987479f32472	draft
e9a4e75b-a608-4256-bd4e-1bd3e2914786	51fea794-41df-405f-87e6-eee26cdd075b	2	214a8f99-5a84-442e-915f-cbc152d17253	\N	modified	\N	\N	\N	\N	0.5	PEPSICO	PepsiCo	\N	1	\N	\N	\N	\N	2026-08-11 00:31:18.814809+00	2026-08-18 01:38:14.161681+00	\N	\N	d400d4bfffb7a41b913612e7b21d88dc762ac07a1460acd4d3d7343b5b87d5ca	ce141f30a5033d8c23dc020f480fad3ba66477ea75ad88b8d251c6d60e15804e	draft
610161ae-f1f3-4fe5-a7b0-d0b53d5eb3b9	1375ba99-37e4-4ae1-ad04-3d31e1149a7e	2	0af20945-3782-439f-bab2-1f9b971ae338	\N	modified	\N	\N	\N	\N	0.5	MONDELEZ	Mondelez International	\N	1	\N	\N	\N	\N	2026-08-11 00:31:18.814809+00	2026-08-18 01:38:14.161681+00	\N	\N	e59e23074bf87ec396186d4df2e34d26f77d516079685d3c13cf1463cb650e4d	d571188b8e555a29d4c43a84ce19960de12f007a96d2a54198e05fc03b479c8e	draft
5f9240a1-b915-4ef7-aa8c-9c641c4d19cb	b4c0c793-ce66-4d49-a887-445032ef46bc	2	d2953bc0-35cf-4584-928b-978726f650b7	\N	modified	\N	\N	\N	\N	0.5	DANONE	Danone	\N	1	\N	\N	\N	\N	2026-08-11 00:31:18.814809+00	2026-08-18 01:38:14.161681+00	\N	\N	bb5cb61283bf0a3851093f59888b36e9aebedc1103ec1b6216ffb088b25b7cea	a30af8f1f69aeed694456614c92a05cc07da63c0a4d29d2ca72fc7b8f7068c61	draft
8a6c8b62-283a-482e-8ebe-74d62fe855ea	ba19618f-2a03-4c54-9a56-df5c348b1624	2	e1430849-8ec5-4d8b-9248-0706f9271b06	\N	modified	\N	\N	\N	\N	0.5	MARS	Mars	\N	1	\N	\N	\N	\N	2026-08-11 00:31:18.814809+00	2026-08-18 01:38:14.161681+00	\N	\N	ee2a4d57032bc9fc30ec779241ff7f9c13e6cdc6b0dd56b16d04d6abf77dda64	90eab4cab51f9d6d86459ceb108b08eaaab281e345128e77883326e1d8397404	draft
266e257a-f581-40d7-97da-95547f24cfc0	23d86625-13ba-455e-941f-973baab652ec	2	af0c2471-9802-49f6-893d-c5393a773ce0	\N	modified	\N	\N	\N	\N	0.5	KRAFT_HEINZ	Kraft Heinz	\N	1	\N	\N	\N	\N	2026-08-11 00:31:18.814809+00	2026-08-18 01:38:14.161681+00	\N	\N	d0c993cde9f97a1e965605362866fc0cd38e00d28256894155dd35fdcf407be0	8373c2bbd068a0f8d7cc4f0610bcfa38ae73aa54692ce90a516681e85e90cfdc	draft
11670045-ea3d-4237-bcaf-a5c8d3c999ae	85bebf98-420b-433e-8745-f66aef1b6ee8	2	1a3cccf1-cfc6-4ede-8a78-aad21f296e3d	\N	modified	\N	\N	\N	\N	0.5	GENERAL_MILLS	General Mills	\N	1	\N	\N	\N	\N	2026-08-11 00:31:18.814809+00	2026-08-18 01:38:14.161681+00	\N	\N	1310222ee0d10c30589cfa8daa9f5496c61a38f28562b6c5bc6353d7af3b545f	35675c17dde8ea3d9243bec78617f9a3138b85dc4556d8f3691c280bd4f59db2	draft
\.


--
-- Data for Name: company_search_index; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.company_search_index (id, company_id, search_name, search_text, search_tokens, language_codes, search_rank, generated_at) FROM stdin;
\.


--
-- Data for Name: company_translations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.company_translations (id, company_id, language_id, name, short_name, display_name, search_name, description, translation_status, version_number, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: condition_nutrition_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.condition_nutrition_rules (id, condition_id, nutrition_type_code, operator, threshold_value, unit_code, severity, description, is_active, created_at) FROM stdin;
862af4f4-6861-400c-a89e-345feea165fd	ac3dce1f-f7f5-45fb-b790-b5ab7572177a	SUGAR	>	15	G	warning	High sugar content - warning for diabetics	t	2026-08-18 01:38:14.161681+00
cc658e36-2b63-41ee-abbb-425bf9fe500f	ac3dce1f-f7f5-45fb-b790-b5ab7572177a	CARBOHYDRATE	>	30	G	warning	High carbohydrate content - monitor for diabetics	t	2026-08-18 01:38:14.161681+00
57af2397-0510-4bc4-b13f-9c326cb98397	cef8cca0-8756-49ec-960e-fe8d91482232	SODIUM	>	600	MG	warning	High sodium content - warning for hypertension	t	2026-08-18 01:38:14.161681+00
ca6deacb-28a3-40f4-83a2-64feea953036	cef8cca0-8756-49ec-960e-fe8d91482232	TOTAL_FAT	>	20	G	warning	High fat content - monitor for heart health	t	2026-08-18 01:38:14.161681+00
c36f50db-c960-42d1-b0b8-e1d4240113b4	50151501-7df1-4822-8f4c-4b5d2a966fdf	SATURATED_FAT	>	5	G	warning	High saturated fat - warning for heart disease	t	2026-08-18 01:38:14.161681+00
02e99834-7409-4b27-835c-9b41c0c78219	50151501-7df1-4822-8f4c-4b5d2a966fdf	SODIUM	>	400	MG	warning	High sodium - warning for heart disease	t	2026-08-18 01:38:14.161681+00
156129c6-ffcd-4530-9f23-06bb65eec2be	30558ed7-0a33-4949-a01c-2c8af3c738bb	FIBER	>	3	G	info	May contain gluten - check ingredient list	t	2026-08-18 01:38:14.161681+00
be840e0a-5b70-4a4c-ada5-293b9084c5e0	24eabcbf-2e4e-4e22-ba3c-1a5f287e1e56	PROTEIN	>	5	G	info	May contain nuts - check allergen declarations	t	2026-08-18 01:38:14.161681+00
\.


--
-- Data for Name: countries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.countries (id, code, alpha_3, numeric_code, name, is_gcc_member, status_id, version_number, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: coverage_snapshots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.coverage_snapshots (id, company_id, scan_job_id, total_products, products_with_barcode, products_with_ingredients, products_with_allergens, products_with_nutrition, products_with_evidence, products_with_halal, barcode_coverage_pct, ingredient_coverage_pct, allergen_coverage_pct, nutrition_coverage_pct, evidence_coverage_pct, halal_coverage_pct, overall_coverage_pct, snapshot_at, created_at) FROM stdin;
\.


--
-- Data for Name: data_conflicts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.data_conflicts (id, entity_type, entity_id, entity_name, field_name, value_a, value_b, source_a_id, source_b_id, confidence_a, confidence_b, resolution, resolution_note, resolved_by, resolved_at, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: data_sources; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.data_sources (id, code, name, description, source_type_id, priority_id, country_id, is_verified, status_id, version_number, created_at, updated_at, deleted_at) FROM stdin;
65e8a675-805d-49a2-87ad-d3b62a9ba86d	FATEEN_TEST	Fateen Internal Test Dataset	Controlled test data used for database integration validation.	99a00982-9129-4753-afe3-60f56aae2875	b9957035-26e7-4c3c-8d99-a6a582d07eaa	\N	f	1	1	2026-08-12 13:55:13.845982+00	2026-08-12 13:55:13.845982+00	\N
\.


--
-- Data for Name: data_versions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.data_versions (id, entity_type, entity_id, version_number, data_snapshot, source_config_id, change_summary, created_at) FROM stdin;
\.


--
-- Data for Name: discovery_candidates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.discovery_candidates (id, company_id, scan_job_id, name, brand, barcode, category, country, market, source_url, source_reference, source_retrieved_at, raw_data, status, normalized_name, normalized_brand, normalized_barcode, matched_product_id, match_confidence, validation_errors, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: entity_relationships; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.entity_relationships (id, subject_entity_type, subject_id, object_entity_type, object_id, relationship_type_id, source_id, evidence_type_id, confidence_level, effective_from, effective_to, verified_at, approved_at, status_id, version_number, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: entity_versions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.entity_versions (id, entity_type, entity_id, version_number, history_table, history_row_id, version_status, change_set_id, previous_version_id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: evidence_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.evidence_types (id, code, name, description, display_order, status_id, version_number, created_at, updated_at, deleted_at) FROM stdin;
c24d31c8-beda-4579-a81c-9ca44d430170	LABEL	Product Label	\N	0	1	1	2026-08-11 00:13:04.502262+00	2026-08-11 00:13:04.502262+00	\N
4748581e-f31c-4cbb-8ff7-58d898618f91	MANUFACTURER	Manufacturer	\N	0	1	1	2026-08-11 00:13:04.502262+00	2026-08-11 00:13:04.502262+00	\N
357c53ca-be84-4972-b455-fb4ba5bf7db2	OFFICIAL_SOURCE	Official Source	\N	0	1	1	2026-08-11 00:13:04.502262+00	2026-08-11 00:13:04.502262+00	\N
8b8071bd-53f4-4896-9587-d0114af571c3	DATABASE	Database Record	\N	0	1	1	2026-08-11 00:13:04.502262+00	2026-08-11 00:13:04.502262+00	\N
\.


--
-- Data for Name: halal_evidence; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.halal_evidence (id, product_id, status, confidence, source_config_id, evidence_type, authority, reasoning, raw_evidence, retrieved_at, is_current, created_at, updated_at) FROM stdin;
e696bb02-a4db-430d-aa7e-e5d8222046ff	523b923e-2e00-424f-b6eb-8e8797a06025	HALAL	0.9	\N	LABEL	Test Authority	Test reasoning	\N	2026-08-18 02:13:24.231921+00	f	2026-08-18 02:13:24.231921+00	2026-08-18 02:13:24.318477+00
cbbd76ad-4e01-4be6-897c-ae5a971d7f58	523b923e-2e00-424f-b6eb-8e8797a06025	UNKNOWN	0.5	\N	LABEL	Test	Initial	\N	2026-08-18 02:13:24.318477+00	f	2026-08-18 02:13:24.318477+00	2026-08-18 02:13:24.472633+00
79de2150-40ca-404b-8585-09c0a9d0ee9b	523b923e-2e00-424f-b6eb-8e8797a06025	UNKNOWN	0.5	\N	LABEL	Test	Initial	\N	2026-08-18 02:13:24.472633+00	f	2026-08-18 02:13:24.472633+00	2026-08-18 02:13:24.595719+00
538b5824-9a76-4e97-8170-4d3c41c23f4d	523b923e-2e00-424f-b6eb-8e8797a06025	UNKNOWN	0.5	\N	LABEL	Test	Initial	\N	2026-08-18 02:13:24.595719+00	t	2026-08-18 02:13:24.595719+00	2026-08-18 02:13:24.595719+00
\.


--
-- Data for Name: health_conditions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.health_conditions (id, name, code, description, is_active, created_at) FROM stdin;
ac3dce1f-f7f5-45fb-b790-b5ab7572177a	Diabetes	DIABETES	Sugar and carbohydrate monitoring for diabetic patients	t	2026-08-18 01:38:14.161681+00
cef8cca0-8756-49ec-960e-fe8d91482232	Hypertension	HYPERTENSION	Sodium and fat monitoring for hypertension patients	t	2026-08-18 01:38:14.161681+00
30558ed7-0a33-4949-a01c-2c8af3c738bb	Celiac Disease	CELIAC	Gluten monitoring for celiac patients	t	2026-08-18 01:38:14.161681+00
24eabcbf-2e4e-4e22-ba3c-1a5f287e1e56	Nut Allergy	NUT_ALLERGY	Tree nut and peanut allergen monitoring	t	2026-08-18 01:38:14.161681+00
e19dcaac-ffc1-4f43-a496-19eb37c2e3a3	Lactose Intolerance	LACTOSE	Lactose and dairy monitoring	t	2026-08-18 01:38:14.161681+00
50151501-7df1-4822-8f4c-4b5d2a966fdf	Heart Disease	HEART_DISEASE	Fat, sodium, and cholesterol monitoring	t	2026-08-18 01:38:14.161681+00
7c51d27e-996f-4dc4-a3c0-9ed3ff3889ff	Obesity	OBESITY	Calorie and sugar monitoring	t	2026-08-18 01:38:14.161681+00
\.


--
-- Data for Name: health_flag_translations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.health_flag_translations (id, health_flag_id, language_id, name, short_name, display_name, search_name, description, translation_status, version_number, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: health_flag_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.health_flag_types (id, code, name, description, display_order, status_id, version_number, created_at, updated_at, deleted_at) FROM stdin;
c40db76f-62b3-4d19-a813-603112731cef	ALLERGY	Allergy	\N	0	1	1	2026-08-11 00:28:05.41058+00	2026-08-11 00:28:05.41058+00	\N
7ae7c564-719a-4320-a950-c2ec04c5cb02	CHRONIC_CONDITION	Chronic Condition	\N	0	1	1	2026-08-11 00:28:05.41058+00	2026-08-11 00:28:05.41058+00	\N
f8e96b2d-fbbb-4e78-bca9-1c8805dbf4ae	DIETARY	Dietary Restriction	\N	0	1	1	2026-08-11 00:28:05.41058+00	2026-08-11 00:28:05.41058+00	\N
62881f5c-4da1-4cc6-a0aa-69ec6f15a300	NUTRITION	Nutrition Related	\N	0	1	1	2026-08-11 00:28:05.41058+00	2026-08-11 00:28:05.41058+00	\N
\.


--
-- Data for Name: health_flags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.health_flags (id, health_flag_type_id, internal_code, name, description, status_id, source_id, confidence_level, verified_at, approved_at, deprecated_at, version_number, created_by, approved_by, created_at, updated_at, deleted_at) FROM stdin;
eb5af6be-c413-4347-8a54-f110ae667d8d	7ae7c564-719a-4320-a950-c2ec04c5cb02	DIABETES	Diabetes	\N	1	\N	1.0	\N	\N	\N	1	\N	\N	2026-08-11 00:28:06.120948+00	2026-08-11 00:28:06.120948+00	\N
60db7be0-152e-4e70-800b-6087f4723744	7ae7c564-719a-4320-a950-c2ec04c5cb02	HIGH_BLOOD_PRESSURE	High Blood Pressure	\N	1	\N	1.0	\N	\N	\N	1	\N	\N	2026-08-11 00:28:06.120948+00	2026-08-11 00:28:06.120948+00	\N
a872207b-ba89-4d19-a992-0d05d36288f1	c40db76f-62b3-4d19-a813-603112731cef	CELIAC	Celiac Disease	\N	1	\N	1.0	\N	\N	\N	1	\N	\N	2026-08-11 00:28:06.562659+00	2026-08-11 00:28:06.562659+00	\N
c7b229b1-67ea-4e61-bbc7-03c34af20ec3	c40db76f-62b3-4d19-a813-603112731cef	LACTOSE_INTOLERANCE	Lactose Intolerance	\N	1	\N	1.0	\N	\N	\N	1	\N	\N	2026-08-11 00:28:06.562659+00	2026-08-11 00:28:06.562659+00	\N
11de7600-e511-43c7-9b0a-e04681b94f81	c40db76f-62b3-4d19-a813-603112731cef	GLUTEN_INTOLERANCE	Gluten Intolerance	\N	1	\N	1.0	\N	\N	\N	1	\N	\N	2026-08-11 00:28:06.562659+00	2026-08-11 00:28:06.562659+00	\N
0f0c49af-7397-4fde-b22b-f3cb60120ecc	f8e96b2d-fbbb-4e78-bca9-1c8805dbf4ae	VEGAN	Vegan	\N	1	\N	1.0	\N	\N	\N	1	\N	\N	2026-08-11 00:28:06.960877+00	2026-08-11 00:28:06.960877+00	\N
e7121381-6737-4cc5-85f4-ec2a2143129b	f8e96b2d-fbbb-4e78-bca9-1c8805dbf4ae	VEGETARIAN	Vegetarian	\N	1	\N	1.0	\N	\N	\N	1	\N	\N	2026-08-11 00:28:06.960877+00	2026-08-11 00:28:06.960877+00	\N
081721ed-28f0-43cd-a6fe-3353fec6ba27	62881f5c-4da1-4cc6-a0aa-69ec6f15a300	LOW_SODIUM	Low Sodium	\N	1	\N	1.0	\N	\N	\N	1	\N	\N	2026-08-11 00:28:07.350953+00	2026-08-11 00:28:07.350953+00	\N
9e024bbd-4ae8-4374-9552-3bb2ca712fa4	62881f5c-4da1-4cc6-a0aa-69ec6f15a300	LOW_SUGAR	Low Sugar	\N	1	\N	1.0	\N	\N	\N	1	\N	\N	2026-08-11 00:28:07.350953+00	2026-08-11 00:28:07.350953+00	\N
9f9e3de6-7869-40ad-9ff8-da7f585a78ce	62881f5c-4da1-4cc6-a0aa-69ec6f15a300	LOW_FAT	Low Fat	\N	1	\N	1.0	\N	\N	\N	1	\N	\N	2026-08-11 00:28:07.350953+00	2026-08-11 00:28:07.350953+00	\N
\.


--
-- Data for Name: health_flags_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.health_flags_history (id, original_entity_id, version_number, previous_version_id, change_set_id, change_type, change_reason, changed_by, approved_by, source_id, confidence_level, health_flag_type_id, internal_code, name, description, status_id, verified_at, approved_at, deprecated_at, deleted_at, created_at, effective_from, effective_to, superseded_at, snapshot_hash, checksum, version_status) FROM stdin;
8d73ab61-a7b4-4123-94c0-715bfdbb71d7	eb5af6be-c413-4347-8a54-f110ae667d8d	1	\N	\N	created	\N	\N	\N	\N	1.0	7ae7c564-719a-4320-a950-c2ec04c5cb02	DIABETES	Diabetes	\N	1	\N	\N	\N	\N	2026-08-11 00:28:06.120948+00	2026-08-11 00:28:06.120948+00	\N	\N	32c79a89b06fce692051b627eb0830ede2e23b6d6e44ea29101ab7ce988a2a43	3b3a9e18151f5f1e6049df8e8785a14f125542258cdd27942823e821a045e795	draft
6e65db68-98fc-48f4-a170-914c1b1f582f	60db7be0-152e-4e70-800b-6087f4723744	1	\N	\N	created	\N	\N	\N	\N	1.0	7ae7c564-719a-4320-a950-c2ec04c5cb02	HIGH_BLOOD_PRESSURE	High Blood Pressure	\N	1	\N	\N	\N	\N	2026-08-11 00:28:06.120948+00	2026-08-11 00:28:06.120948+00	\N	\N	adecfe1b2e91e303ef997257444a2cea0a51a1a4d298c2fa32e026a431f4842b	9b1633e92975247156a4aefa058f738eb72bec0f3a0f8f2557f681f9ca8e413b	draft
18ca5bbb-b2b9-4171-a1d0-48b4400d1b98	a872207b-ba89-4d19-a992-0d05d36288f1	1	\N	\N	created	\N	\N	\N	\N	1.0	c40db76f-62b3-4d19-a813-603112731cef	CELIAC	Celiac Disease	\N	1	\N	\N	\N	\N	2026-08-11 00:28:06.562659+00	2026-08-11 00:28:06.562659+00	\N	\N	15160951d6c777d7b73cd2f695487cb649d1456744b615eecf9ab3f01daa522f	729969dece69fdde543f6bf61f3c3e3b1e266ae98ad3a7bd4489b05566af74f0	draft
bc55019c-b80a-4725-b92e-4858968dda15	c7b229b1-67ea-4e61-bbc7-03c34af20ec3	1	\N	\N	created	\N	\N	\N	\N	1.0	c40db76f-62b3-4d19-a813-603112731cef	LACTOSE_INTOLERANCE	Lactose Intolerance	\N	1	\N	\N	\N	\N	2026-08-11 00:28:06.562659+00	2026-08-11 00:28:06.562659+00	\N	\N	e0fc451b69f1d4ef22c2f6fdaef753c0f29db4feefb6a638ab0386f1217cce8c	cff9931efed269dc85790817901982ff5c0366beec49d619acce279842bc6265	draft
0ce05af4-309f-45d9-9133-08334b65ecf7	11de7600-e511-43c7-9b0a-e04681b94f81	1	\N	\N	created	\N	\N	\N	\N	1.0	c40db76f-62b3-4d19-a813-603112731cef	GLUTEN_INTOLERANCE	Gluten Intolerance	\N	1	\N	\N	\N	\N	2026-08-11 00:28:06.562659+00	2026-08-11 00:28:06.562659+00	\N	\N	e6340b2d4fd52aebe23fe52ed66b2378364f085dc43b5a397ce052e0bfaa2810	a9d3ab1c005554377bf7a1fda3f2533c598a71383d2d2cb2ff4aab6942d825e5	draft
98845dca-9e6b-4f7c-a47d-5c9d5e1e51d0	0f0c49af-7397-4fde-b22b-f3cb60120ecc	1	\N	\N	created	\N	\N	\N	\N	1.0	f8e96b2d-fbbb-4e78-bca9-1c8805dbf4ae	VEGAN	Vegan	\N	1	\N	\N	\N	\N	2026-08-11 00:28:06.960877+00	2026-08-11 00:28:06.960877+00	\N	\N	e8d3daffeb173e03feafec9e127b1a9ecd2f1862a6b447ea6ea40242ce90ea4c	3032235ae000e4666992b307248fffffc9654e4bc5e5390d7b837be5be9c7c49	draft
cc15e672-d95a-4682-86f1-96b09e7c09fd	e7121381-6737-4cc5-85f4-ec2a2143129b	1	\N	\N	created	\N	\N	\N	\N	1.0	f8e96b2d-fbbb-4e78-bca9-1c8805dbf4ae	VEGETARIAN	Vegetarian	\N	1	\N	\N	\N	\N	2026-08-11 00:28:06.960877+00	2026-08-11 00:28:06.960877+00	\N	\N	6195980f7f2b7f59dc03b68ad1479d3d49ccfe327c7d573e854008a31647dbcc	13d0d83a00b1a316e726184c49180ef61ca053b44900879475a1011ed52462b8	draft
5626cdf1-d320-4bc1-a081-6fd0b9d31bfb	081721ed-28f0-43cd-a6fe-3353fec6ba27	1	\N	\N	created	\N	\N	\N	\N	1.0	62881f5c-4da1-4cc6-a0aa-69ec6f15a300	LOW_SODIUM	Low Sodium	\N	1	\N	\N	\N	\N	2026-08-11 00:28:07.350953+00	2026-08-11 00:28:07.350953+00	\N	\N	0ac16f0ffa338aca2c06db16bbe14f5617fbb33efaef5d29e6a6be6c0039d026	351e1ba943711eaacf90d091140b22da253d551505bcc91a3d15ef318e2dd7ce	draft
86562c55-a509-435c-be73-7df2cd913cd9	9e024bbd-4ae8-4374-9552-3bb2ca712fa4	1	\N	\N	created	\N	\N	\N	\N	1.0	62881f5c-4da1-4cc6-a0aa-69ec6f15a300	LOW_SUGAR	Low Sugar	\N	1	\N	\N	\N	\N	2026-08-11 00:28:07.350953+00	2026-08-11 00:28:07.350953+00	\N	\N	2ea806d8fc6741ca255002c9396ef0257bc13c3337e89b98ec39dc582626c431	ac6c9231a8bc5807b9e292476b568fbc6f20c68cc9cf00dcec74c63879beb4ff	draft
c46c6acd-b25f-4365-bd7b-55499607e29e	9f9e3de6-7869-40ad-9ff8-da7f585a78ce	1	\N	\N	created	\N	\N	\N	\N	1.0	62881f5c-4da1-4cc6-a0aa-69ec6f15a300	LOW_FAT	Low Fat	\N	1	\N	\N	\N	\N	2026-08-11 00:28:07.350953+00	2026-08-11 00:28:07.350953+00	\N	\N	7f35902cb1cd3bb4b62754e47f748908adb4fc3dc5375f8a9ca95b4f5137ab81	ebbb8f1bdfe1f799d8e20ef64e98eeae7c97d1b18592307f75f78df5d28b14fd	draft
\.


--
-- Data for Name: image_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.image_types (id, code, name, description, display_order, status_id, version_number, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: images; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.images (id, image_type_id, source_id, language_id, storage_uri, content_hash, mime_type, width, height, file_size, status_id, metadata, version_number, created_by, updated_by, reviewed_by, approved_by, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: images_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.images_history (id, original_entity_id, version_number, previous_version_id, change_set_id, change_type, change_reason, changed_by, approved_by, source_id, confidence_level, image_type_id, language_id, storage_uri, content_hash, mime_type, width, height, file_size, metadata, status_id, deleted_at, created_at, effective_from, effective_to, superseded_at, snapshot_hash, checksum, version_status) FROM stdin;
\.


--
-- Data for Name: ingredient_aliases; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ingredient_aliases (id, ingredient_id, alias, language_id, relationship_type_id, source_id, evidence_type_id, confidence_level, effective_from, effective_to, verified_at, approved_at, status_id, version_number, created_at, updated_at, deleted_at) FROM stdin;
5f0e5aae-bd2a-48a0-a85b-ed34ab07c012	03620dd4-331d-438b-b77e-80647da17601	Milk Solids	\N	ce47dde0-5a33-4cfd-9751-44bb4f4a58d2	\N	\N	1.0	\N	\N	\N	\N	1	1	2026-08-11 00:21:55.551458+00	2026-08-11 00:21:55.551458+00	\N
fb415dd8-19d8-4427-af75-a7fc7ac78b4b	03620dd4-331d-438b-b77e-80647da17601	Milk	\N	ce47dde0-5a33-4cfd-9751-44bb4f4a58d2	\N	\N	1.0	\N	\N	\N	\N	1	1	2026-08-11 00:21:55.551458+00	2026-08-11 00:21:55.551458+00	\N
8af39b42-8b56-4f2c-b5cf-f1e914e24661	c16e7813-6912-4fe6-9c32-58f7395debbf	Whey Protein	\N	ce47dde0-5a33-4cfd-9751-44bb4f4a58d2	\N	\N	1.0	\N	\N	\N	\N	1	1	2026-08-11 00:21:55.551458+00	2026-08-11 00:21:55.551458+00	\N
4c47cb88-8ed4-44e8-8d95-faa677221fad	c8631d1a-bbb9-472e-9a69-3135675fef7f	Casein	\N	ce47dde0-5a33-4cfd-9751-44bb4f4a58d2	\N	\N	1.0	\N	\N	\N	\N	1	1	2026-08-11 00:21:55.551458+00	2026-08-11 00:21:55.551458+00	\N
f5d928af-26f9-4e40-bc99-b8f4a57210ab	5fabfd34-8dcb-402f-88f0-3aef87155bb1	Milk Sugar	\N	ce47dde0-5a33-4cfd-9751-44bb4f4a58d2	\N	\N	1.0	\N	\N	\N	\N	1	1	2026-08-11 00:21:55.551458+00	2026-08-11 00:21:55.551458+00	\N
e89c9b92-d5ef-462c-adb8-24ad82cefca7	ffe10640-a09c-435d-845b-47a5316ffc13	Eggs	\N	ce47dde0-5a33-4cfd-9751-44bb4f4a58d2	\N	\N	1.0	\N	\N	\N	\N	1	1	2026-08-11 00:21:55.551458+00	2026-08-11 00:21:55.551458+00	\N
fe396cee-622c-4234-a5b3-95eef7e47cc6	799ca946-566f-40a1-bab2-4a58876656c9	Egg White	\N	ce47dde0-5a33-4cfd-9751-44bb4f4a58d2	\N	\N	1.0	\N	\N	\N	\N	1	1	2026-08-11 00:21:55.551458+00	2026-08-11 00:21:55.551458+00	\N
aa310c0d-7a70-4ab3-aed4-7e0d7a353d9b	6941d019-fca8-4e52-982c-86649246b9f1	Egg Yolk	\N	ce47dde0-5a33-4cfd-9751-44bb4f4a58d2	\N	\N	1.0	\N	\N	\N	\N	1	1	2026-08-11 00:21:55.551458+00	2026-08-11 00:21:55.551458+00	\N
b70f7ab9-c6b9-4b40-97fe-ade8345bac12	bf178102-a91b-4180-9226-5ccfa8f120a6	Peanuts	\N	ce47dde0-5a33-4cfd-9751-44bb4f4a58d2	\N	\N	1.0	\N	\N	\N	\N	1	1	2026-08-11 00:21:55.551458+00	2026-08-11 00:21:55.551458+00	\N
f5d6638d-6aff-41a0-ac3f-0fd927902a23	bf178102-a91b-4180-9226-5ccfa8f120a6	Groundnut	\N	ce47dde0-5a33-4cfd-9751-44bb4f4a58d2	\N	\N	1.0	\N	\N	\N	\N	1	1	2026-08-11 00:21:55.551458+00	2026-08-11 00:21:55.551458+00	\N
fe6b8f06-b176-45d4-a03c-8926730cdb36	06f213a4-6e6f-46b8-8be8-28e6381125e1	Wheat Flour	\N	ce47dde0-5a33-4cfd-9751-44bb4f4a58d2	\N	\N	1.0	\N	\N	\N	\N	1	1	2026-08-11 00:21:55.551458+00	2026-08-11 00:21:55.551458+00	\N
ef8fc71d-5195-430f-b5ee-7fd3585a0496	64ee34d2-0972-4170-a5f4-838695ad595e	Soya	\N	ce47dde0-5a33-4cfd-9751-44bb4f4a58d2	\N	\N	1.0	\N	\N	\N	\N	1	1	2026-08-11 00:21:55.551458+00	2026-08-11 00:21:55.551458+00	\N
3ced5b33-e7d9-4a4a-a04d-41508b60017b	98450c22-a798-42c4-89e6-f7737be16b58	Soya Lecithin	\N	ce47dde0-5a33-4cfd-9751-44bb4f4a58d2	\N	\N	1.0	\N	\N	\N	\N	1	1	2026-08-11 00:21:55.551458+00	2026-08-11 00:21:55.551458+00	\N
d291a879-099a-454e-a644-794edc71514b	8f72fe51-a81d-4fe0-97e9-37636b0f3bd2	Sesame Seed	\N	ce47dde0-5a33-4cfd-9751-44bb4f4a58d2	\N	\N	1.0	\N	\N	\N	\N	1	1	2026-08-11 00:21:55.551458+00	2026-08-11 00:21:55.551458+00	\N
5e91c30f-e495-42db-8959-45deb3fb0c32	66c8b78e-ed88-4aeb-b856-30b2c413527b	Almonds	\N	ce47dde0-5a33-4cfd-9751-44bb4f4a58d2	\N	\N	1.0	\N	\N	\N	\N	1	1	2026-08-11 00:21:55.551458+00	2026-08-11 00:21:55.551458+00	\N
a231f0ba-8a5d-427c-b1bb-8213c8765544	cfa55cbb-6646-4d98-8de1-047194fdbce1	Cashews	\N	ce47dde0-5a33-4cfd-9751-44bb4f4a58d2	\N	\N	1.0	\N	\N	\N	\N	1	1	2026-08-11 00:21:55.551458+00	2026-08-11 00:21:55.551458+00	\N
8a40b35a-1caf-4abc-9b4e-8e6c1998cf7b	c8e6a39c-564b-422f-b9a4-45b0bc179cb6	Walnuts	\N	ce47dde0-5a33-4cfd-9751-44bb4f4a58d2	\N	\N	1.0	\N	\N	\N	\N	1	1	2026-08-11 00:21:55.551458+00	2026-08-11 00:21:55.551458+00	\N
317c410e-2fb5-4042-9e24-dd476030fa97	26f36e96-2965-4927-90ca-a548f22874db	Prawn	\N	ce47dde0-5a33-4cfd-9751-44bb4f4a58d2	\N	\N	1.0	\N	\N	\N	\N	1	1	2026-08-11 00:21:55.551458+00	2026-08-11 00:21:55.551458+00	\N
125769ef-927c-4d39-b67c-49d5da782e76	4d49c54b-cf07-4fc0-9171-b15369254083	Mustard	\N	ce47dde0-5a33-4cfd-9751-44bb4f4a58d2	\N	\N	1.0	\N	\N	\N	\N	1	1	2026-08-11 00:21:55.551458+00	2026-08-11 00:21:55.551458+00	\N
\.


--
-- Data for Name: ingredient_allergens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ingredient_allergens (id, ingredient_id, allergen_id, relationship_type_id, source_id, evidence_type_id, confidence_level, effective_from, effective_to, verified_at, approved_at, status_id, version_number, created_at, updated_at, deleted_at) FROM stdin;
5777796d-24db-4faf-9c96-1ddb1087c35e	03620dd4-331d-438b-b77e-80647da17601	5c302be6-3afe-4ed7-919c-c308158bc54e	18fa6ec8-afd8-40b2-b468-adc78bd6be12	\N	\N	1.0	\N	\N	\N	\N	1	1	2026-08-11 00:17:48.125504+00	2026-08-11 00:17:48.125504+00	\N
b3883dc7-e170-4200-86c6-4afbc69aedfe	c16e7813-6912-4fe6-9c32-58f7395debbf	5c302be6-3afe-4ed7-919c-c308158bc54e	18fa6ec8-afd8-40b2-b468-adc78bd6be12	\N	\N	1.0	\N	\N	\N	\N	1	1	2026-08-11 00:17:48.125504+00	2026-08-11 00:17:48.125504+00	\N
6eeacba7-c1f0-4785-8982-94ac7e1b4bc0	c8631d1a-bbb9-472e-9a69-3135675fef7f	5c302be6-3afe-4ed7-919c-c308158bc54e	18fa6ec8-afd8-40b2-b468-adc78bd6be12	\N	\N	1.0	\N	\N	\N	\N	1	1	2026-08-11 00:17:48.125504+00	2026-08-11 00:17:48.125504+00	\N
5aba2b77-6142-4996-be57-b6e05bef9e1f	5fabfd34-8dcb-402f-88f0-3aef87155bb1	5c302be6-3afe-4ed7-919c-c308158bc54e	18fa6ec8-afd8-40b2-b468-adc78bd6be12	\N	\N	1.0	\N	\N	\N	\N	1	1	2026-08-11 00:17:48.125504+00	2026-08-11 00:17:48.125504+00	\N
a47c3091-3de0-4995-b3d6-8360ea034d95	ffe10640-a09c-435d-845b-47a5316ffc13	1ead5274-48ad-4c67-bde1-73fad80eb19e	18fa6ec8-afd8-40b2-b468-adc78bd6be12	\N	\N	1.0	\N	\N	\N	\N	1	1	2026-08-11 00:17:48.125504+00	2026-08-11 00:17:48.125504+00	\N
116099cb-9b0a-437c-8275-92fda973ccd3	799ca946-566f-40a1-bab2-4a58876656c9	1ead5274-48ad-4c67-bde1-73fad80eb19e	18fa6ec8-afd8-40b2-b468-adc78bd6be12	\N	\N	1.0	\N	\N	\N	\N	1	1	2026-08-11 00:17:48.125504+00	2026-08-11 00:17:48.125504+00	\N
78cfc911-241b-4096-86d1-8fcaf8098a54	6941d019-fca8-4e52-982c-86649246b9f1	1ead5274-48ad-4c67-bde1-73fad80eb19e	18fa6ec8-afd8-40b2-b468-adc78bd6be12	\N	\N	1.0	\N	\N	\N	\N	1	1	2026-08-11 00:17:48.125504+00	2026-08-11 00:17:48.125504+00	\N
f5a30647-591b-4a24-9dcf-8df2f2df5f98	bf178102-a91b-4180-9226-5ccfa8f120a6	f62d44e1-1646-450a-b8ee-2a6adf6cd7cd	18fa6ec8-afd8-40b2-b468-adc78bd6be12	\N	\N	1.0	\N	\N	\N	\N	1	1	2026-08-11 00:17:48.125504+00	2026-08-11 00:17:48.125504+00	\N
95b2e3a3-2b56-4077-a5ae-f3d4f7c8c583	23abc89d-f2f9-4c02-8259-483889a86fcc	2cfdcf5e-487a-4c61-bdbd-e5acbac726d0	18fa6ec8-afd8-40b2-b468-adc78bd6be12	\N	\N	1.0	\N	\N	\N	\N	1	1	2026-08-11 00:17:48.125504+00	2026-08-11 00:17:48.125504+00	\N
baaa2b86-6078-49fd-8807-4e208ad5c026	06f213a4-6e6f-46b8-8be8-28e6381125e1	2cfdcf5e-487a-4c61-bdbd-e5acbac726d0	18fa6ec8-afd8-40b2-b468-adc78bd6be12	\N	\N	1.0	\N	\N	\N	\N	1	1	2026-08-11 00:17:48.125504+00	2026-08-11 00:17:48.125504+00	\N
e24b5bd1-f60c-4912-8250-6fe2bda024be	64ee34d2-0972-4170-a5f4-838695ad595e	4bc260bc-d95a-4a8b-84c1-c7c6cdbdfced	18fa6ec8-afd8-40b2-b468-adc78bd6be12	\N	\N	1.0	\N	\N	\N	\N	1	1	2026-08-11 00:17:48.125504+00	2026-08-11 00:17:48.125504+00	\N
8fa06341-7980-42dc-9c10-7eee329641a1	98450c22-a798-42c4-89e6-f7737be16b58	4bc260bc-d95a-4a8b-84c1-c7c6cdbdfced	18fa6ec8-afd8-40b2-b468-adc78bd6be12	\N	\N	1.0	\N	\N	\N	\N	1	1	2026-08-11 00:17:48.125504+00	2026-08-11 00:17:48.125504+00	\N
c2539c99-fa90-4137-bf90-10c38ba61bb6	8f72fe51-a81d-4fe0-97e9-37636b0f3bd2	6d0112a9-81c0-4184-b317-f24c886f9ae5	18fa6ec8-afd8-40b2-b468-adc78bd6be12	\N	\N	1.0	\N	\N	\N	\N	1	1	2026-08-11 00:17:48.125504+00	2026-08-11 00:17:48.125504+00	\N
8953efa6-7e51-43aa-a7e4-a84102c461ba	66c8b78e-ed88-4aeb-b856-30b2c413527b	796f3f70-b86a-417d-8f17-9f928882d824	18fa6ec8-afd8-40b2-b468-adc78bd6be12	\N	\N	1.0	\N	\N	\N	\N	1	1	2026-08-11 00:17:48.125504+00	2026-08-11 00:17:48.125504+00	\N
548f1782-f517-4c0d-8fd2-9d9c0091c047	cfa55cbb-6646-4d98-8de1-047194fdbce1	796f3f70-b86a-417d-8f17-9f928882d824	18fa6ec8-afd8-40b2-b468-adc78bd6be12	\N	\N	1.0	\N	\N	\N	\N	1	1	2026-08-11 00:17:48.125504+00	2026-08-11 00:17:48.125504+00	\N
c76c304c-64cb-48ba-ade9-9a5eceaf19b4	c8e6a39c-564b-422f-b9a4-45b0bc179cb6	796f3f70-b86a-417d-8f17-9f928882d824	18fa6ec8-afd8-40b2-b468-adc78bd6be12	\N	\N	1.0	\N	\N	\N	\N	1	1	2026-08-11 00:17:48.125504+00	2026-08-11 00:17:48.125504+00	\N
326ada9b-8106-4da3-b1a0-6e1c28674d7d	de40f5e6-ee92-4aba-89a1-d413c6dbf37c	e3b64b8a-7dbb-42d5-8788-c759084e49a0	18fa6ec8-afd8-40b2-b468-adc78bd6be12	\N	\N	1.0	\N	\N	\N	\N	1	1	2026-08-11 00:17:48.125504+00	2026-08-11 00:17:48.125504+00	\N
cc908d3b-1a41-4829-b55c-599e65e75e0f	26f36e96-2965-4927-90ca-a548f22874db	bd366d6c-718f-4ee4-ac11-1b2b0dbaa8c2	18fa6ec8-afd8-40b2-b468-adc78bd6be12	\N	\N	1.0	\N	\N	\N	\N	1	1	2026-08-11 00:17:48.125504+00	2026-08-11 00:17:48.125504+00	\N
f7e89665-63fd-4760-ad48-df82849f575d	4d49c54b-cf07-4fc0-9171-b15369254083	d958c1ac-c2c8-47d2-80de-f001c7b44705	18fa6ec8-afd8-40b2-b468-adc78bd6be12	\N	\N	1.0	\N	\N	\N	\N	1	1	2026-08-11 00:17:48.125504+00	2026-08-11 00:17:48.125504+00	\N
\.


--
-- Data for Name: ingredient_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ingredient_categories (id, code, name, description, parent_id, display_order, status_id, version_number, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: ingredient_categories_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ingredient_categories_history (id, original_entity_id, version_number, previous_version_id, change_set_id, change_type, change_reason, changed_by, approved_by, source_id, confidence_level, code, name, description, parent_id, display_order, status_id, deleted_at, created_at, effective_from, effective_to, superseded_at, snapshot_hash, checksum, version_status) FROM stdin;
\.


--
-- Data for Name: ingredient_health_flags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ingredient_health_flags (id, ingredient_id, health_flag_id, relationship_type_id, source_id, evidence_type_id, confidence_level, effective_from, effective_to, verified_at, approved_at, status_id, version_number, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: ingredient_search_index; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ingredient_search_index (id, ingredient_id, search_name, search_text, search_tokens, language_codes, search_rank, generated_at) FROM stdin;
\.


--
-- Data for Name: ingredient_translations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ingredient_translations (id, ingredient_id, language_id, name, short_name, display_name, search_name, description, translation_status, version_number, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: ingredients; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ingredients (id, internal_code, name, description, status_id, source_id, confidence_level, verified_at, approved_at, deprecated_at, version_number, created_by, approved_by, created_at, updated_at, deleted_at) FROM stdin;
03620dd4-331d-438b-b77e-80647da17601	MILK	Milk	Milk ingredient	1	\N	1.0	\N	\N	\N	1	\N	\N	2026-08-11 00:17:47.305371+00	2026-08-11 00:17:47.305371+00	\N
c16e7813-6912-4fe6-9c32-58f7395debbf	WHEY	Whey	Milk-derived whey protein	1	\N	1.0	\N	\N	\N	1	\N	\N	2026-08-11 00:17:47.305371+00	2026-08-11 00:17:47.305371+00	\N
c8631d1a-bbb9-472e-9a69-3135675fef7f	CASEIN	Casein	Milk-derived protein	1	\N	1.0	\N	\N	\N	1	\N	\N	2026-08-11 00:17:47.305371+00	2026-08-11 00:17:47.305371+00	\N
5fabfd34-8dcb-402f-88f0-3aef87155bb1	LACTOSE	Lactose	Milk sugar	1	\N	1.0	\N	\N	\N	1	\N	\N	2026-08-11 00:17:47.305371+00	2026-08-11 00:17:47.305371+00	\N
ffe10640-a09c-435d-845b-47a5316ffc13	EGG	Egg	Egg ingredient	1	\N	1.0	\N	\N	\N	1	\N	\N	2026-08-11 00:17:47.305371+00	2026-08-11 00:17:47.305371+00	\N
799ca946-566f-40a1-bab2-4a58876656c9	EGG_WHITE	Egg White	Egg white ingredient	1	\N	1.0	\N	\N	\N	1	\N	\N	2026-08-11 00:17:47.305371+00	2026-08-11 00:17:47.305371+00	\N
6941d019-fca8-4e52-982c-86649246b9f1	EGG_YOLK	Egg Yolk	Egg yolk ingredient	1	\N	1.0	\N	\N	\N	1	\N	\N	2026-08-11 00:17:47.305371+00	2026-08-11 00:17:47.305371+00	\N
bf178102-a91b-4180-9226-5ccfa8f120a6	PEANUT	Peanut	Peanut ingredient	1	\N	1.0	\N	\N	\N	1	\N	\N	2026-08-11 00:17:47.305371+00	2026-08-11 00:17:47.305371+00	\N
23abc89d-f2f9-4c02-8259-483889a86fcc	WHEAT_FLOUR	Wheat Flour	Flour made from wheat	1	\N	1.0	\N	\N	\N	1	\N	\N	2026-08-11 00:17:47.305371+00	2026-08-11 00:17:47.305371+00	\N
06f213a4-6e6f-46b8-8be8-28e6381125e1	WHEAT	Wheat	Wheat ingredient	1	\N	1.0	\N	\N	\N	1	\N	\N	2026-08-11 00:17:47.305371+00	2026-08-11 00:17:47.305371+00	\N
64ee34d2-0972-4170-a5f4-838695ad595e	SOY	Soy	Soybean ingredient	1	\N	1.0	\N	\N	\N	1	\N	\N	2026-08-11 00:17:47.305371+00	2026-08-11 00:17:47.305371+00	\N
98450c22-a798-42c4-89e6-f7737be16b58	SOY_LECITHIN	Soy Lecithin	Lecithin derived from soybean	1	\N	1.0	\N	\N	\N	1	\N	\N	2026-08-11 00:17:47.305371+00	2026-08-11 00:17:47.305371+00	\N
8f72fe51-a81d-4fe0-97e9-37636b0f3bd2	SESAME	Sesame	Sesame ingredient	1	\N	1.0	\N	\N	\N	1	\N	\N	2026-08-11 00:17:47.305371+00	2026-08-11 00:17:47.305371+00	\N
66c8b78e-ed88-4aeb-b856-30b2c413527b	ALMOND	Almond	Tree nut almond	1	\N	1.0	\N	\N	\N	1	\N	\N	2026-08-11 00:17:47.305371+00	2026-08-11 00:17:47.305371+00	\N
cfa55cbb-6646-4d98-8de1-047194fdbce1	CASHEW	Cashew	Tree nut cashew	1	\N	1.0	\N	\N	\N	1	\N	\N	2026-08-11 00:17:47.305371+00	2026-08-11 00:17:47.305371+00	\N
c8e6a39c-564b-422f-b9a4-45b0bc179cb6	WALNUT	Walnut	Tree nut walnut	1	\N	1.0	\N	\N	\N	1	\N	\N	2026-08-11 00:17:47.305371+00	2026-08-11 00:17:47.305371+00	\N
de40f5e6-ee92-4aba-89a1-d413c6dbf37c	FISH	Fish	Fish ingredient	1	\N	1.0	\N	\N	\N	1	\N	\N	2026-08-11 00:17:47.305371+00	2026-08-11 00:17:47.305371+00	\N
26f36e96-2965-4927-90ca-a548f22874db	SHRIMP	Shrimp	Crustacean ingredient	1	\N	1.0	\N	\N	\N	1	\N	\N	2026-08-11 00:17:47.305371+00	2026-08-11 00:17:47.305371+00	\N
4d49c54b-cf07-4fc0-9171-b15369254083	MUSTARD	Mustard	Mustard ingredient	1	\N	1.0	\N	\N	\N	1	\N	\N	2026-08-11 00:17:47.305371+00	2026-08-11 00:17:47.305371+00	\N
\.


--
-- Data for Name: ingredients_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ingredients_history (id, original_entity_id, version_number, previous_version_id, change_set_id, change_type, change_reason, changed_by, approved_by, source_id, confidence_level, internal_code, name, description, status_id, verified_at, approved_at, deprecated_at, deleted_at, created_at, effective_from, effective_to, superseded_at, snapshot_hash, checksum, version_status) FROM stdin;
f40531d5-d865-4cba-802c-3b88aa7bd317	03620dd4-331d-438b-b77e-80647da17601	1	\N	\N	created	\N	\N	\N	\N	1.0	MILK	Milk	Milk ingredient	1	\N	\N	\N	\N	2026-08-11 00:17:47.305371+00	2026-08-11 00:17:47.305371+00	\N	\N	d5afb6b4c8657bf4b8ff84f116505ae011e601d1a62be4d8f2b24408d6782d9a	f4ff19755a52f1abf8871b530f78ea88820ea4cba3e40f63df674f2b99bed702	draft
b915ff91-dc68-4490-9616-def523d5c5ed	c16e7813-6912-4fe6-9c32-58f7395debbf	1	\N	\N	created	\N	\N	\N	\N	1.0	WHEY	Whey	Milk-derived whey protein	1	\N	\N	\N	\N	2026-08-11 00:17:47.305371+00	2026-08-11 00:17:47.305371+00	\N	\N	203163ada20a6a2d43ac6f4ee3d6dbd8599aa366caf9494b314d42da3dbd2d5b	05a3fb26c3768f6309eef57b5da09a15759bc3eed5f6634e04e2497fd935012f	draft
3c846681-105d-4c77-a65a-7c2ab84d9314	c8631d1a-bbb9-472e-9a69-3135675fef7f	1	\N	\N	created	\N	\N	\N	\N	1.0	CASEIN	Casein	Milk-derived protein	1	\N	\N	\N	\N	2026-08-11 00:17:47.305371+00	2026-08-11 00:17:47.305371+00	\N	\N	8b17e11cb32c814d2d592326ac21e1986324f439beffe1f7aa0810451e467527	879b41046c83519cb0223f59fc3a6e5bd4ab3a507a8e98948fa659f950d4409f	draft
03865fb3-b7bb-4c44-92d8-15b85156485b	5fabfd34-8dcb-402f-88f0-3aef87155bb1	1	\N	\N	created	\N	\N	\N	\N	1.0	LACTOSE	Lactose	Milk sugar	1	\N	\N	\N	\N	2026-08-11 00:17:47.305371+00	2026-08-11 00:17:47.305371+00	\N	\N	88ea64efb48f8c38afbf1ba5c08bba5409b68e8c3a7941907ba94e99b4ae21d6	bde1f420720edebd2e94759458e88a1244b07838690a31163d2e39179efab6e5	draft
bae90bee-1e88-4d09-918d-ae47e9443cce	ffe10640-a09c-435d-845b-47a5316ffc13	1	\N	\N	created	\N	\N	\N	\N	1.0	EGG	Egg	Egg ingredient	1	\N	\N	\N	\N	2026-08-11 00:17:47.305371+00	2026-08-11 00:17:47.305371+00	\N	\N	0f8dd7cb08b1dce83a28620096271b790e6b447fe3514e49a2f049cd425e397f	7c3f673fd033c0e28cb345c895a32e7fdd2f13209998bff645979ed380d25002	draft
b50dcc65-0b0d-44ba-b333-0e0a3bd8703a	799ca946-566f-40a1-bab2-4a58876656c9	1	\N	\N	created	\N	\N	\N	\N	1.0	EGG_WHITE	Egg White	Egg white ingredient	1	\N	\N	\N	\N	2026-08-11 00:17:47.305371+00	2026-08-11 00:17:47.305371+00	\N	\N	97e9a104b479f3ea851a01faa04e7980a65a933ca02bc1b35f8bfc020b6c9778	88b14d63689f8410662832d57e4dd9a69504c52c253dc1e083b7d8b8e70f0875	draft
eac8d06b-6810-45b7-a807-c45abbfc9f6c	6941d019-fca8-4e52-982c-86649246b9f1	1	\N	\N	created	\N	\N	\N	\N	1.0	EGG_YOLK	Egg Yolk	Egg yolk ingredient	1	\N	\N	\N	\N	2026-08-11 00:17:47.305371+00	2026-08-11 00:17:47.305371+00	\N	\N	918b06a3c57f062ca2d3918b48bf9ff478b01714f5a7f9801f446c2d1ede2cd6	5b5e24ec68c83e3e3d7f1c89533a4e230bc3b134a43de0ab6f620d3ef77c7f32	draft
50228022-ada2-4d6a-92ad-68d4cd86c99f	bf178102-a91b-4180-9226-5ccfa8f120a6	1	\N	\N	created	\N	\N	\N	\N	1.0	PEANUT	Peanut	Peanut ingredient	1	\N	\N	\N	\N	2026-08-11 00:17:47.305371+00	2026-08-11 00:17:47.305371+00	\N	\N	f04b7f980372a3f52eb73290619eeae381fccb91e407f1e19902f949783312f2	f258151a4c64b142c8238d7fd2de5499718a5758e821ad22047b0adf63de8c87	draft
fd716ef9-d476-4c14-ba62-5707ec30af70	23abc89d-f2f9-4c02-8259-483889a86fcc	1	\N	\N	created	\N	\N	\N	\N	1.0	WHEAT_FLOUR	Wheat Flour	Flour made from wheat	1	\N	\N	\N	\N	2026-08-11 00:17:47.305371+00	2026-08-11 00:17:47.305371+00	\N	\N	36c066ddcdb7983d804945aabd6310b4bc88148359d9ec3b9be0e0a6d38ccb73	08c3d7f329556317a3b5609a55e674b5f39a1e4c8930bba12acd8293ee51daa3	draft
e6b7f10e-b077-41b4-a8e1-475ae92d6b63	06f213a4-6e6f-46b8-8be8-28e6381125e1	1	\N	\N	created	\N	\N	\N	\N	1.0	WHEAT	Wheat	Wheat ingredient	1	\N	\N	\N	\N	2026-08-11 00:17:47.305371+00	2026-08-11 00:17:47.305371+00	\N	\N	c98b6ed1d295bd5594457e73a9df737ad52a43657439cece3f463e8174d14910	1815a32ec76a9e6f3b977ebb6780b17f108c3af3c62b449d636489628c5b26b6	draft
81bdfab1-1d77-4e04-b2e4-bff946a71c45	64ee34d2-0972-4170-a5f4-838695ad595e	1	\N	\N	created	\N	\N	\N	\N	1.0	SOY	Soy	Soybean ingredient	1	\N	\N	\N	\N	2026-08-11 00:17:47.305371+00	2026-08-11 00:17:47.305371+00	\N	\N	b1ca3a129bbca5ddd7058a27d6ef5e003c3a435c67a7c85dfefcbc6295ac72dd	9cfefc47489b4fe2c6873ca0d5d07609ee50d85d68941c18d65f65f3c697c312	draft
fd99de13-0b57-4485-bcf6-7f66ab93bc51	98450c22-a798-42c4-89e6-f7737be16b58	1	\N	\N	created	\N	\N	\N	\N	1.0	SOY_LECITHIN	Soy Lecithin	Lecithin derived from soybean	1	\N	\N	\N	\N	2026-08-11 00:17:47.305371+00	2026-08-11 00:17:47.305371+00	\N	\N	677f0b6ef4da04ebf957ae76045bb761fc693cb34cf65d8021baaec811490e46	8715e82d8775a9c507d5eace4898418b53ab5481619de4f12be3bf62f780f981	draft
e801e0fc-5bad-46ec-944d-ffc731c69958	8f72fe51-a81d-4fe0-97e9-37636b0f3bd2	1	\N	\N	created	\N	\N	\N	\N	1.0	SESAME	Sesame	Sesame ingredient	1	\N	\N	\N	\N	2026-08-11 00:17:47.305371+00	2026-08-11 00:17:47.305371+00	\N	\N	969f3eb76b3830d90edaed5eb60eb393c76d5872de62a6c31225ba679d9121f1	e549072aff41abdb5a7fdd67159c4c5b1643713a5660da69a30fdd7395ef1e65	draft
95e22ff3-db88-4bd0-91e6-bf863fa53593	66c8b78e-ed88-4aeb-b856-30b2c413527b	1	\N	\N	created	\N	\N	\N	\N	1.0	ALMOND	Almond	Tree nut almond	1	\N	\N	\N	\N	2026-08-11 00:17:47.305371+00	2026-08-11 00:17:47.305371+00	\N	\N	89a6546f0f097737ed2f53b32a72c104d814438ae60361aa73c2979bf1f73bf6	eae3e26498a1994daf52ecfafbde54ca65321efcef6835a7334d280c73eda5d1	draft
7697031a-5e46-4336-b7e2-b61460691831	cfa55cbb-6646-4d98-8de1-047194fdbce1	1	\N	\N	created	\N	\N	\N	\N	1.0	CASHEW	Cashew	Tree nut cashew	1	\N	\N	\N	\N	2026-08-11 00:17:47.305371+00	2026-08-11 00:17:47.305371+00	\N	\N	47acd9b6608593936663661ccd474edd398c5c303c99cb5c5a36c97234b52216	c3ff57e8c1a1df558e082698b2fab01d2481cbae811ffb33beb630f20b090164	draft
85abc2df-04b1-43ef-84b0-6d71ce884dfc	c8e6a39c-564b-422f-b9a4-45b0bc179cb6	1	\N	\N	created	\N	\N	\N	\N	1.0	WALNUT	Walnut	Tree nut walnut	1	\N	\N	\N	\N	2026-08-11 00:17:47.305371+00	2026-08-11 00:17:47.305371+00	\N	\N	c15a7dbd6987608dfde1e60a42d625404ae64bb0e4a3175f9d23b85e0807455b	8731357aa1be9ca15fd57caf6f80752c5215793b2072d7f0544daba100776a1e	draft
6b7389e6-3936-4db3-883e-09c6327abd11	de40f5e6-ee92-4aba-89a1-d413c6dbf37c	1	\N	\N	created	\N	\N	\N	\N	1.0	FISH	Fish	Fish ingredient	1	\N	\N	\N	\N	2026-08-11 00:17:47.305371+00	2026-08-11 00:17:47.305371+00	\N	\N	d6af4c9f5a07bfb0bc3ea39d5263401a1df8a7834fda51b18ed9f408f79860c7	1ebbfa4315f290d7e841a0cf9020ae155ee6e2ddf6c36ec7c1b32a65c3b53cc2	draft
8f3e80f8-668d-4534-9f59-74427ec4a195	26f36e96-2965-4927-90ca-a548f22874db	1	\N	\N	created	\N	\N	\N	\N	1.0	SHRIMP	Shrimp	Crustacean ingredient	1	\N	\N	\N	\N	2026-08-11 00:17:47.305371+00	2026-08-11 00:17:47.305371+00	\N	\N	6eb34f3269846c6d57054d43f8c1932c6d1e5a6fc1b8271aaf83016c61d2985e	e11809614ce7ef86171f92f03093a9170f42f0b1ba2eea66917abb313d368d19	draft
b5f5a3df-eb40-4cee-90f3-d438456cfb63	4d49c54b-cf07-4fc0-9171-b15369254083	1	\N	\N	created	\N	\N	\N	\N	1.0	MUSTARD	Mustard	Mustard ingredient	1	\N	\N	\N	\N	2026-08-11 00:17:47.305371+00	2026-08-11 00:17:47.305371+00	\N	\N	3a6379e06be2c7c3961078af6b5dd926444c269e4b5612310a50edbfb8235aa0	66895087c156bd09ecbe10782d54e3eaf09e2d94c502a4e16f857b5d16db28ac	draft
\.


--
-- Data for Name: languages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.languages (id, code, name, native_name, is_rtl, status_id, version_number, created_at, updated_at, deleted_at) FROM stdin;
c43b9ba9-e823-42b3-b031-2a9ec3ece457	en	English	English	f	1	1	2026-08-11 00:28:03.944019+00	2026-08-11 00:28:03.944019+00	\N
4b80bc8d-396c-406c-b479-2c4274fed94a	ar	Arabic	العربية	f	1	1	2026-08-11 00:28:03.944019+00	2026-08-11 00:28:03.944019+00	\N
\.


--
-- Data for Name: lifecycle_statuses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.lifecycle_statuses (id, code, name, description, display_order, version_number, created_at, updated_at, deleted_at) FROM stdin;
1	ACTIVE	Active	Reference row is in service and eligible for use.	1	1	2026-08-10 11:12:51.728364+00	2026-08-10 11:12:51.728364+00	\N
2	DEPRECATED	Deprecated	No longer recommended; kept for history and referential integrity.	2	1	2026-08-10 11:12:51.728364+00	2026-08-10 11:12:51.728364+00	\N
3	ARCHIVED	Archived	Retired from use; preserved for audit and history.	3	1	2026-08-10 11:12:51.728364+00	2026-08-10 11:12:51.728364+00	\N
\.


--
-- Data for Name: measurement_bases; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.measurement_bases (id, code, name, description, display_order, status_id, version_number, created_at, updated_at, deleted_at) FROM stdin;
3a92802c-a58d-4398-9afe-7d28cd6fd3ea	PER_100ML	Per 100 ml	Nutritional value measured per 100 milliliters.	2	1	1	2026-08-13 19:15:29.500126+00	2026-08-13 19:15:29.500126+00	\N
6235c333-a2a4-493e-acfe-ed7cec9393b2	PER_100G	Per 100 g	Nutritional value measured per 100 grams.	1	1	1	2026-08-13 19:15:29.500126+00	2026-08-13 19:15:29.500126+00	\N
cdcfe62c-40be-460e-88ca-ab8b2c45af59	PER_PACKAGE	Per Package	Nutritional value measured for the full package.	4	1	1	2026-08-13 19:15:29.500126+00	2026-08-13 19:15:29.500126+00	\N
9f51e2f0-33ca-40ae-ad31-2ad6e14d042e	PER_SERVING	Per Serving	Nutritional value measured per serving.	3	1	1	2026-08-13 19:15:29.500126+00	2026-08-13 19:15:29.500126+00	\N
\.


--
-- Data for Name: nutrition_type_translations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.nutrition_type_translations (id, nutrition_type_id, language_id, name, short_name, display_name, search_name, description, translation_status, version_number, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: nutrition_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.nutrition_types (id, code, name, description, display_order, status_id, version_number, created_at, updated_at, deleted_at) FROM stdin;
f2b7e53a-7967-4b55-a56b-ddeecdcc84c4	ENERGY	Energy	\N	0	1	1	2026-08-11 00:28:08.092247+00	2026-08-11 00:28:08.092247+00	\N
7335b58d-bcae-4c91-abba-eb5b1d339296	PROTEIN	Protein	\N	0	1	1	2026-08-11 00:28:08.092247+00	2026-08-11 00:28:08.092247+00	\N
7d654278-5571-4d46-bb30-55c471c095b1	CARBOHYDRATE	Carbohydrate	\N	0	1	1	2026-08-11 00:28:08.092247+00	2026-08-11 00:28:08.092247+00	\N
64deae22-bb51-4bae-b7a1-08d619902b8e	TOTAL_FAT	Total Fat	\N	0	1	1	2026-08-11 00:28:08.092247+00	2026-08-11 00:28:08.092247+00	\N
25133cf1-fea4-4e9f-82ac-d00efa505d6d	SATURATED_FAT	Saturated Fat	\N	0	1	1	2026-08-11 00:28:08.092247+00	2026-08-11 00:28:08.092247+00	\N
09ba73d7-19a4-439b-948b-1a2b7fc52dfc	TRANS_FAT	Trans Fat	\N	0	1	1	2026-08-11 00:28:08.092247+00	2026-08-11 00:28:08.092247+00	\N
28a38949-f7b3-4ea8-8456-92538dc8262d	SODIUM	Sodium	\N	0	1	1	2026-08-11 00:28:08.092247+00	2026-08-11 00:28:08.092247+00	\N
0fd49348-3025-4661-9f91-b1d860a7c1a2	SUGAR	Sugar	\N	0	1	1	2026-08-11 00:28:08.092247+00	2026-08-11 00:28:08.092247+00	\N
8d483349-3d04-4894-8a7b-979b8f0380dc	FIBER	Dietary Fiber	\N	0	1	1	2026-08-11 00:28:08.092247+00	2026-08-11 00:28:08.092247+00	\N
\.


--
-- Data for Name: nutrition_types_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.nutrition_types_history (id, original_entity_id, version_number, previous_version_id, change_set_id, change_type, change_reason, changed_by, approved_by, source_id, confidence_level, code, name, description, display_order, status_id, deleted_at, created_at, effective_from, effective_to, superseded_at, snapshot_hash, checksum, version_status) FROM stdin;
793d9b6e-2bb4-48c7-85ec-752157894c3a	f2b7e53a-7967-4b55-a56b-ddeecdcc84c4	1	\N	\N	created	\N	\N	\N	\N	0.5	ENERGY	Energy	\N	0	1	\N	2026-08-11 00:28:08.092247+00	2026-08-11 00:28:08.092247+00	\N	\N	136901c218f7c75212b8243494160dcbdb91d2737d3834e0dca45f0be7ce5b34	7dc1b99377061447fc2ae9fb1f1fbee8f1441666ed4e4ee3d77fc053b790a33f	draft
ebddc02e-9e0c-4d12-8b2e-2a0b728bc382	7335b58d-bcae-4c91-abba-eb5b1d339296	1	\N	\N	created	\N	\N	\N	\N	0.5	PROTEIN	Protein	\N	0	1	\N	2026-08-11 00:28:08.092247+00	2026-08-11 00:28:08.092247+00	\N	\N	5a8028c4d87d9c3ef95b438b90c8562d2a499974431d5fb1dfe721bb0f08c367	dfecb48cb08a0f3b21fe4ae5fca652a1bd7b39df5ef534268895bceb66fd8208	draft
615318d2-a4dd-471d-b66b-fc3006d9eb6c	7d654278-5571-4d46-bb30-55c471c095b1	1	\N	\N	created	\N	\N	\N	\N	0.5	CARBOHYDRATE	Carbohydrate	\N	0	1	\N	2026-08-11 00:28:08.092247+00	2026-08-11 00:28:08.092247+00	\N	\N	7a0afbb6d54354485f6fe4aad8b06ade8eba2b6b60e5d7da5f413d51c1e255ca	a7e81e3a3d83bd7d2b7f3d646d9082c160e3902cd182b7542643422ce024fc32	draft
aaf3cee3-6cc3-4d6e-bd57-0041ba496ce9	64deae22-bb51-4bae-b7a1-08d619902b8e	1	\N	\N	created	\N	\N	\N	\N	0.5	TOTAL_FAT	Total Fat	\N	0	1	\N	2026-08-11 00:28:08.092247+00	2026-08-11 00:28:08.092247+00	\N	\N	696b80496051401c0808b65cac574701fea2655cf8d84411454e83058de07852	d0f3e46c79cc34f5f3597ec6b9ea32956c96cf7b63a5193cb14d6aa1bf8b8d80	draft
266547d6-877c-4398-b991-a29720780adb	25133cf1-fea4-4e9f-82ac-d00efa505d6d	1	\N	\N	created	\N	\N	\N	\N	0.5	SATURATED_FAT	Saturated Fat	\N	0	1	\N	2026-08-11 00:28:08.092247+00	2026-08-11 00:28:08.092247+00	\N	\N	7c58b972f8779fdcb625ca2f47c01d8208b1fba88f9105d0417379aff38d1668	a78c8b85f58219a9c5e2a1f73fc80d3681d8a6b538fc20c0e3679d660c200068	draft
8f70bcf2-9380-4fc7-afd4-70c00a33e30b	09ba73d7-19a4-439b-948b-1a2b7fc52dfc	1	\N	\N	created	\N	\N	\N	\N	0.5	TRANS_FAT	Trans Fat	\N	0	1	\N	2026-08-11 00:28:08.092247+00	2026-08-11 00:28:08.092247+00	\N	\N	4dea82a3f68183617576d8a7c19915fe4ea84f5d0d4a15a3c37a9da959bb8b92	27c3bc1af748684d7ca03febbfa4e0e5717de6d9cb866492260ee5a52b69a8cb	draft
20b0d381-6bcb-4634-9b93-45447b94a5f6	28a38949-f7b3-4ea8-8456-92538dc8262d	1	\N	\N	created	\N	\N	\N	\N	0.5	SODIUM	Sodium	\N	0	1	\N	2026-08-11 00:28:08.092247+00	2026-08-11 00:28:08.092247+00	\N	\N	d975669dba978a4cabd06fecff08ec40db7a1648f7493242f15bbe43daf28002	2a44781b769e764d6e1ecbb0a459ff87c1fb5ce95a2f6a24183fe100dff1d695	draft
9dedf331-206f-4036-87bb-b05b3ebb8194	0fd49348-3025-4661-9f91-b1d860a7c1a2	1	\N	\N	created	\N	\N	\N	\N	0.5	SUGAR	Sugar	\N	0	1	\N	2026-08-11 00:28:08.092247+00	2026-08-11 00:28:08.092247+00	\N	\N	72ca0fdb48ccb74b2289db5de70afa5087732082d42a6397ccc8491a5492424b	cbfc66caaf9cc4060921db0706ed06c53ebc9c7928c38564f3ead33ab489c467	draft
73bfda30-3284-4030-99e5-ad57626c804d	8d483349-3d04-4894-8a7b-979b8f0380dc	1	\N	\N	created	\N	\N	\N	\N	0.5	FIBER	Dietary Fiber	\N	0	1	\N	2026-08-11 00:28:08.092247+00	2026-08-11 00:28:08.092247+00	\N	\N	e112b26ecd3280cd0c46bd2bcc7e0639d1704495ffc2f6813c2c40f4fa22898c	79222d29ce662c23ed56f7bb9fc915ac3c083bb9632b344dcac827b6835a7c9d	draft
\.


--
-- Data for Name: package_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.package_types (id, code, name, description, display_order, status_id, version_number, created_at, updated_at, deleted_at) FROM stdin;
aa3666d3-234d-4ce7-87a7-26ccf072ac93	BOTTLE	Bottle	\N	0	1	1	2026-08-11 00:13:05.655222+00	2026-08-11 00:13:05.655222+00	\N
450d1161-4f47-45f3-97e2-539566e5aafb	BOX	Box	\N	0	1	1	2026-08-11 00:13:05.655222+00	2026-08-11 00:13:05.655222+00	\N
1646ce88-63a2-47b0-aaa0-e9613688b15a	CAN	Can	\N	0	1	1	2026-08-11 00:13:05.655222+00	2026-08-11 00:13:05.655222+00	\N
f9ee6fc5-d4b2-4e7e-898a-d33a120f1e3d	BAG	Bag	\N	0	1	1	2026-08-11 00:13:05.655222+00	2026-08-11 00:13:05.655222+00	\N
ff50981e-fcd4-4431-b38c-58ef3dea7e9b	CARTON	Carton	\N	0	1	1	2026-08-11 00:13:05.655222+00	2026-08-11 00:13:05.655222+00	\N
fe249e86-0cc7-4c8e-bc94-a5243f13567d	JAR	Jar	\N	0	1	1	2026-08-11 00:13:05.655222+00	2026-08-11 00:13:05.655222+00	\N
8f4c183c-fb10-4e6f-8f80-56f7a3066352	POUCH	Pouch	\N	0	1	1	2026-08-11 00:13:05.655222+00	2026-08-11 00:13:05.655222+00	\N
ff1c4c91-d191-4b58-8d1f-286d0e2c604d	OTHER	Other	\N	0	1	1	2026-08-11 00:13:05.655222+00	2026-08-11 00:13:05.655222+00	\N
\.


--
-- Data for Name: permission_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.permission_types (id, code, name, description, display_order, status_id, version_number, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: product_allergens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_allergens (id, product_id, allergen_id, relationship_type_id, source_id, evidence_type_id, confidence_level, effective_from, effective_to, verified_at, approved_at, status_id, version_number, created_at, updated_at, deleted_at) FROM stdin;
4b80d265-c4e2-4d8b-98e4-f765ac4f5f00	1915540e-716f-4ed1-93c0-208f79b95245	2cfdcf5e-487a-4c61-bdbd-e5acbac726d0	18fa6ec8-afd8-40b2-b468-adc78bd6be12	65e8a675-805d-49a2-87ad-d3b62a9ba86d	8b8071bd-53f4-4896-9587-d0114af571c3	1.0	\N	\N	\N	\N	1	1	2026-08-12 17:57:43.00436+00	2026-08-12 17:57:43.00436+00	\N
c0ac5ec0-0d62-4dff-b287-bdedf1c6669b	523b923e-2e00-424f-b6eb-8e8797a06025	5c302be6-3afe-4ed7-919c-c308158bc54e	18fa6ec8-afd8-40b2-b468-adc78bd6be12	65e8a675-805d-49a2-87ad-d3b62a9ba86d	8b8071bd-53f4-4896-9587-d0114af571c3	1.0	\N	\N	\N	\N	1	1	2026-08-12 17:57:43.00436+00	2026-08-12 17:57:43.00436+00	\N
81dc6323-7b02-425b-8b67-4a77839ce01c	5c1df2b4-e59d-424d-a4b5-ddd1311e7b34	5c302be6-3afe-4ed7-919c-c308158bc54e	18fa6ec8-afd8-40b2-b468-adc78bd6be12	65e8a675-805d-49a2-87ad-d3b62a9ba86d	8b8071bd-53f4-4896-9587-d0114af571c3	1.0	\N	\N	\N	\N	1	1	2026-08-12 17:57:43.00436+00	2026-08-12 17:57:43.00436+00	\N
2c107f37-e5e6-4592-af1a-9c40ae46e437	92a49394-f8bd-4969-9dce-7ffa05e97feb	5c302be6-3afe-4ed7-919c-c308158bc54e	18fa6ec8-afd8-40b2-b468-adc78bd6be12	65e8a675-805d-49a2-87ad-d3b62a9ba86d	8b8071bd-53f4-4896-9587-d0114af571c3	1.0	\N	\N	\N	\N	1	1	2026-08-12 17:57:43.00436+00	2026-08-12 17:57:43.00436+00	\N
6aab2855-a77a-49fe-b448-835e60e134f3	b6cd3e32-ca24-496b-b5fa-8ea3f8bed5c2	2cfdcf5e-487a-4c61-bdbd-e5acbac726d0	18fa6ec8-afd8-40b2-b468-adc78bd6be12	65e8a675-805d-49a2-87ad-d3b62a9ba86d	8b8071bd-53f4-4896-9587-d0114af571c3	1.0	\N	\N	\N	\N	1	1	2026-08-12 17:57:43.00436+00	2026-08-12 17:57:43.00436+00	\N
34340aef-a485-4b71-ae12-251acc8c1654	cd029de1-856f-4952-b1ed-cd0cb2b06879	f62d44e1-1646-450a-b8ee-2a6adf6cd7cd	18fa6ec8-afd8-40b2-b468-adc78bd6be12	65e8a675-805d-49a2-87ad-d3b62a9ba86d	8b8071bd-53f4-4896-9587-d0114af571c3	1.0	\N	\N	\N	\N	1	1	2026-08-12 17:57:43.00436+00	2026-08-12 17:57:43.00436+00	\N
7e0273ce-beae-41fc-9fab-a1963b019512	d743db46-c247-4217-a28f-0063189f41eb	4bc260bc-d95a-4a8b-84c1-c7c6cdbdfced	18fa6ec8-afd8-40b2-b468-adc78bd6be12	65e8a675-805d-49a2-87ad-d3b62a9ba86d	8b8071bd-53f4-4896-9587-d0114af571c3	1.0	\N	\N	\N	\N	1	1	2026-08-12 17:57:43.00436+00	2026-08-12 17:57:43.00436+00	\N
\.


--
-- Data for Name: product_barcodes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_barcodes (id, product_id, barcode_id, relationship_type_id, source_id, evidence_type_id, confidence_level, effective_from, effective_to, verified_at, approved_at, status_id, version_number, created_at, updated_at, deleted_at) FROM stdin;
e6bca23b-dfae-43fc-8ced-cdc36692307c	cd029de1-856f-4952-b1ed-cd0cb2b06879	1735210f-d5ad-476d-9e36-da15f3584a2c	7489a8be-be9a-4f22-b472-96f7140295be	65e8a675-805d-49a2-87ad-d3b62a9ba86d	8b8071bd-53f4-4896-9587-d0114af571c3	1.0	\N	\N	\N	\N	1	1	2026-08-12 18:00:11.498008+00	2026-08-12 18:00:11.498008+00	\N
2298d454-4b8f-4c4f-a64d-986d05c24059	d743db46-c247-4217-a28f-0063189f41eb	627e6069-b55a-42b1-8ffa-c5b03c67877e	7489a8be-be9a-4f22-b472-96f7140295be	65e8a675-805d-49a2-87ad-d3b62a9ba86d	8b8071bd-53f4-4896-9587-d0114af571c3	1.0	\N	\N	\N	\N	1	1	2026-08-12 18:00:11.498008+00	2026-08-12 18:00:11.498008+00	\N
a8ce1cef-102f-4f67-b4fc-f50d95ccccc5	b6cd3e32-ca24-496b-b5fa-8ea3f8bed5c2	e8dc8a10-8560-4e57-851f-05c83c5570ec	7489a8be-be9a-4f22-b472-96f7140295be	65e8a675-805d-49a2-87ad-d3b62a9ba86d	8b8071bd-53f4-4896-9587-d0114af571c3	1.0	\N	\N	\N	\N	1	1	2026-08-12 18:00:11.498008+00	2026-08-12 18:00:11.498008+00	\N
bfdab0db-56c2-48dc-883c-22da4c8e8dd1	5c1df2b4-e59d-424d-a4b5-ddd1311e7b34	5088e20c-e943-4a4b-aa1d-602a4e3dccff	7489a8be-be9a-4f22-b472-96f7140295be	65e8a675-805d-49a2-87ad-d3b62a9ba86d	8b8071bd-53f4-4896-9587-d0114af571c3	1.0	\N	\N	\N	\N	1	1	2026-08-12 18:00:11.498008+00	2026-08-12 18:00:11.498008+00	\N
483ab0eb-7837-4f0e-be43-45a5f89466f4	92a49394-f8bd-4969-9dce-7ffa05e97feb	28532d4a-6776-44ec-b86e-3fd3b4f67403	7489a8be-be9a-4f22-b472-96f7140295be	65e8a675-805d-49a2-87ad-d3b62a9ba86d	8b8071bd-53f4-4896-9587-d0114af571c3	1.0	\N	\N	\N	\N	1	1	2026-08-12 18:00:11.498008+00	2026-08-12 18:00:11.498008+00	\N
6b8c3945-cc49-4fb7-968c-e9413bffc34c	1915540e-716f-4ed1-93c0-208f79b95245	b4b93651-7600-4992-ae9b-2604e917f4aa	7489a8be-be9a-4f22-b472-96f7140295be	65e8a675-805d-49a2-87ad-d3b62a9ba86d	8b8071bd-53f4-4896-9587-d0114af571c3	1.0	\N	\N	\N	\N	1	1	2026-08-12 18:00:11.498008+00	2026-08-12 18:00:11.498008+00	\N
343b2a3c-8688-47cc-a63d-f9ae6683bd26	523b923e-2e00-424f-b6eb-8e8797a06025	2a491400-4249-4466-afee-36ca917f35ed	7489a8be-be9a-4f22-b472-96f7140295be	65e8a675-805d-49a2-87ad-d3b62a9ba86d	8b8071bd-53f4-4896-9587-d0114af571c3	1.0	\N	\N	\N	\N	1	41	2026-08-12 18:00:11.498008+00	2026-08-18 02:05:53.181173+00	\N
\.


--
-- Data for Name: product_barcodes_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_barcodes_history (id, original_entity_id, version_number, previous_version_id, change_set_id, change_type, change_reason, changed_by, approved_by, source_id, confidence_level, product_id, barcode_id, relationship_type_id, evidence_type_id, effective_from, effective_to, verified_at, approved_at, status_id, deleted_at, created_at, superseded_at, snapshot_hash, checksum, version_status) FROM stdin;
2f2b2697-ae13-40e4-930a-4052a8203e5b	e6bca23b-dfae-43fc-8ced-cdc36692307c	1	\N	\N	created	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	cd029de1-856f-4952-b1ed-cd0cb2b06879	1735210f-d5ad-476d-9e36-da15f3584a2c	7489a8be-be9a-4f22-b472-96f7140295be	8b8071bd-53f4-4896-9587-d0114af571c3	\N	\N	\N	\N	1	\N	2026-08-12 18:00:11.498008+00	\N	8ac245a273a8a2cc3ba42fb8a3b07f1f2a9c0de78e2c3ced4e4d840430ba27a9	5cee50028fdefbcae8d7555d6c6dcb00750c9c7857bffaccb1e437bd1952badc	draft
dd949597-fa25-48c0-b595-1aaa2f2b1ca3	2298d454-4b8f-4c4f-a64d-986d05c24059	1	\N	\N	created	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	d743db46-c247-4217-a28f-0063189f41eb	627e6069-b55a-42b1-8ffa-c5b03c67877e	7489a8be-be9a-4f22-b472-96f7140295be	8b8071bd-53f4-4896-9587-d0114af571c3	\N	\N	\N	\N	1	\N	2026-08-12 18:00:11.498008+00	\N	c9e415d0ea7d6fafe886dc69a2546578aff55e0a0deacf486bfea44c05651fb5	e21071b8eb31c353b5d49bf64cab211690abf94deac09387feab29edcc816387	draft
dc82c312-831b-433c-a01a-2f91c9c98a8c	343b2a3c-8688-47cc-a63d-f9ae6683bd26	1	\N	\N	created	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	523b923e-2e00-424f-b6eb-8e8797a06025	2a491400-4249-4466-afee-36ca917f35ed	7489a8be-be9a-4f22-b472-96f7140295be	8b8071bd-53f4-4896-9587-d0114af571c3	\N	\N	\N	\N	1	\N	2026-08-12 18:00:11.498008+00	\N	3cdad015d1ca561e06755e97be06b6fa36d0c3bcbe5492808d5bc53bc49846bb	86cdc6e2d9075525056476c0c3df1ae8619b5163e8b677665fb19f020ae60a79	draft
9c402cea-5abf-4851-bc70-73b3ccf390c0	a8ce1cef-102f-4f67-b4fc-f50d95ccccc5	1	\N	\N	created	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	b6cd3e32-ca24-496b-b5fa-8ea3f8bed5c2	e8dc8a10-8560-4e57-851f-05c83c5570ec	7489a8be-be9a-4f22-b472-96f7140295be	8b8071bd-53f4-4896-9587-d0114af571c3	\N	\N	\N	\N	1	\N	2026-08-12 18:00:11.498008+00	\N	4df9be0e5dd3e91d3c4a22434786c23bee871b7ae6aa61495a787c68bac65c95	9887e9513a589953736e62182f6d3e8f230592654710a199aad80aca17ffc8bb	draft
c725f906-4aea-454c-9cf1-717b57b28cd5	bfdab0db-56c2-48dc-883c-22da4c8e8dd1	1	\N	\N	created	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	5c1df2b4-e59d-424d-a4b5-ddd1311e7b34	5088e20c-e943-4a4b-aa1d-602a4e3dccff	7489a8be-be9a-4f22-b472-96f7140295be	8b8071bd-53f4-4896-9587-d0114af571c3	\N	\N	\N	\N	1	\N	2026-08-12 18:00:11.498008+00	\N	5818be36b58ef2114eb848ae09097d2cb54b2aa69185b52214682fdfcd71eed3	86b2a22f078729709b570762aadd1b58905e3909fa7dbd315eb5fee20ee3e1e1	draft
f4a77af6-d3a0-459f-a691-049cb70ab8ce	483ab0eb-7837-4f0e-be43-45a5f89466f4	1	\N	\N	created	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	92a49394-f8bd-4969-9dce-7ffa05e97feb	28532d4a-6776-44ec-b86e-3fd3b4f67403	7489a8be-be9a-4f22-b472-96f7140295be	8b8071bd-53f4-4896-9587-d0114af571c3	\N	\N	\N	\N	1	\N	2026-08-12 18:00:11.498008+00	\N	0676c96ff797253c77b0774bc4cf9c400819f8e989907d3fe61052c35ef64d55	f1daa90b7938ae0e815c0a7950e5e76fdda393c875c80a5a3fc3de68e4462b29	draft
999515f9-c7d2-4557-99db-3193974d4ae0	6b8c3945-cc49-4fb7-968c-e9413bffc34c	1	\N	\N	created	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	1915540e-716f-4ed1-93c0-208f79b95245	b4b93651-7600-4992-ae9b-2604e917f4aa	7489a8be-be9a-4f22-b472-96f7140295be	8b8071bd-53f4-4896-9587-d0114af571c3	\N	\N	\N	\N	1	\N	2026-08-12 18:00:11.498008+00	\N	6b05b2e2e09805819bc5360858acac5c7517b0e7f46b0bafe9ab912792b1bca3	0e272a95f9225eefacb2b6bf564353bd856671ea67c892b4dff1e10050f31b65	draft
e26a2a5f-b43c-4d75-abb5-0d811f0d9e15	343b2a3c-8688-47cc-a63d-f9ae6683bd26	30	fc5f97a1-7403-40ea-bcae-de5193d97929	\N	modified	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	523b923e-2e00-424f-b6eb-8e8797a06025	2a491400-4249-4466-afee-36ca917f35ed	7489a8be-be9a-4f22-b472-96f7140295be	8b8071bd-53f4-4896-9587-d0114af571c3	\N	2025-08-18 01:38:35.696882+00	\N	\N	1	\N	2026-08-12 18:00:11.498008+00	\N	a746fd7d9262e5420dbb6b88e9130bbf6a56025677bf4791de73743ff672e4eb	68f5b943af30a387ad0068d2e602251162ea65cb67c8c5e369323f7302f11717	draft
b85ccf2f-6737-48ee-86d6-932f3e4d2183	343b2a3c-8688-47cc-a63d-f9ae6683bd26	31	e26a2a5f-b43c-4d75-abb5-0d811f0d9e15	\N	modified	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	523b923e-2e00-424f-b6eb-8e8797a06025	2a491400-4249-4466-afee-36ca917f35ed	7489a8be-be9a-4f22-b472-96f7140295be	8b8071bd-53f4-4896-9587-d0114af571c3	\N	\N	\N	\N	1	\N	2026-08-12 18:00:11.498008+00	\N	77b21ae02a19d0a33a756a029bff248981663d04d97deedf2b79d5d773edd13e	597885187e304008147fdfeddc87d33ef94bbd6dc44327a24b607180cd3d82f4	draft
7c482e6e-83a5-4244-b2d5-a639c76b984d	343b2a3c-8688-47cc-a63d-f9ae6683bd26	34	617fcd31-c1fe-44c4-a152-245d60d06cf8	\N	modified	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	523b923e-2e00-424f-b6eb-8e8797a06025	2a491400-4249-4466-afee-36ca917f35ed	7489a8be-be9a-4f22-b472-96f7140295be	8b8071bd-53f4-4896-9587-d0114af571c3	\N	2025-08-18 02:05:00.161501+00	\N	\N	1	\N	2026-08-12 18:00:11.498008+00	\N	856c528ec423c6040137037215cad02628a2bef0ec7ff14f9b522a9e26cf809a	995d8dc5471f40fbd8b43d0fd1261b942c3632fbdcb1e6a7f7092491c705731f	draft
8145432f-2835-44ab-9f7f-e1306cb61942	343b2a3c-8688-47cc-a63d-f9ae6683bd26	35	7c482e6e-83a5-4244-b2d5-a639c76b984d	\N	modified	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	523b923e-2e00-424f-b6eb-8e8797a06025	2a491400-4249-4466-afee-36ca917f35ed	7489a8be-be9a-4f22-b472-96f7140295be	8b8071bd-53f4-4896-9587-d0114af571c3	\N	\N	\N	\N	1	\N	2026-08-12 18:00:11.498008+00	\N	a94cecbd3521df1043c419ef7a8383238974c49188f8bbab51f03d4032a21af6	101ca0cb5512aa73d204b8e49512d75f3773fdc0003e8f67be8f381c01908129	draft
85916e90-c684-49e9-bdb3-1ac82b8120e5	343b2a3c-8688-47cc-a63d-f9ae6683bd26	38	c63bf51f-e91e-4349-bd01-443d03feb62a	\N	modified	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	523b923e-2e00-424f-b6eb-8e8797a06025	2a491400-4249-4466-afee-36ca917f35ed	7489a8be-be9a-4f22-b472-96f7140295be	8b8071bd-53f4-4896-9587-d0114af571c3	\N	2025-08-18 02:05:52.368409+00	\N	\N	1	\N	2026-08-12 18:00:11.498008+00	\N	5a117dffde80faf705ebe958d3b07d5412379d7038733f4aebef0fd41ba3cd5f	9c3e1f7740e45a7d1cd41213889343e333e5ec1579c307d3701066072a3f4c90	draft
4bdc1964-637b-4404-856a-6347a98d4d28	343b2a3c-8688-47cc-a63d-f9ae6683bd26	39	85916e90-c684-49e9-bdb3-1ac82b8120e5	\N	modified	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	523b923e-2e00-424f-b6eb-8e8797a06025	2a491400-4249-4466-afee-36ca917f35ed	7489a8be-be9a-4f22-b472-96f7140295be	8b8071bd-53f4-4896-9587-d0114af571c3	\N	\N	\N	\N	1	\N	2026-08-12 18:00:11.498008+00	\N	558c96d791f93261eff0793e830cd977a395aa040cc1208a9f11a0a973816a9b	2d39e4979874d163164b55abea00e221dbc5e838cd1e910197f312f2a78f4759	draft
3a82f449-3a9d-47a6-925e-a800041ebc08	343b2a3c-8688-47cc-a63d-f9ae6683bd26	32	b85ccf2f-6737-48ee-86d6-932f3e4d2183	\N	modified	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	523b923e-2e00-424f-b6eb-8e8797a06025	2a491400-4249-4466-afee-36ca917f35ed	7489a8be-be9a-4f22-b472-96f7140295be	8b8071bd-53f4-4896-9587-d0114af571c3	2027-08-18 01:38:36.244306+00	\N	\N	\N	1	\N	2026-08-12 18:00:11.498008+00	\N	6c8bcde289f5773c27989e1cbc5fc31af02938f007e9c31ad91bdeda2626b457	5908349c726a1887f0b89028614c51c7904ef4017058cbde3bd8930a9295d172	draft
617fcd31-c1fe-44c4-a152-245d60d06cf8	343b2a3c-8688-47cc-a63d-f9ae6683bd26	33	3a82f449-3a9d-47a6-925e-a800041ebc08	\N	modified	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	523b923e-2e00-424f-b6eb-8e8797a06025	2a491400-4249-4466-afee-36ca917f35ed	7489a8be-be9a-4f22-b472-96f7140295be	8b8071bd-53f4-4896-9587-d0114af571c3	\N	\N	\N	\N	1	\N	2026-08-12 18:00:11.498008+00	\N	bc16792061edabe38d9c1abf63083b5285e5172649e5f8a11abc189aff7923d7	7cd7869ef90da53496d47cef45986dcdbaf14982f1e5b78bacd18e78f9c6fd32	draft
7dd95aff-202a-4872-8159-05326f82d342	343b2a3c-8688-47cc-a63d-f9ae6683bd26	36	8145432f-2835-44ab-9f7f-e1306cb61942	\N	modified	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	523b923e-2e00-424f-b6eb-8e8797a06025	2a491400-4249-4466-afee-36ca917f35ed	7489a8be-be9a-4f22-b472-96f7140295be	8b8071bd-53f4-4896-9587-d0114af571c3	2027-08-18 02:05:00.54536+00	\N	\N	\N	1	\N	2026-08-12 18:00:11.498008+00	\N	be846bdbc04748fa325e02be6810984195e4dbabd0a2a5b92501248d38230524	77c8e1db187f55789b5677a1e6008422dec3edffdabd6ec1cb66d88e98cca862	draft
c63bf51f-e91e-4349-bd01-443d03feb62a	343b2a3c-8688-47cc-a63d-f9ae6683bd26	37	7dd95aff-202a-4872-8159-05326f82d342	\N	modified	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	523b923e-2e00-424f-b6eb-8e8797a06025	2a491400-4249-4466-afee-36ca917f35ed	7489a8be-be9a-4f22-b472-96f7140295be	8b8071bd-53f4-4896-9587-d0114af571c3	\N	\N	\N	\N	1	\N	2026-08-12 18:00:11.498008+00	\N	116beff99307025877ab74ffd7e7b92639486939de4d7954e866d192429c4d76	937a593b22d731d7c9797c602a72cc6f0801532e5fbb1b8b1e8e15d114dda346	draft
69f6fb92-f84a-44b7-8505-0425e70c2495	343b2a3c-8688-47cc-a63d-f9ae6683bd26	40	4bdc1964-637b-4404-856a-6347a98d4d28	\N	modified	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	523b923e-2e00-424f-b6eb-8e8797a06025	2a491400-4249-4466-afee-36ca917f35ed	7489a8be-be9a-4f22-b472-96f7140295be	8b8071bd-53f4-4896-9587-d0114af571c3	2027-08-18 02:05:52.980533+00	\N	\N	\N	1	\N	2026-08-12 18:00:11.498008+00	\N	8e8c46e3f8e3ee624daf7338c0a24354dbcded302b0b4cc5800cbb4204d30fa3	f080d02c915049324bfeb1193dc40d4e6490b2023927c665667a990248ac03af	draft
6aff9711-5228-4d19-8bd6-23d808587600	343b2a3c-8688-47cc-a63d-f9ae6683bd26	41	69f6fb92-f84a-44b7-8505-0425e70c2495	\N	modified	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	523b923e-2e00-424f-b6eb-8e8797a06025	2a491400-4249-4466-afee-36ca917f35ed	7489a8be-be9a-4f22-b472-96f7140295be	8b8071bd-53f4-4896-9587-d0114af571c3	\N	\N	\N	\N	1	\N	2026-08-12 18:00:11.498008+00	\N	1ce72076f047fb38a280d172e231896c264d503b6eabf7695d5c9fcf92d2be85	7f69a7b4d878c865ffad0e64636f5e85e0c50729982b74e6881d7fb3051ac359	draft
e7fc9190-97d6-48bf-8b3d-f4fb129362f3	343b2a3c-8688-47cc-a63d-f9ae6683bd26	2	dc82c312-831b-433c-a01a-2f91c9c98a8c	\N	modified	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	523b923e-2e00-424f-b6eb-8e8797a06025	2a491400-4249-4466-afee-36ca917f35ed	7489a8be-be9a-4f22-b472-96f7140295be	8b8071bd-53f4-4896-9587-d0114af571c3	\N	2025-08-18 00:40:40.499787+00	\N	\N	1	\N	2026-08-12 18:00:11.498008+00	\N	d3a7cbb416bd254519e4521930c807ec0031ec4eaa3e909938c05db84e3d01d9	1864f0480218019038fb9136c3a284141a2cf57d855910c8cd1b97a64037048f	draft
8e34170c-1f6d-4cc5-b397-fc46d0681a6d	343b2a3c-8688-47cc-a63d-f9ae6683bd26	3	e7fc9190-97d6-48bf-8b3d-f4fb129362f3	\N	modified	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	523b923e-2e00-424f-b6eb-8e8797a06025	2a491400-4249-4466-afee-36ca917f35ed	7489a8be-be9a-4f22-b472-96f7140295be	8b8071bd-53f4-4896-9587-d0114af571c3	\N	\N	\N	\N	1	\N	2026-08-12 18:00:11.498008+00	\N	2b5d5160eecd6603a2c9da70a74e1225e27f7a220e459e7fbb04e03e5fccc885	b3dfda3ee8eeedf3b75d4277ad3d7d19905a9ef6f3b6ada1e2e8cfb704b0f478	draft
293daafb-5111-4066-9072-58598e727f83	343b2a3c-8688-47cc-a63d-f9ae6683bd26	4	8e34170c-1f6d-4cc5-b397-fc46d0681a6d	\N	modified	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	523b923e-2e00-424f-b6eb-8e8797a06025	2a491400-4249-4466-afee-36ca917f35ed	7489a8be-be9a-4f22-b472-96f7140295be	8b8071bd-53f4-4896-9587-d0114af571c3	2027-08-18 00:40:40.920075+00	\N	\N	\N	1	\N	2026-08-12 18:00:11.498008+00	\N	bdeba345f276f8c05347c795994d3eafc128cc7ffb37be2b794ba111ee0c53dc	d9b9814678749ba6472e60ba4083bdab6f4bd2756f38b823e78b4ae4f457c8be	draft
bad5fc86-f8f4-4e38-9f88-e201cec36963	343b2a3c-8688-47cc-a63d-f9ae6683bd26	5	293daafb-5111-4066-9072-58598e727f83	\N	modified	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	523b923e-2e00-424f-b6eb-8e8797a06025	2a491400-4249-4466-afee-36ca917f35ed	7489a8be-be9a-4f22-b472-96f7140295be	8b8071bd-53f4-4896-9587-d0114af571c3	\N	\N	\N	\N	1	\N	2026-08-12 18:00:11.498008+00	\N	f5d1bd7833fb7cbc4dd95e035d70b65721514251dcf7bd0d9d9b13b56eb2a5dd	4d75bc9c8f18850f9cc3f7225a698f60e4ace8197540bdda55243840f876b858	draft
0329d4e5-2582-48fb-b2d5-2f9f3bab93be	343b2a3c-8688-47cc-a63d-f9ae6683bd26	6	bad5fc86-f8f4-4e38-9f88-e201cec36963	\N	modified	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	523b923e-2e00-424f-b6eb-8e8797a06025	2a491400-4249-4466-afee-36ca917f35ed	7489a8be-be9a-4f22-b472-96f7140295be	8b8071bd-53f4-4896-9587-d0114af571c3	\N	2025-08-18 00:41:53.900896+00	\N	\N	1	\N	2026-08-12 18:00:11.498008+00	\N	674f86fbfac5638b7decb17a39fcdc09967bde32aa46cb0dd405f6c2fbb11705	090848c8347a7e12ff49d3df51ec9a1b826373a6216d271ee1865211aeef339b	draft
8da74eeb-3e14-4bf2-8261-33fd8d622fdd	343b2a3c-8688-47cc-a63d-f9ae6683bd26	7	0329d4e5-2582-48fb-b2d5-2f9f3bab93be	\N	modified	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	523b923e-2e00-424f-b6eb-8e8797a06025	2a491400-4249-4466-afee-36ca917f35ed	7489a8be-be9a-4f22-b472-96f7140295be	8b8071bd-53f4-4896-9587-d0114af571c3	\N	\N	\N	\N	1	\N	2026-08-12 18:00:11.498008+00	\N	ffcff09fb0032ad880e83fe3e3af7d7a0a1def7f8807741e7744d9a058302e13	ff55d8ca49504ffb350f8b6072ab7fb2d2485a48e71d9634859e78cfe8df3b76	draft
af64e527-2e30-40a6-a630-d22732fa9684	343b2a3c-8688-47cc-a63d-f9ae6683bd26	8	8da74eeb-3e14-4bf2-8261-33fd8d622fdd	\N	modified	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	523b923e-2e00-424f-b6eb-8e8797a06025	2a491400-4249-4466-afee-36ca917f35ed	7489a8be-be9a-4f22-b472-96f7140295be	8b8071bd-53f4-4896-9587-d0114af571c3	2027-08-18 00:41:54.285245+00	\N	\N	\N	1	\N	2026-08-12 18:00:11.498008+00	\N	620c07ae2cbe9ec62e617b32ce152fc3a50915dbce999aeae70df026e4e3f1b2	58f223f6aed6b5feebe16b3686981506a505d2cf0c17eec0c7ef977ae4726da5	draft
8d678a5f-cdc2-4507-b720-584e62c1d5a7	343b2a3c-8688-47cc-a63d-f9ae6683bd26	9	af64e527-2e30-40a6-a630-d22732fa9684	\N	modified	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	523b923e-2e00-424f-b6eb-8e8797a06025	2a491400-4249-4466-afee-36ca917f35ed	7489a8be-be9a-4f22-b472-96f7140295be	8b8071bd-53f4-4896-9587-d0114af571c3	\N	\N	\N	\N	1	\N	2026-08-12 18:00:11.498008+00	\N	4b2259173dd6cd42d91088e86c9b4cf75161d886889139895ea2c5da4fcdd8b0	b61aafa12aadb715723dd87e76d6d40f59da66e0acd9d42f011a7047204864f6	draft
9d57ab3f-2028-4e85-a8e1-9b441f7afe97	343b2a3c-8688-47cc-a63d-f9ae6683bd26	10	8d678a5f-cdc2-4507-b720-584e62c1d5a7	\N	modified	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	523b923e-2e00-424f-b6eb-8e8797a06025	2a491400-4249-4466-afee-36ca917f35ed	7489a8be-be9a-4f22-b472-96f7140295be	8b8071bd-53f4-4896-9587-d0114af571c3	\N	2025-08-18 00:59:05.601878+00	\N	\N	1	\N	2026-08-12 18:00:11.498008+00	\N	178c175f746cf3fe93d8c8de52350cdb0fcd8e21cb4977d00cf9c7568411eed0	b35c8625fdab4e8e2cfabdde26aced3819c7fad32ae4052a75e37c7f7b849b20	draft
477a622a-a5e6-4040-9046-6ae2de69d1f1	343b2a3c-8688-47cc-a63d-f9ae6683bd26	11	9d57ab3f-2028-4e85-a8e1-9b441f7afe97	\N	modified	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	523b923e-2e00-424f-b6eb-8e8797a06025	2a491400-4249-4466-afee-36ca917f35ed	7489a8be-be9a-4f22-b472-96f7140295be	8b8071bd-53f4-4896-9587-d0114af571c3	\N	\N	\N	\N	1	\N	2026-08-12 18:00:11.498008+00	\N	a99b6b0d440242d236def110e6a4c5c717d766d328a8e862560240a2c045519f	3ed693ba7d4e7280e09ae9b833edbcc5e3cc0348e3bdeb484ac0abe21d2341bc	draft
975f572d-0169-4d12-9b6c-2ddd996105b2	343b2a3c-8688-47cc-a63d-f9ae6683bd26	12	477a622a-a5e6-4040-9046-6ae2de69d1f1	\N	modified	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	523b923e-2e00-424f-b6eb-8e8797a06025	2a491400-4249-4466-afee-36ca917f35ed	7489a8be-be9a-4f22-b472-96f7140295be	8b8071bd-53f4-4896-9587-d0114af571c3	2027-08-18 00:59:06.07226+00	\N	\N	\N	1	\N	2026-08-12 18:00:11.498008+00	\N	3adebce471f22db0114872327d8e50b8262a9916142edd3dccdc4bb53900c339	cf851f9613ac57d68291d13a39700b11bd17a8f4266303531d0350bbdfa3b2e6	draft
52a1f45f-1066-49fc-b49c-86a627d1f645	343b2a3c-8688-47cc-a63d-f9ae6683bd26	13	975f572d-0169-4d12-9b6c-2ddd996105b2	\N	modified	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	523b923e-2e00-424f-b6eb-8e8797a06025	2a491400-4249-4466-afee-36ca917f35ed	7489a8be-be9a-4f22-b472-96f7140295be	8b8071bd-53f4-4896-9587-d0114af571c3	\N	\N	\N	\N	1	\N	2026-08-12 18:00:11.498008+00	\N	0af3aae34f24e31616990bf516b4578c2739f5c66e00d2ecd1e8cf6f8043deb7	75ac8e59d42023cac3b6c487dc3bb0f99b5b21e206258e89e536aa406ed0d1fd	draft
b0a34507-bba2-4f34-adf8-4fbe11d36485	343b2a3c-8688-47cc-a63d-f9ae6683bd26	14	52a1f45f-1066-49fc-b49c-86a627d1f645	\N	modified	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	523b923e-2e00-424f-b6eb-8e8797a06025	2a491400-4249-4466-afee-36ca917f35ed	7489a8be-be9a-4f22-b472-96f7140295be	8b8071bd-53f4-4896-9587-d0114af571c3	\N	2025-08-18 01:05:35.455154+00	\N	\N	1	\N	2026-08-12 18:00:11.498008+00	\N	f8f9c86fae0b9253d93ed14b8db3d30699592988e4370fd8a679b4343a684862	2832c7e462580083ab73a574196b9f80def65a30b1aa37d8935db3743b83a1dd	draft
189fa8fe-cc0b-4b88-810e-9ca006a60d58	343b2a3c-8688-47cc-a63d-f9ae6683bd26	15	b0a34507-bba2-4f34-adf8-4fbe11d36485	\N	modified	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	523b923e-2e00-424f-b6eb-8e8797a06025	2a491400-4249-4466-afee-36ca917f35ed	7489a8be-be9a-4f22-b472-96f7140295be	8b8071bd-53f4-4896-9587-d0114af571c3	\N	\N	\N	\N	1	\N	2026-08-12 18:00:11.498008+00	\N	186c40955509eea00d930db5391c71a52954ac051507440255229f42612a08ab	6dee1f7719c526a26e13fadc2e05977831dd79702c82072688515ac3d125a062	draft
5e96237c-428f-4244-977b-d5db4b84401b	343b2a3c-8688-47cc-a63d-f9ae6683bd26	16	189fa8fe-cc0b-4b88-810e-9ca006a60d58	\N	modified	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	523b923e-2e00-424f-b6eb-8e8797a06025	2a491400-4249-4466-afee-36ca917f35ed	7489a8be-be9a-4f22-b472-96f7140295be	8b8071bd-53f4-4896-9587-d0114af571c3	2027-08-18 01:05:35.835451+00	\N	\N	\N	1	\N	2026-08-12 18:00:11.498008+00	\N	0d40d9fd315c9e56010472ef67b9585fb5c3ec7a54b243a1babf6b2618a5c28a	7322481a05815b147e64eadb07be87a3ff04df6e7ebac789053f231f23af586d	draft
19dd2cee-25a1-4615-9ade-aaa25c83429d	343b2a3c-8688-47cc-a63d-f9ae6683bd26	17	5e96237c-428f-4244-977b-d5db4b84401b	\N	modified	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	523b923e-2e00-424f-b6eb-8e8797a06025	2a491400-4249-4466-afee-36ca917f35ed	7489a8be-be9a-4f22-b472-96f7140295be	8b8071bd-53f4-4896-9587-d0114af571c3	\N	\N	\N	\N	1	\N	2026-08-12 18:00:11.498008+00	\N	059baf2ce1e066531d9c1ebf5a55c04d2c4d5a842b9f723873661151943d904f	91f603cbbdeb642635caba3a4d1f5bc5d9d717cb6deb9e087b6fb61e411f89de	draft
37916c32-415b-46f0-a3f1-e4a1b3d5e7a7	343b2a3c-8688-47cc-a63d-f9ae6683bd26	18	19dd2cee-25a1-4615-9ade-aaa25c83429d	\N	modified	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	523b923e-2e00-424f-b6eb-8e8797a06025	2a491400-4249-4466-afee-36ca917f35ed	7489a8be-be9a-4f22-b472-96f7140295be	8b8071bd-53f4-4896-9587-d0114af571c3	2027-08-18 01:07:38.811123+00	\N	\N	\N	1	\N	2026-08-12 18:00:11.498008+00	\N	73688b7d9d0db219f7d0e7e7a5d1f35fddfbac05530d57d9ac7cc1d010dc10b1	a21067bc2569b7df776b4ee61a1d43405b241855955fe72f67a1e7f0264093f0	draft
785723b5-186c-4204-9f44-26a1f64778ed	343b2a3c-8688-47cc-a63d-f9ae6683bd26	19	37916c32-415b-46f0-a3f1-e4a1b3d5e7a7	\N	modified	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	523b923e-2e00-424f-b6eb-8e8797a06025	2a491400-4249-4466-afee-36ca917f35ed	7489a8be-be9a-4f22-b472-96f7140295be	8b8071bd-53f4-4896-9587-d0114af571c3	\N	\N	\N	\N	1	\N	2026-08-12 18:00:11.498008+00	\N	bbac2c4a1a9162df213f133d286b48c080a0d4b894dbcea921f04e61ce65b700	f189a7fc69902b4c74c5a277d098e0190c18f5ca20164f93930857614420a36d	draft
5c42e3e8-bc5c-41e7-84aa-f0d156479cec	343b2a3c-8688-47cc-a63d-f9ae6683bd26	20	785723b5-186c-4204-9f44-26a1f64778ed	\N	modified	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	523b923e-2e00-424f-b6eb-8e8797a06025	2a491400-4249-4466-afee-36ca917f35ed	7489a8be-be9a-4f22-b472-96f7140295be	8b8071bd-53f4-4896-9587-d0114af571c3	\N	2025-08-18 01:07:38.925786+00	\N	\N	1	\N	2026-08-12 18:00:11.498008+00	\N	3baf3635eae8b8ec5f2fc7de645af17b28af5118639a537b7715ae5cef4c2cbd	d7158c912a6dadeabe58cfa7f424179536f59aefe526fa741f8e06cd7d17ff29	draft
8a202d57-396e-46db-b777-d06c447f18a1	343b2a3c-8688-47cc-a63d-f9ae6683bd26	21	5c42e3e8-bc5c-41e7-84aa-f0d156479cec	\N	modified	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	523b923e-2e00-424f-b6eb-8e8797a06025	2a491400-4249-4466-afee-36ca917f35ed	7489a8be-be9a-4f22-b472-96f7140295be	8b8071bd-53f4-4896-9587-d0114af571c3	\N	\N	\N	\N	1	\N	2026-08-12 18:00:11.498008+00	\N	8bf2bfc963b97a8821b311394c6205cc42706e81b5847613614a42b52834e84c	4ee06af9cf4a15046440ef8ba0d7b2a9a142ad49a256781eebf45369798760c2	draft
22976086-527d-4713-a561-b9c03799dc6b	343b2a3c-8688-47cc-a63d-f9ae6683bd26	22	8a202d57-396e-46db-b777-d06c447f18a1	\N	modified	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	523b923e-2e00-424f-b6eb-8e8797a06025	2a491400-4249-4466-afee-36ca917f35ed	7489a8be-be9a-4f22-b472-96f7140295be	8b8071bd-53f4-4896-9587-d0114af571c3	2027-08-18 01:13:04.715901+00	\N	\N	\N	1	\N	2026-08-12 18:00:11.498008+00	\N	0862b6fd76679f939a5bd19c6469105a6ebe33875b2e07874698289ca59898d5	26937595d59b296ce3b0e9ae649cf5da1047d029f208d403033adb6d8c77fbb0	draft
a84da525-6e95-4f2d-95c7-95787923aab0	343b2a3c-8688-47cc-a63d-f9ae6683bd26	23	22976086-527d-4713-a561-b9c03799dc6b	\N	modified	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	523b923e-2e00-424f-b6eb-8e8797a06025	2a491400-4249-4466-afee-36ca917f35ed	7489a8be-be9a-4f22-b472-96f7140295be	8b8071bd-53f4-4896-9587-d0114af571c3	\N	\N	\N	\N	1	\N	2026-08-12 18:00:11.498008+00	\N	24ede08a4beae18425f7c9f209f0166b9247720b839b1c151a887c84c87ae5c5	536a2f385287a6290f77690e0f22cca8e959a3c2f3e393c362c6d913083f3fe6	draft
e5421bd5-5c45-4057-a369-ad2bc02a85ad	343b2a3c-8688-47cc-a63d-f9ae6683bd26	24	a84da525-6e95-4f2d-95c7-95787923aab0	\N	modified	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	523b923e-2e00-424f-b6eb-8e8797a06025	2a491400-4249-4466-afee-36ca917f35ed	7489a8be-be9a-4f22-b472-96f7140295be	8b8071bd-53f4-4896-9587-d0114af571c3	\N	2025-08-18 01:13:04.960545+00	\N	\N	1	\N	2026-08-12 18:00:11.498008+00	\N	372910d064d5faaa42b6f1c9dc284f8e83ed6c3f27480fff2e9d5a50c767e0c8	5ef9ef32ef06213ac408b97979cc3ebc10b2fdf4eebefc06e9a5f3cd4971fa78	draft
5b924100-b836-40d3-9941-9a30a5c17f2f	343b2a3c-8688-47cc-a63d-f9ae6683bd26	25	e5421bd5-5c45-4057-a369-ad2bc02a85ad	\N	modified	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	523b923e-2e00-424f-b6eb-8e8797a06025	2a491400-4249-4466-afee-36ca917f35ed	7489a8be-be9a-4f22-b472-96f7140295be	8b8071bd-53f4-4896-9587-d0114af571c3	\N	\N	\N	\N	1	\N	2026-08-12 18:00:11.498008+00	\N	8522164e5ee301e87263fc7e3e886662c4ef061ddf4523f5650cae2597e4f1a1	8fdf86baa049c97a73b899b2bfd5f14e341b116cdbcb8e9855e0bc08b6e05233	draft
d379cfe3-13b3-42f4-8eb0-98096ea86f11	343b2a3c-8688-47cc-a63d-f9ae6683bd26	26	5b924100-b836-40d3-9941-9a30a5c17f2f	\N	modified	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	523b923e-2e00-424f-b6eb-8e8797a06025	2a491400-4249-4466-afee-36ca917f35ed	7489a8be-be9a-4f22-b472-96f7140295be	8b8071bd-53f4-4896-9587-d0114af571c3	\N	2025-08-18 01:13:52.544886+00	\N	\N	1	\N	2026-08-12 18:00:11.498008+00	\N	6b6e9cc5883cbd4e603e8aff48ff6973cf53696687dcb2f05438cad14db3ee02	8e376ba0e63c2976d49b55833948c464196ba202b9b43e4278cc15ac7f08c9fc	draft
7daaa707-ca63-4343-82e5-f24b8cff76df	343b2a3c-8688-47cc-a63d-f9ae6683bd26	27	d379cfe3-13b3-42f4-8eb0-98096ea86f11	\N	modified	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	523b923e-2e00-424f-b6eb-8e8797a06025	2a491400-4249-4466-afee-36ca917f35ed	7489a8be-be9a-4f22-b472-96f7140295be	8b8071bd-53f4-4896-9587-d0114af571c3	\N	\N	\N	\N	1	\N	2026-08-12 18:00:11.498008+00	\N	f37fc39b2849b0a51eb70c84f734e6adf966e3517d91933ec0db68a4e5d5fbc6	9cce31f1aa684b586d2ecaa00eee700eb6f124d86173e23765775ad31c20821e	draft
d9063b80-3b77-497e-94c0-d485eac96ac3	343b2a3c-8688-47cc-a63d-f9ae6683bd26	28	7daaa707-ca63-4343-82e5-f24b8cff76df	\N	modified	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	523b923e-2e00-424f-b6eb-8e8797a06025	2a491400-4249-4466-afee-36ca917f35ed	7489a8be-be9a-4f22-b472-96f7140295be	8b8071bd-53f4-4896-9587-d0114af571c3	2027-08-18 01:13:53.006061+00	\N	\N	\N	1	\N	2026-08-12 18:00:11.498008+00	\N	4bad909baf4d045e0f3ceb21f5d1f9515ee4acc80b8bd1e4494190588d9b388a	a697f561b9adc31180b04ec4394eb21b23fbf73cd601594108979464be618da5	draft
fc5f97a1-7403-40ea-bcae-de5193d97929	343b2a3c-8688-47cc-a63d-f9ae6683bd26	29	d9063b80-3b77-497e-94c0-d485eac96ac3	\N	modified	\N	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	1.0	523b923e-2e00-424f-b6eb-8e8797a06025	2a491400-4249-4466-afee-36ca917f35ed	7489a8be-be9a-4f22-b472-96f7140295be	8b8071bd-53f4-4896-9587-d0114af571c3	\N	\N	\N	\N	1	\N	2026-08-12 18:00:11.498008+00	\N	13d376f4eb38fd96a45419712f20d324ead32126f3ef0070f3d7fdf05508f6aa	30438be4ffae8771c787ee4300381bed3fd7735b79c42af48a814de91085d3c2	draft
\.


--
-- Data for Name: product_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_categories (id, code, name, description, parent_id, display_order, status_id, version_number, created_at, updated_at, deleted_at) FROM stdin;
acf8502c-2ea3-47d5-b10e-63bde2301d56	DAIRY	Dairy Products	\N	\N	0	1	1	2026-08-11 00:28:04.638556+00	2026-08-11 00:28:04.638556+00	\N
5bebaca4-a5ad-4905-9f2f-ac5bbbf6bb5a	BAKERY	Bakery Products	\N	\N	0	1	1	2026-08-11 00:28:04.638556+00	2026-08-11 00:28:04.638556+00	\N
5a7e8ade-4b8a-4026-9087-9dc1563e3160	BEVERAGES	Beverages	\N	\N	0	1	1	2026-08-11 00:28:04.638556+00	2026-08-11 00:28:04.638556+00	\N
2caff78d-4a7d-4c5b-a5a5-5974b827d86e	SNACKS	Snacks	\N	\N	0	1	1	2026-08-11 00:28:04.638556+00	2026-08-11 00:28:04.638556+00	\N
33d06796-7aec-46c0-afa1-c580eab2ef7d	CEREALS	Cereals	\N	\N	0	1	1	2026-08-11 00:28:04.638556+00	2026-08-11 00:28:04.638556+00	\N
b15224b6-295d-401f-9322-81b4b78a7d47	SAUCES	Sauces and Condiments	\N	\N	0	1	1	2026-08-11 00:28:04.638556+00	2026-08-11 00:28:04.638556+00	\N
5a2a9e5b-e5b3-48b8-acd0-9bac8cd40600	CANNED_FOOD	Canned Food	\N	\N	0	1	1	2026-08-11 00:28:04.638556+00	2026-08-11 00:28:04.638556+00	\N
dc17b053-786e-421c-86ff-010fecd34c55	FROZEN_FOOD	Frozen Food	\N	\N	0	1	1	2026-08-11 00:28:04.638556+00	2026-08-11 00:28:04.638556+00	\N
d06b316c-141c-42d2-964c-9b533c066618	CONFECTIONERY	Confectionery	\N	\N	0	1	1	2026-08-11 00:28:04.638556+00	2026-08-11 00:28:04.638556+00	\N
3f45d4c9-63d9-4eae-b7ca-552e702ea628	BABY_FOOD	Baby Food	\N	\N	0	1	1	2026-08-11 00:28:04.638556+00	2026-08-11 00:28:04.638556+00	\N
ee127547-9578-405e-9177-1227fdb57400	MEAT	Meat Products	\N	\N	0	1	1	2026-08-11 00:28:04.638556+00	2026-08-11 00:28:04.638556+00	\N
34477817-c87f-4d49-a5ae-2187594227a6	SEAFOOD	Seafood	\N	\N	0	1	1	2026-08-11 00:28:04.638556+00	2026-08-11 00:28:04.638556+00	\N
f047b785-2b16-4378-a1ed-8b704332e1b8	FRUITS	Fruits	\N	\N	0	1	1	2026-08-11 00:28:04.638556+00	2026-08-11 00:28:04.638556+00	\N
b4f6a152-4a7f-4185-811f-76f968f74774	VEGETABLES	Vegetables	\N	\N	0	1	1	2026-08-11 00:28:04.638556+00	2026-08-11 00:28:04.638556+00	\N
315baedd-adb6-4782-bf07-6ec27da60986	OTHER	Other	\N	\N	0	1	1	2026-08-11 00:28:04.638556+00	2026-08-11 00:28:04.638556+00	\N
68c21140-1bba-40e8-8c67-8e049d8cb86c	TEST_DAIRY	Test Dairy	\N	\N	0	1	1	2026-08-11 00:29:13.642605+00	2026-08-11 00:29:13.642605+00	\N
43b97eff-65e2-466a-bef8-6d1ee41f5287	TEST_SNACK	Test Snack	\N	\N	0	1	1	2026-08-11 00:29:13.642605+00	2026-08-11 00:29:13.642605+00	\N
\.


--
-- Data for Name: product_categories_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_categories_history (id, original_entity_id, version_number, previous_version_id, change_set_id, change_type, change_reason, changed_by, approved_by, source_id, confidence_level, code, name, description, parent_id, display_order, status_id, deleted_at, created_at, effective_from, effective_to, superseded_at, snapshot_hash, checksum, version_status) FROM stdin;
73bf7b00-569e-4eb4-8d40-3e2ea01e2edb	acf8502c-2ea3-47d5-b10e-63bde2301d56	1	\N	\N	created	\N	\N	\N	\N	0.5	DAIRY	Dairy Products	\N	\N	0	1	\N	2026-08-11 00:28:04.638556+00	2026-08-11 00:28:04.638556+00	\N	\N	db8b1220fd7fe743e2445823fd91c576462224525eaa446548ffaab442eca623	5d351decdffe7a4f51d6f199c32820e9380f4d4dca9a18ae05392352353fc32b	draft
75ede4b4-cd11-4b70-b5ee-d186e0db7040	5bebaca4-a5ad-4905-9f2f-ac5bbbf6bb5a	1	\N	\N	created	\N	\N	\N	\N	0.5	BAKERY	Bakery Products	\N	\N	0	1	\N	2026-08-11 00:28:04.638556+00	2026-08-11 00:28:04.638556+00	\N	\N	6fa9aea8a2c0bb8f986d985985295ca7b709c64ed528f5565491f4048992c80c	945797386dc93ce43955e489704064896c9cfaceb653691819e4d155f24f1362	draft
c1766dd2-4d12-4132-a766-a44389b984a9	5a7e8ade-4b8a-4026-9087-9dc1563e3160	1	\N	\N	created	\N	\N	\N	\N	0.5	BEVERAGES	Beverages	\N	\N	0	1	\N	2026-08-11 00:28:04.638556+00	2026-08-11 00:28:04.638556+00	\N	\N	902f078472a6183bdacdbbd5cd261290f104d4d157c7dc572a256444fcbf4270	c4765a58d85cd69fea86e2f8b37649df02d6c22cd1f91b48e62f3dd639e4b234	draft
c53ee0db-2848-4465-8460-bce2ac106e2f	2caff78d-4a7d-4c5b-a5a5-5974b827d86e	1	\N	\N	created	\N	\N	\N	\N	0.5	SNACKS	Snacks	\N	\N	0	1	\N	2026-08-11 00:28:04.638556+00	2026-08-11 00:28:04.638556+00	\N	\N	1137ea44899221b0ceb90b78a5d957d59d217d86499fb14f95295fb2caeae6e0	c87a1bc5fc5abd7ccb68300e3247ead8bfc3c74df96ab1cd7c0aba583e4438d8	draft
a10b482a-bb20-4616-8a13-c90fc8d3d378	33d06796-7aec-46c0-afa1-c580eab2ef7d	1	\N	\N	created	\N	\N	\N	\N	0.5	CEREALS	Cereals	\N	\N	0	1	\N	2026-08-11 00:28:04.638556+00	2026-08-11 00:28:04.638556+00	\N	\N	f8ee3a022332ffeae365dc9efd327c8f4759c763da4beb8f33a1e0b4c6f59e6d	5dc4ea9f80f5ec5159146f36cd0f97133ca42130ffef522530f2602f13fa7302	draft
5db3d459-e1cb-4b83-921f-0bf63ce6f9e8	b15224b6-295d-401f-9322-81b4b78a7d47	1	\N	\N	created	\N	\N	\N	\N	0.5	SAUCES	Sauces and Condiments	\N	\N	0	1	\N	2026-08-11 00:28:04.638556+00	2026-08-11 00:28:04.638556+00	\N	\N	ec306bfaee43355558a161ed56bf307cf6fae4b714720e4f7dae17a2ec753246	3a1e9f4c20004542d0930a4ed99c1ef4887d198197d846aef0dbd7c40896519b	draft
107bd290-ad88-4d5f-80b8-e5099ff364c1	5a2a9e5b-e5b3-48b8-acd0-9bac8cd40600	1	\N	\N	created	\N	\N	\N	\N	0.5	CANNED_FOOD	Canned Food	\N	\N	0	1	\N	2026-08-11 00:28:04.638556+00	2026-08-11 00:28:04.638556+00	\N	\N	7443e8af6700798ef043058a587646d8d458f70273ffa1a43e0c544d0e990ceb	8122afbc110d25d7c6d30dcb61c569314b115104e1bb606d0d3228ee56b68cc6	draft
12695dbb-cc7b-45ba-9c1c-e1d36ec52144	dc17b053-786e-421c-86ff-010fecd34c55	1	\N	\N	created	\N	\N	\N	\N	0.5	FROZEN_FOOD	Frozen Food	\N	\N	0	1	\N	2026-08-11 00:28:04.638556+00	2026-08-11 00:28:04.638556+00	\N	\N	b100cdedc5b52bd26f5ff0aeb854ccb1fffe0cddf635b91da64d79febf55bd10	84dd07b10631cb55e53fefe529625782772678cdca5bf2b66413ad0c75049dc6	draft
ab9fafd7-63b1-493c-8902-637768b7deb8	d06b316c-141c-42d2-964c-9b533c066618	1	\N	\N	created	\N	\N	\N	\N	0.5	CONFECTIONERY	Confectionery	\N	\N	0	1	\N	2026-08-11 00:28:04.638556+00	2026-08-11 00:28:04.638556+00	\N	\N	048143ebdc7a7d8400152f8724c89fb943d4d9c17e9bd9e7bece7470b3cb8469	bbbf09a8c2e65fa616e7c4bd3ca7dcdb40bafd6f118efaaa9a92ec80d6d9638c	draft
8e29426f-f3ea-4b05-a3fb-25b9d5113b3d	3f45d4c9-63d9-4eae-b7ca-552e702ea628	1	\N	\N	created	\N	\N	\N	\N	0.5	BABY_FOOD	Baby Food	\N	\N	0	1	\N	2026-08-11 00:28:04.638556+00	2026-08-11 00:28:04.638556+00	\N	\N	70c4c63d364693fcfe31ccbb08ccca2a32353adb14dffe4631d6782211b9a773	1ece27743d416e6c4bcd9d822e14c17f45939d85cd04f26ea905d3798033469a	draft
d4904280-0959-409b-ae00-53ee472911d1	ee127547-9578-405e-9177-1227fdb57400	1	\N	\N	created	\N	\N	\N	\N	0.5	MEAT	Meat Products	\N	\N	0	1	\N	2026-08-11 00:28:04.638556+00	2026-08-11 00:28:04.638556+00	\N	\N	3a15fe9509d0be8b9bcf2b9242551d9be7f5189589ce75fc93963f79fdc57cf2	0e8ca75c1326d9c9fb7dfcdedbc648b54fa5c6a7aa4b85107b8cfdde7b2b0a2c	draft
066aa2fa-20fa-46af-b50b-ba518ea24f0e	34477817-c87f-4d49-a5ae-2187594227a6	1	\N	\N	created	\N	\N	\N	\N	0.5	SEAFOOD	Seafood	\N	\N	0	1	\N	2026-08-11 00:28:04.638556+00	2026-08-11 00:28:04.638556+00	\N	\N	641da37e5eaae84920ecc969e596e80b81a37cabf73c1b4b40a02006ceae4cbf	1884910e0e5853a480d26710b4ef4096de10c0207afe9cd819a5dc87a573475d	draft
5128a666-b782-437c-8e5e-5ed8599bf3b3	f047b785-2b16-4378-a1ed-8b704332e1b8	1	\N	\N	created	\N	\N	\N	\N	0.5	FRUITS	Fruits	\N	\N	0	1	\N	2026-08-11 00:28:04.638556+00	2026-08-11 00:28:04.638556+00	\N	\N	8435c766443815ce36469a7c4e8364dcb25368705240b8390a54ec3aa5be8a89	62aa6ffff1a3a0d735c2033b441fcbfc611f979db47ea54c7dc7c443edb48acc	draft
27d9f6ac-6500-4e5e-9220-ed3fbb4862c1	b4f6a152-4a7f-4185-811f-76f968f74774	1	\N	\N	created	\N	\N	\N	\N	0.5	VEGETABLES	Vegetables	\N	\N	0	1	\N	2026-08-11 00:28:04.638556+00	2026-08-11 00:28:04.638556+00	\N	\N	8af176c04f12606350075b797c0cd0dd529d26a533498d19d12152e757c2d61a	07c5564046bf11b09d9e0e9c026853ff7c58ed78e37a01d6407035bfe1d69125	draft
d71b86be-1faf-4087-aafc-e911e8a880c1	315baedd-adb6-4782-bf07-6ec27da60986	1	\N	\N	created	\N	\N	\N	\N	0.5	OTHER	Other	\N	\N	0	1	\N	2026-08-11 00:28:04.638556+00	2026-08-11 00:28:04.638556+00	\N	\N	9062d13b17aba7a98fc4e9d8481151828c618fe52cd0ebc93e275c4f75fb5428	49fa31b1900f0deb1db6253ad23a0a02a1dfe8772a5c12f57784479575f09261	draft
df80e6aa-f311-4ba2-a3b8-3ea486cc2a3a	68c21140-1bba-40e8-8c67-8e049d8cb86c	1	\N	\N	created	\N	\N	\N	\N	0.5	TEST_DAIRY	Test Dairy	\N	\N	0	1	\N	2026-08-11 00:29:13.642605+00	2026-08-11 00:29:13.642605+00	\N	\N	1614f151dcb6b4d2dcb518a93df698f16598de1ed8a51429226eaec5b7a2e13a	4b030dcc78094a91d383e844527d824ee27267f64fba2fcd80c5416fdfe98b7c	draft
7cacdb3b-ac14-47c5-8e46-11d6154377d4	43b97eff-65e2-466a-bef8-6d1ee41f5287	1	\N	\N	created	\N	\N	\N	\N	0.5	TEST_SNACK	Test Snack	\N	\N	0	1	\N	2026-08-11 00:29:13.642605+00	2026-08-11 00:29:13.642605+00	\N	\N	3e4506f934d91f5ff810cdc64f4413e0f2a1cd3e0dfbc7022da57fdb5d2d4173	4944656785fed064d6c35d3c6f33c020f3fdbfb3ac5b556b19d333c58bf85171	draft
\.


--
-- Data for Name: product_category_translations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_category_translations (id, product_category_id, language_id, name, short_name, display_name, search_name, description, translation_status, version_number, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: product_health_evaluations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_health_evaluations (id, product_id, condition_id, evaluation_result, evidence, evaluated_at, created_at) FROM stdin;
e5f90f20-2bad-4147-bbb0-8f9342e32acd	523b923e-2e00-424f-b6eb-8e8797a06025	e19dcaac-ffc1-4f43-a496-19eb37c2e3a3	UNKNOWN	[]	2026-08-18 02:13:24.847819+00	2026-08-18 02:13:24.847819+00
d7bdc77f-c2f1-4a6d-8dbd-a9f1c72d88ec	523b923e-2e00-424f-b6eb-8e8797a06025	7c51d27e-996f-4dc4-a3c0-9ed3ff3889ff	UNKNOWN	[]	2026-08-18 02:13:24.847819+00	2026-08-18 02:13:24.847819+00
\.


--
-- Data for Name: product_health_flags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_health_flags (id, product_id, health_flag_id, relationship_type_id, source_id, evidence_type_id, confidence_level, effective_from, effective_to, verified_at, approved_at, status_id, version_number, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: product_images; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_images (id, product_id, image_id, relationship_type_id, source_id, evidence_type_id, confidence_level, effective_from, effective_to, verified_at, approved_at, status_id, version_number, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: product_images_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_images_history (id, original_entity_id, version_number, previous_version_id, change_set_id, change_type, change_reason, changed_by, approved_by, source_id, confidence_level, product_id, image_id, relationship_type_id, evidence_type_id, effective_from, effective_to, verified_at, approved_at, status_id, deleted_at, created_at, superseded_at, snapshot_hash, checksum, version_status) FROM stdin;
\.


--
-- Data for Name: product_ingredients; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_ingredients (id, product_id, ingredient_id, relationship_type_id, amount_value, unit_id, source_id, evidence_type_id, confidence_level, effective_from, effective_to, verified_at, approved_at, status_id, version_number, created_at, updated_at, deleted_at) FROM stdin;
e0c83c6f-f3ba-4ff3-98e9-f40352520de2	523b923e-2e00-424f-b6eb-8e8797a06025	03620dd4-331d-438b-b77e-80647da17601	ce47dde0-5a33-4cfd-9751-44bb4f4a58d2	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	c24d31c8-beda-4579-a81c-9ca44d430170	1.0	\N	\N	\N	\N	1	1	2026-08-12 17:57:43.00436+00	2026-08-12 17:57:43.00436+00	\N
933cb5b7-cf00-40e8-bd1c-29214e91812d	cd029de1-856f-4952-b1ed-cd0cb2b06879	bf178102-a91b-4180-9226-5ccfa8f120a6	ce47dde0-5a33-4cfd-9751-44bb4f4a58d2	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	c24d31c8-beda-4579-a81c-9ca44d430170	1.0	\N	\N	\N	\N	1	1	2026-08-12 17:57:43.00436+00	2026-08-12 17:57:43.00436+00	\N
b006b3dc-4266-497b-8278-05d01534d3a9	5c1df2b4-e59d-424d-a4b5-ddd1311e7b34	03620dd4-331d-438b-b77e-80647da17601	ce47dde0-5a33-4cfd-9751-44bb4f4a58d2	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	c24d31c8-beda-4579-a81c-9ca44d430170	1.0	\N	\N	\N	\N	1	1	2026-08-12 17:57:43.00436+00	2026-08-12 17:57:43.00436+00	\N
75065166-bb6f-40d1-8321-326d0f768851	5c1df2b4-e59d-424d-a4b5-ddd1311e7b34	c16e7813-6912-4fe6-9c32-58f7395debbf	ce47dde0-5a33-4cfd-9751-44bb4f4a58d2	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	c24d31c8-beda-4579-a81c-9ca44d430170	1.0	\N	\N	\N	\N	1	1	2026-08-12 17:57:43.00436+00	2026-08-12 17:57:43.00436+00	\N
6b1c5e67-dcd8-4a2b-b56d-36fc072f5b25	5c1df2b4-e59d-424d-a4b5-ddd1311e7b34	c8631d1a-bbb9-472e-9a69-3135675fef7f	ce47dde0-5a33-4cfd-9751-44bb4f4a58d2	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	c24d31c8-beda-4579-a81c-9ca44d430170	1.0	\N	\N	\N	\N	1	1	2026-08-12 17:57:43.00436+00	2026-08-12 17:57:43.00436+00	\N
e0d5c329-0a4d-479e-8b36-76077d37d388	5c1df2b4-e59d-424d-a4b5-ddd1311e7b34	5fabfd34-8dcb-402f-88f0-3aef87155bb1	ce47dde0-5a33-4cfd-9751-44bb4f4a58d2	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	c24d31c8-beda-4579-a81c-9ca44d430170	1.0	\N	\N	\N	\N	1	1	2026-08-12 17:57:43.00436+00	2026-08-12 17:57:43.00436+00	\N
645651b8-a38f-4c53-b9ba-8c3b6cc3ce18	1915540e-716f-4ed1-93c0-208f79b95245	23abc89d-f2f9-4c02-8259-483889a86fcc	ce47dde0-5a33-4cfd-9751-44bb4f4a58d2	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	c24d31c8-beda-4579-a81c-9ca44d430170	1.0	\N	\N	\N	\N	1	1	2026-08-12 17:57:43.00436+00	2026-08-12 17:57:43.00436+00	\N
bc9f96c4-9ee2-4814-8af4-ff3397012476	1915540e-716f-4ed1-93c0-208f79b95245	06f213a4-6e6f-46b8-8be8-28e6381125e1	ce47dde0-5a33-4cfd-9751-44bb4f4a58d2	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	c24d31c8-beda-4579-a81c-9ca44d430170	1.0	\N	\N	\N	\N	1	1	2026-08-12 17:57:43.00436+00	2026-08-12 17:57:43.00436+00	\N
eab08cb1-8334-4d65-8494-6735a1b8fab5	92a49394-f8bd-4969-9dce-7ffa05e97feb	03620dd4-331d-438b-b77e-80647da17601	ce47dde0-5a33-4cfd-9751-44bb4f4a58d2	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	c24d31c8-beda-4579-a81c-9ca44d430170	1.0	\N	\N	\N	\N	1	1	2026-08-12 17:57:43.00436+00	2026-08-12 17:57:43.00436+00	\N
0bc7cabd-4fa9-42e8-9bb5-8f156685021c	92a49394-f8bd-4969-9dce-7ffa05e97feb	c8631d1a-bbb9-472e-9a69-3135675fef7f	ce47dde0-5a33-4cfd-9751-44bb4f4a58d2	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	c24d31c8-beda-4579-a81c-9ca44d430170	1.0	\N	\N	\N	\N	1	1	2026-08-12 17:57:43.00436+00	2026-08-12 17:57:43.00436+00	\N
3105a90d-d56a-48e6-8267-11bceb27c52b	d743db46-c247-4217-a28f-0063189f41eb	98450c22-a798-42c4-89e6-f7737be16b58	ce47dde0-5a33-4cfd-9751-44bb4f4a58d2	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	c24d31c8-beda-4579-a81c-9ca44d430170	1.0	\N	\N	\N	\N	1	1	2026-08-12 17:57:43.00436+00	2026-08-12 17:57:43.00436+00	\N
cc31fdc1-2942-4926-a61a-317d861dc3e4	b6cd3e32-ca24-496b-b5fa-8ea3f8bed5c2	23abc89d-f2f9-4c02-8259-483889a86fcc	ce47dde0-5a33-4cfd-9751-44bb4f4a58d2	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	c24d31c8-beda-4579-a81c-9ca44d430170	1.0	\N	\N	\N	\N	1	1	2026-08-12 17:57:43.00436+00	2026-08-12 17:57:43.00436+00	\N
4409f53c-633d-4e8e-8b17-ec4a201817ae	b6cd3e32-ca24-496b-b5fa-8ea3f8bed5c2	06f213a4-6e6f-46b8-8be8-28e6381125e1	ce47dde0-5a33-4cfd-9751-44bb4f4a58d2	\N	\N	65e8a675-805d-49a2-87ad-d3b62a9ba86d	c24d31c8-beda-4579-a81c-9ca44d430170	1.0	\N	\N	\N	\N	1	1	2026-08-12 17:57:43.00436+00	2026-08-12 17:57:43.00436+00	\N
\.


--
-- Data for Name: product_nutrition_values; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_nutrition_values (id, product_id, nutrition_type_id, relationship_type_id, amount_value, unit_id, source_id, evidence_type_id, confidence_level, effective_from, effective_to, verified_at, approved_at, status_id, version_number, created_at, updated_at, deleted_at, measurement_basis_id) FROM stdin;
a1406c8c-8cdf-4c52-a250-55af421c2cb0	523b923e-2e00-424f-b6eb-8e8797a06025	09ba73d7-19a4-439b-948b-1a2b7fc52dfc	f25e9bae-659c-4b20-9ab9-c445975a9105	0.0	45c69208-467c-4049-9c22-2b79ddd9f8e9	\N	8b8071bd-53f4-4896-9587-d0114af571c3	1.0	\N	\N	\N	\N	1	1	2026-08-13 19:08:24.761723+00	2026-08-13 19:24:00.903596+00	\N	3a92802c-a58d-4398-9afe-7d28cd6fd3ea
08f613d3-6bdd-4a95-af42-7972aa8abe9d	523b923e-2e00-424f-b6eb-8e8797a06025	0fd49348-3025-4661-9f91-b1d860a7c1a2	f25e9bae-659c-4b20-9ab9-c445975a9105	4.8	45c69208-467c-4049-9c22-2b79ddd9f8e9	\N	8b8071bd-53f4-4896-9587-d0114af571c3	1.0	\N	\N	\N	\N	1	1	2026-08-13 19:08:24.761723+00	2026-08-13 19:24:00.903596+00	\N	3a92802c-a58d-4398-9afe-7d28cd6fd3ea
c5427a6e-2925-4f47-bc95-6ea56a2cc335	523b923e-2e00-424f-b6eb-8e8797a06025	25133cf1-fea4-4e9f-82ac-d00efa505d6d	f25e9bae-659c-4b20-9ab9-c445975a9105	1.9	45c69208-467c-4049-9c22-2b79ddd9f8e9	\N	8b8071bd-53f4-4896-9587-d0114af571c3	1.0	\N	\N	\N	\N	1	1	2026-08-13 19:08:24.761723+00	2026-08-13 19:24:00.903596+00	\N	3a92802c-a58d-4398-9afe-7d28cd6fd3ea
6d688452-f3e0-4def-90b2-0d0838ac0278	523b923e-2e00-424f-b6eb-8e8797a06025	28a38949-f7b3-4ea8-8456-92538dc8262d	f25e9bae-659c-4b20-9ab9-c445975a9105	43.0	28189bfe-81a7-436d-b51e-a3855941669d	\N	8b8071bd-53f4-4896-9587-d0114af571c3	1.0	\N	\N	\N	\N	1	1	2026-08-13 19:08:24.761723+00	2026-08-13 19:24:00.903596+00	\N	3a92802c-a58d-4398-9afe-7d28cd6fd3ea
a93c4bed-81e7-4c31-834d-f8597a0a4700	523b923e-2e00-424f-b6eb-8e8797a06025	64deae22-bb51-4bae-b7a1-08d619902b8e	f25e9bae-659c-4b20-9ab9-c445975a9105	3.2	45c69208-467c-4049-9c22-2b79ddd9f8e9	\N	8b8071bd-53f4-4896-9587-d0114af571c3	1.0	\N	\N	\N	\N	1	1	2026-08-13 19:08:24.761723+00	2026-08-13 19:24:00.903596+00	\N	3a92802c-a58d-4398-9afe-7d28cd6fd3ea
af31cc97-e28d-4dbd-a37d-d7db88150ca8	523b923e-2e00-424f-b6eb-8e8797a06025	7335b58d-bcae-4c91-abba-eb5b1d339296	f25e9bae-659c-4b20-9ab9-c445975a9105	3.2	45c69208-467c-4049-9c22-2b79ddd9f8e9	\N	8b8071bd-53f4-4896-9587-d0114af571c3	1.0	\N	\N	\N	\N	1	1	2026-08-13 19:08:24.761723+00	2026-08-13 19:24:00.903596+00	\N	3a92802c-a58d-4398-9afe-7d28cd6fd3ea
4cd4d6eb-a5d9-4d07-8a5c-4ccb946ee5f4	523b923e-2e00-424f-b6eb-8e8797a06025	7d654278-5571-4d46-bb30-55c471c095b1	f25e9bae-659c-4b20-9ab9-c445975a9105	4.8	45c69208-467c-4049-9c22-2b79ddd9f8e9	\N	8b8071bd-53f4-4896-9587-d0114af571c3	1.0	\N	\N	\N	\N	1	1	2026-08-13 19:08:24.761723+00	2026-08-13 19:24:00.903596+00	\N	3a92802c-a58d-4398-9afe-7d28cd6fd3ea
e584382b-8179-4f13-bca9-53926e500242	523b923e-2e00-424f-b6eb-8e8797a06025	8d483349-3d04-4894-8a7b-979b8f0380dc	f25e9bae-659c-4b20-9ab9-c445975a9105	0.0	45c69208-467c-4049-9c22-2b79ddd9f8e9	\N	8b8071bd-53f4-4896-9587-d0114af571c3	1.0	\N	\N	\N	\N	1	1	2026-08-13 19:08:24.761723+00	2026-08-13 19:24:00.903596+00	\N	3a92802c-a58d-4398-9afe-7d28cd6fd3ea
9ef58f88-a705-4d88-bbd4-9413da545a16	523b923e-2e00-424f-b6eb-8e8797a06025	f2b7e53a-7967-4b55-a56b-ddeecdcc84c4	f25e9bae-659c-4b20-9ab9-c445975a9105	61	edd3befb-9aed-496d-ba0a-0bd772976ed6	\N	8b8071bd-53f4-4896-9587-d0114af571c3	1.0	\N	\N	\N	\N	1	1	2026-08-13 19:08:24.761723+00	2026-08-18 00:25:24.491697+00	\N	3a92802c-a58d-4398-9afe-7d28cd6fd3ea
\.


--
-- Data for Name: product_search_index; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_search_index (id, product_id, search_name, search_text, search_tokens, language_codes, search_rank, generated_at) FROM stdin;
\.


--
-- Data for Name: product_translations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_translations (id, product_id, language_id, name, short_name, display_name, search_name, description, translation_status, version_number, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.products (id, brand_id, product_category_id, internal_code, name, description, status_id, source_id, confidence_level, verified_at, approved_at, deprecated_at, version_number, created_by, approved_by, created_at, updated_at, deleted_at) FROM stdin;
523b923e-2e00-424f-b6eb-8e8797a06025	a03497f8-562e-4b20-a98c-8ec497c5bccd	\N	FATEEN_MILK_TEST	Fateen Test Milk	\N	1	\N	0.5	\N	\N	\N	1	\N	\N	2026-08-11 00:29:12.621739+00	2026-08-11 00:29:12.621739+00	\N
cd029de1-856f-4952-b1ed-cd0cb2b06879	a03497f8-562e-4b20-a98c-8ec497c5bccd	\N	FATEEN_SNACK_TEST	Fateen Test Snack	\N	1	\N	0.5	\N	\N	\N	1	\N	\N	2026-08-11 00:29:12.968864+00	2026-08-11 00:29:12.968864+00	\N
5c1df2b4-e59d-424d-a4b5-ddd1311e7b34	e98ff5f4-5a2f-4b38-93b9-37d78707f98a	\N	TEST_MILK_001	Test Milk Product	\N	1	\N	0.5	\N	\N	\N	2	\N	\N	2026-08-11 00:31:20.214268+00	2026-08-11 00:40:50.216011+00	\N
1915540e-716f-4ed1-93c0-208f79b95245	feec1927-2905-470e-86bd-47f2673dadb8	\N	TEST_BREAD_001	Test Wheat Bread	\N	1	\N	0.5	\N	\N	\N	2	\N	\N	2026-08-11 00:31:20.214268+00	2026-08-11 00:40:50.671479+00	\N
92a49394-f8bd-4969-9dce-7ffa05e97feb	b9a7338b-4432-4292-85ea-6d3a80e193ff	\N	TEST_CHOCOLATE_001	Test Milk Chocolate	\N	1	\N	0.5	\N	\N	\N	2	\N	\N	2026-08-11 00:31:20.214268+00	2026-08-11 00:40:51.113929+00	\N
d743db46-c247-4217-a28f-0063189f41eb	84926a6b-f834-48cb-b8b8-4cbe8cdda5e2	\N	TEST_CHIPS_001	Test Potato Chips	\N	1	\N	0.5	\N	\N	\N	2	\N	\N	2026-08-11 00:31:20.214268+00	2026-08-11 00:40:51.56078+00	\N
b6cd3e32-ca24-496b-b5fa-8ea3f8bed5c2	c0c7d43a-fdd0-4dc3-99d8-fa2fb488337f	\N	TEST_BISCUIT_001	Test Wheat Biscuit	\N	1	\N	0.5	\N	\N	\N	2	\N	\N	2026-08-11 00:31:20.214268+00	2026-08-11 00:40:52.042078+00	\N
\.


--
-- Data for Name: products_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.products_history (id, original_entity_id, version_number, previous_version_id, change_set_id, change_type, change_reason, changed_by, approved_by, source_id, confidence_level, brand_id, product_category_id, internal_code, name, description, status_id, verified_at, approved_at, deprecated_at, deleted_at, created_at, effective_from, effective_to, superseded_at, snapshot_hash, checksum, version_status) FROM stdin;
fc12e1e6-9cc4-4471-8d7a-c7f6f8be85d5	523b923e-2e00-424f-b6eb-8e8797a06025	1	\N	\N	created	\N	\N	\N	\N	0.5	a03497f8-562e-4b20-a98c-8ec497c5bccd	\N	FATEEN_MILK_TEST	Fateen Test Milk	\N	1	\N	\N	\N	\N	2026-08-11 00:29:12.621739+00	2026-08-11 00:29:12.621739+00	\N	\N	701022e560a4f9cc27e1718f6ed0e019d8cb3a98c224c7a63ba0e98b36ac1b2c	473e3edfbb28fabe8bdecaa69ae528156377773c7baa45ef87f8475e73f83c29	draft
eeb64918-d60e-4ca5-8c8b-49678e797d7d	cd029de1-856f-4952-b1ed-cd0cb2b06879	1	\N	\N	created	\N	\N	\N	\N	0.5	a03497f8-562e-4b20-a98c-8ec497c5bccd	\N	FATEEN_SNACK_TEST	Fateen Test Snack	\N	1	\N	\N	\N	\N	2026-08-11 00:29:12.968864+00	2026-08-11 00:29:12.968864+00	\N	\N	db79829a1da2017065b68ce0619771623bcb37ed64086d556323f6bb2ec7e47e	f8ee81b73bd8e69553f1569277e2c30d4b3afa7b20f7762c0c4f80cae4ab83ba	draft
b4c5e9eb-90db-4cec-898a-a5a3bd1e042b	5c1df2b4-e59d-424d-a4b5-ddd1311e7b34	1	\N	\N	created	\N	\N	\N	\N	0.5	\N	\N	TEST_MILK_001	Test Milk Product	\N	1	\N	\N	\N	\N	2026-08-11 00:31:20.214268+00	2026-08-11 00:31:20.214268+00	\N	\N	4a4e3e9fc26260204ee5c9ef77f0258969f2ad082b06e99f5784a3933163fb8a	e094e7fe940d54833669c63d78d0679fc23445cebd3a37f30614b7c0d906d097	draft
33247354-e818-4c78-ad30-5dd19c8ab2ec	1915540e-716f-4ed1-93c0-208f79b95245	1	\N	\N	created	\N	\N	\N	\N	0.5	\N	\N	TEST_BREAD_001	Test Wheat Bread	\N	1	\N	\N	\N	\N	2026-08-11 00:31:20.214268+00	2026-08-11 00:31:20.214268+00	\N	\N	bc2874212e132992814f370c3ceedc937c010d7ca94924f2fe76bc47945c3dcb	db2ecd3636e0a8b79fb7d8664d073082b2e26d0e65a258fb8574ce4a9753080a	draft
8c2b1524-6f05-4efb-a95e-e4ecb60ccdb5	92a49394-f8bd-4969-9dce-7ffa05e97feb	1	\N	\N	created	\N	\N	\N	\N	0.5	\N	\N	TEST_CHOCOLATE_001	Test Milk Chocolate	\N	1	\N	\N	\N	\N	2026-08-11 00:31:20.214268+00	2026-08-11 00:31:20.214268+00	\N	\N	babb51ade6e9b0f629c850806cc2f6682c7e262f81a3331e704b77bb725c06b7	2976c17a8a18cc4dae028f15d091657807a97207bf9793b931fad462ebf31ddd	draft
6f2f0243-2c2f-4168-aa18-7e320e689897	d743db46-c247-4217-a28f-0063189f41eb	1	\N	\N	created	\N	\N	\N	\N	0.5	\N	\N	TEST_CHIPS_001	Test Potato Chips	\N	1	\N	\N	\N	\N	2026-08-11 00:31:20.214268+00	2026-08-11 00:31:20.214268+00	\N	\N	e83e62cf9f88ced404540a91f982f19a053f449713863c5117ddc950ae1dd631	09a9602966d7cf068a39dc8cc1cdeb3004135215e77ffd8673013ece4e032e94	draft
ee5dc36c-f6af-4297-b79a-f12ec7884676	b6cd3e32-ca24-496b-b5fa-8ea3f8bed5c2	1	\N	\N	created	\N	\N	\N	\N	0.5	\N	\N	TEST_BISCUIT_001	Test Wheat Biscuit	\N	1	\N	\N	\N	\N	2026-08-11 00:31:20.214268+00	2026-08-11 00:31:20.214268+00	\N	\N	16ee249e98901c8cee46c1521c3a7473d87078b5d22fd3427af39c7603111e1d	42b4435be7781e966eca380fae3eee3cf8890a69d87db91680cc680784b7653f	draft
2438a097-aa7b-4cdb-87e6-dae10c95c13b	5c1df2b4-e59d-424d-a4b5-ddd1311e7b34	2	b4c5e9eb-90db-4cec-898a-a5a3bd1e042b	\N	modified	\N	\N	\N	\N	0.5	e98ff5f4-5a2f-4b38-93b9-37d78707f98a	\N	TEST_MILK_001	Test Milk Product	\N	1	\N	\N	\N	\N	2026-08-11 00:31:20.214268+00	2026-08-11 00:40:50.216011+00	\N	\N	60ce8d95d568014f8fc88b04662734b54bf1620f0890d9b1759fa300bfbc0185	d4732345e2515f40967e7d6db2f2248eae07163e3587f907b5731b24207b10fd	draft
933e1bea-26f2-4a24-957b-f5f36be083fc	1915540e-716f-4ed1-93c0-208f79b95245	2	33247354-e818-4c78-ad30-5dd19c8ab2ec	\N	modified	\N	\N	\N	\N	0.5	feec1927-2905-470e-86bd-47f2673dadb8	\N	TEST_BREAD_001	Test Wheat Bread	\N	1	\N	\N	\N	\N	2026-08-11 00:31:20.214268+00	2026-08-11 00:40:50.671479+00	\N	\N	4aff86a2041d3619dcdf5bef6ca783999a66c317199bbcdb9af08392aa245bdc	6a74b445a3f1288fbf26ffa22cbd5fc0d8469e1953fe2af2195cfcd8d1200985	draft
13dfad82-24ab-4df3-9dd6-bb6c413e8be4	92a49394-f8bd-4969-9dce-7ffa05e97feb	2	8c2b1524-6f05-4efb-a95e-e4ecb60ccdb5	\N	modified	\N	\N	\N	\N	0.5	b9a7338b-4432-4292-85ea-6d3a80e193ff	\N	TEST_CHOCOLATE_001	Test Milk Chocolate	\N	1	\N	\N	\N	\N	2026-08-11 00:31:20.214268+00	2026-08-11 00:40:51.113929+00	\N	\N	26172054b8ce38f93aa53e867c108f886f26b81b2d2052174e2003233f26f6b9	9a9ded86ae35d833e2df8f2376481ef0d8ebe48ed4b59d413cb53fc3b72b1757	draft
fb539f38-9904-47c1-bb03-015dbdc5bfd3	d743db46-c247-4217-a28f-0063189f41eb	2	6f2f0243-2c2f-4168-aa18-7e320e689897	\N	modified	\N	\N	\N	\N	0.5	84926a6b-f834-48cb-b8b8-4cbe8cdda5e2	\N	TEST_CHIPS_001	Test Potato Chips	\N	1	\N	\N	\N	\N	2026-08-11 00:31:20.214268+00	2026-08-11 00:40:51.56078+00	\N	\N	f882a766ab37b48ce6a6897a99e7312868c270b01caba0ca1647c8acdf9f9ca7	ba1b25b11d385ff460ab58bae73852504de900f5193fc1c8859be3dc3fd3605c	draft
e2d28d02-3b96-4687-9fbf-5bca8db9b024	b6cd3e32-ca24-496b-b5fa-8ea3f8bed5c2	2	ee5dc36c-f6af-4297-b79a-f12ec7884676	\N	modified	\N	\N	\N	\N	0.5	c0c7d43a-fdd0-4dc3-99d8-fa2fb488337f	\N	TEST_BISCUIT_001	Test Wheat Biscuit	\N	1	\N	\N	\N	\N	2026-08-11 00:31:20.214268+00	2026-08-11 00:40:52.042078+00	\N	\N	0471cf66a2cb10db9df2d04dbabe829e3d32eb0486322cd56d13e6c777a64fc4	670e185ad866078c00d3eb39e822979d3eee769ec17bb8bd8bd205531e030b06	draft
\.


--
-- Data for Name: regions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.regions (id, code, name, description, display_order, status_id, version_number, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: regulatory_authorities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.regulatory_authorities (id, code, name, description, display_order, status_id, version_number, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: relationship_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.relationship_types (id, code, name, description, is_directional, inverse_type_id, display_order, status_id, version_number, created_at, updated_at, deleted_at) FROM stdin;
ce47dde0-5a33-4cfd-9751-44bb4f4a58d2	CONTAINS_INGREDIENT	Contains Ingredient	\N	t	\N	0	1	1	2026-08-11 00:13:03.870976+00	2026-08-11 00:13:03.870976+00	\N
c816beeb-b723-40a1-9220-910125714e86	MAY_CONTAIN_INGREDIENT	May Contain Ingredient	\N	t	\N	0	1	1	2026-08-11 00:13:03.870976+00	2026-08-11 00:13:03.870976+00	\N
18fa6ec8-afd8-40b2-b468-adc78bd6be12	CONTAINS_ALLERGEN	Contains Allergen	\N	t	\N	0	1	1	2026-08-11 00:13:03.870976+00	2026-08-11 00:13:03.870976+00	\N
eb53c526-c4e5-47d0-827e-482d02a45b37	MAY_CONTAIN_ALLERGEN	May Contain Allergen	\N	t	\N	0	1	1	2026-08-11 00:13:03.870976+00	2026-08-11 00:13:03.870976+00	\N
7489a8be-be9a-4f22-b472-96f7140295be	PRIMARY_BARCODE	Primary Barcode	\N	t	\N	0	1	1	2026-08-11 00:13:03.870976+00	2026-08-11 00:13:03.870976+00	\N
e7a52d95-a5d2-471f-b106-926375279fa4	PACK_SIZE_VARIANT	Pack Size Variant	\N	t	\N	0	1	1	2026-08-11 00:13:03.870976+00	2026-08-11 00:13:03.870976+00	\N
f25e9bae-659c-4b20-9ab9-c445975a9105	MEASURED_VALUE	Measured Value	Represents a measured nutrition value for a product.	t	\N	0	1	1	2026-08-13 19:06:25.543754+00	2026-08-13 19:06:25.543754+00	\N
\.


--
-- Data for Name: role_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.role_types (id, code, name, description, display_order, status_id, version_number, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: scan_job_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.scan_job_items (id, scan_job_id, candidate_id, product_id, barcode, status, action, error_message, processed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: scan_jobs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.scan_jobs (id, company_id, scan_type, status, started_at, finished_at, duration_seconds, products_discovered, products_processed, products_accepted, products_rejected, products_needs_review, products_created, products_updated, products_unchanged, conflicts_detected, errors_count, coverage_pct, error_log, metadata, created_at, updated_at) FROM stdin;
68f8cda4-b611-4fbf-a5b3-798940782f43	8ff0eaab-6877-4d36-9c83-412a88d0a577	dry_run	completed	2026-08-18 02:13:23.191543+00	2026-08-18 02:13:23.405541+00	0.16	0	0	0	0	0	0	0	0	0	0	\N	[]	{}	2026-08-18 02:13:23.191543+00	2026-08-18 02:13:23.405541+00
ac2bd4c7-880f-45bb-8123-de3664fbc702	8ff0eaab-6877-4d36-9c83-412a88d0a577	dry_run	completed	2026-08-18 02:13:23.522844+00	2026-08-18 02:13:23.723726+00	0.15	0	0	0	0	0	0	0	0	0	0	\N	[]	{}	2026-08-18 02:13:23.522844+00	2026-08-18 02:13:23.723726+00
9eee891a-2144-4ffc-b4ba-596305350adb	8ff0eaab-6877-4d36-9c83-412a88d0a577	dry_run	completed	2026-08-18 02:13:23.910157+00	2026-08-18 02:13:24.113505+00	0.14	0	0	0	0	0	0	0	0	0	0	\N	[]	{}	2026-08-18 02:13:23.910157+00	2026-08-18 02:13:24.113505+00
07859a7a-3478-4a55-a2c5-8bf103b343ee	8ff0eaab-6877-4d36-9c83-412a88d0a577	dry_run	completed	2026-08-18 02:13:25.585934+00	2026-08-18 02:13:25.83172+00	0.17	0	0	0	0	0	0	0	0	0	0	\N	[]	{}	2026-08-18 02:13:25.585934+00	2026-08-18 02:13:25.83172+00
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.schema_migrations (version, checksum, applied_at) FROM stdin;
0001_foundation_extensions.sql	25cc78dc2c82da967b3ed1338b0f1087	2026-08-10 11:16:57.832627+00
0002_foundation_enums.sql	e0c797db5c912ed5613dc762cca3063f	2026-08-10 11:16:58.655214+00
0003_foundation_lookup_tables.sql	c3de325fcd3928738cf22210298543ea	2026-08-10 11:16:59.275743+00
0004_foundation_lookup_constraints.sql	78004c298fbc2729f7318244c9dfde48	2026-08-10 11:16:59.690699+00
0005_foundation_lookup_indexes.sql	f8c1138c6c246460b82657d1b3ee85de	2026-08-10 11:17:00.096347+00
0006_foundation_functions_and_triggers.sql	148d20aa8b4202f8c9f9260f2af78d59	2026-08-10 11:17:00.57102+00
0007_seed_lifecycle_statuses.sql	d62d81be6dff947f2ba004122c0d5443	2026-08-10 11:17:01.031861+00
0008_foundation_reference_tables.sql	93b1a804ef858bea08dc74490b8a13ce	2026-08-10 11:17:01.451508+00
0009_foundation_reference_constraints.sql	49aa2095a830f9a4eaca123bf13f9634	2026-08-10 11:17:02.025+00
0010_foundation_reference_indexes.sql	dfb66d28c9adec07a4fbe6dd53427af4	2026-08-10 11:17:02.56403+00
0011_foundation_reference_triggers.sql	663584c192306127b511e17a12d77ffd	2026-08-10 11:17:03.035729+00
0012_core_entity_tables.sql	99aea0d3a591f7e3e724bc3d7a248cb1	2026-08-10 11:17:03.549921+00
0013_core_entity_constraints.sql	11fd9da61ed144808b5e31b9cb9935d7	2026-08-10 11:17:04.042426+00
0014_core_entity_indexes.sql	3458b293eb2477466345009c5d82483a	2026-08-10 11:17:04.577219+00
0015_core_entity_triggers.sql	b7ac049beaf5f3a9d86c2a6a86806b82	2026-08-10 11:17:05.165553+00
0016_relationship_tables.sql	ddde14275144f4dbe7cdc08e4aae50ac	2026-08-10 11:17:05.682562+00
0017_relationship_constraints.sql	17e8e5fa1a307c5e58eb738c4ab99c5b	2026-08-10 11:17:06.293292+00
0018_relationship_indexes.sql	c3b56e6fbb62d42837c8e221a9376193	2026-08-10 11:17:06.834448+00
0019_relationship_triggers.sql	6fdea2f270528758f6185d9fc04cd976	2026-08-10 11:17:07.474779+00
0020_history_tables.sql	a21be62cd97eaf97c32de37491c08fe0	2026-08-10 11:17:08.020253+00
0021_audit_tables.sql	5f9fe5b1549ef2434f779b13feab31af	2026-08-10 11:17:08.533803+00
0022_history_constraints.sql	7ec56ec2f0c35af0e43be93b6e862094	2026-08-10 11:17:09.085866+00
0023_history_indexes.sql	e815102c5daf807a6ddf30beb7d2c4dd	2026-08-10 11:17:09.625441+00
0024_history_triggers.sql	02f4b13d07001996e024aefb0a1c829e	2026-08-10 11:17:10.237211+00
0025_media_and_barcode_tables.sql	eca1b773266de2e9e7db84e91fbfcd2c	2026-08-10 11:17:10.735624+00
0026_media_and_barcode_history_tables.sql	c11fd64de3f6d35bafb32de03ae645d9	2026-08-10 11:17:11.332809+00
0027_media_and_barcode_constraints.sql	299a23749caa51c0b33ecf087a1cdb04	2026-08-10 11:17:11.989088+00
0028_media_and_barcode_indexes.sql	8acd991a77706b423f331ae338fbfe8e	2026-08-10 11:17:12.62044+00
0029_media_and_barcode_triggers.sql	64d565367af8f72a07bdab67eb3be3c1	2026-08-10 11:17:13.164927+00
0030_search_tables.sql	709b5bb9245af87e0cdef7c40859f639	2026-08-10 11:17:13.737559+00
0031_search_indexes.sql	518529bfce1cc341d1e5f7e475aa7028	2026-08-10 11:17:14.292334+00
0032_ecr_product_media_tables.sql	e55839faadedb0f4bb5d8f2423def7a0	2026-08-10 11:17:14.842674+00
0033_ecr_product_media_history_tables.sql	66e4f296e4ced002dfe2a11205231390	2026-08-10 11:17:15.424554+00
0034_ecr_constraints.sql	8d07dafba7c34f7869a1e5384d33c1f7	2026-08-10 11:17:16.014675+00
0035_ecr_indexes.sql	4e2af1e1fe6239c84ee3d64b7b784130	2026-08-10 11:17:16.617188+00
0036_ecr_functions.sql	e097206ebc621a92a59a0a2d915e056e	2026-08-10 11:17:17.198845+00
0037_ecr_triggers.sql	7ef1e8e7eb34969ec07d963930af5983	2026-08-10 11:17:17.739675+00
0038_ecr_fix_capture_history.sql	1a2103a5ca1a5d8afa8e342689762596	2026-08-10 11:17:18.289189+00
0039_ecr_fix_history_original_entity_fk.sql	665f2ffe22fa523551ed67ee07c7aec4	2026-08-10 11:17:18.900113+00
002_collector_tables	fateen-collector-v1	2026-08-18 01:38:14.161681+00
\.


--
-- Data for Name: source_priorities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.source_priorities (id, code, name, rank, description, status_id, version_number, created_at, updated_at, deleted_at) FROM stdin;
b9957035-26e7-4c3c-8d99-a6a582d07eaa	TEST	Test Source	99	Internal priority for controlled Fateen test data.	1	1	2026-08-12 13:55:13.845982+00	2026-08-12 13:55:13.845982+00	\N
\.


--
-- Data for Name: source_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.source_types (id, code, name, description, display_order, status_id, version_number, created_at, updated_at, deleted_at) FROM stdin;
555ec644-ccf9-45e8-8b30-38881e08d886	MANUFACTURER	Manufacturer	\N	0	1	1	2026-08-11 00:13:04.851989+00	2026-08-11 00:13:04.851989+00	\N
8f49e711-945d-4718-8d7e-bd97c8964bc7	REGULATORY	Regulatory Authority	\N	0	1	1	2026-08-11 00:13:04.851989+00	2026-08-11 00:13:04.851989+00	\N
99a00982-9129-4753-afe3-60f56aae2875	DATABASE	Database	\N	0	1	1	2026-08-11 00:13:04.851989+00	2026-08-11 00:13:04.851989+00	\N
9bbc9037-983b-4ce1-81de-6cb6afc086f5	USER_SUBMITTED	User Submitted	\N	0	1	1	2026-08-11 00:13:04.851989+00	2026-08-11 00:13:04.851989+00	\N
6e5b8193-554e-40df-8be8-25c57c1da0be	IMPORT	Data Import	\N	0	1	1	2026-08-11 00:13:04.851989+00	2026-08-11 00:13:04.851989+00	\N
\.


--
-- Data for Name: unit_conversions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.unit_conversions (id, from_unit_id, to_unit_id, conversion_factor, measurement_type, is_exact, notes, created_at) FROM stdin;
c90b909c-b9f1-401c-8d62-468b9b3c7eb0	28189bfe-81a7-436d-b51e-a3855941669d	45c69208-467c-4049-9c22-2b79ddd9f8e9	0.001	mass	t	1 mg = 0.001 g	2026-08-18 01:38:14.161681+00
384ef38a-d813-4f33-8286-4c132a9cfcae	94c63c0a-5d55-4e18-b206-cf659d743231	45c69208-467c-4049-9c22-2b79ddd9f8e9	1000	mass	t	1 kg = 1000 g	2026-08-18 01:38:14.161681+00
f1d9cc9d-8f7d-447c-87ee-2661586c460f	45c69208-467c-4049-9c22-2b79ddd9f8e9	94c63c0a-5d55-4e18-b206-cf659d743231	1000	mass	t	1000 g = 1 kg	2026-08-18 01:38:14.161681+00
ca657822-64f0-4e49-be41-2d6de9be68b3	28189bfe-81a7-436d-b51e-a3855941669d	94c63c0a-5d55-4e18-b206-cf659d743231	0.001	mass	t	1 mg = 0.000001 kg	2026-08-18 01:38:14.161681+00
99ab7424-77f9-4470-87fd-7ca04153d60b	fae562bd-275f-4d85-afbf-f1cfc6a43a6e	c0315aa4-401f-45e7-8df4-96154ca33c6a	0.001	volume	t	1 ml = 0.001 L	2026-08-18 01:38:14.161681+00
40904346-f6cf-4b6e-9038-168078c68a68	c0315aa4-401f-45e7-8df4-96154ca33c6a	fae562bd-275f-4d85-afbf-f1cfc6a43a6e	1000	volume	t	1 L = 1000 ml	2026-08-18 01:38:14.161681+00
\.


--
-- Data for Name: units; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.units (id, code, name, symbol, dimension, is_base_unit, status_id, version_number, created_at, updated_at, deleted_at) FROM stdin;
45c69208-467c-4049-9c22-2b79ddd9f8e9	G	Gram	g	mass	t	1	1	2026-08-11 00:15:33.125181+00	2026-08-11 00:15:33.125181+00	\N
94c63c0a-5d55-4e18-b206-cf659d743231	KG	Kilogram	kg	mass	f	1	1	2026-08-11 00:15:33.125181+00	2026-08-11 00:15:33.125181+00	\N
fae562bd-275f-4d85-afbf-f1cfc6a43a6e	ML	Milliliter	ml	volume	t	1	1	2026-08-11 00:15:33.125181+00	2026-08-11 00:15:33.125181+00	\N
c0315aa4-401f-45e7-8df4-96154ca33c6a	L	Liter	L	volume	f	1	1	2026-08-11 00:15:33.125181+00	2026-08-11 00:15:33.125181+00	\N
28189bfe-81a7-436d-b51e-a3855941669d	MG	Milligram	mg	mass	f	1	1	2026-08-11 00:15:33.125181+00	2026-08-11 00:15:33.125181+00	\N
408296ef-b43f-4420-931f-52672f149434	PCS	Piece	pcs	count	t	1	1	2026-08-11 00:15:33.125181+00	2026-08-11 00:15:33.125181+00	\N
edd3befb-9aed-496d-ba0a-0bd772976ed6	KCAL	Kilocalorie	kcal	energy	f	1	1	2026-08-13 19:14:50.316377+00	2026-08-13 19:14:50.316377+00	\N
47882fab-351f-4ce1-95ea-529f000128ba	KJ	Kilojoule	kJ	energy	t	1	1	2026-08-13 19:14:50.316377+00	2026-08-13 19:14:50.316377+00	\N
\.


--
-- Data for Name: verification_statuses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.verification_statuses (id, code, name, description, display_order, status_id, version_number, created_at, updated_at, deleted_at) FROM stdin;
18ca5db5-32b8-4662-ac0d-be0b15cf0ba1	UNVERIFIED	Unverified	\N	0	1	1	2026-08-11 00:13:05.238317+00	2026-08-11 00:13:05.238317+00	\N
05408d93-519d-4e19-96d4-3a18bd1e85de	PENDING	Pending Verification	\N	0	1	1	2026-08-11 00:13:05.238317+00	2026-08-11 00:13:05.238317+00	\N
ed354cfc-f915-4805-842d-f035d8aacec5	VERIFIED	Verified	\N	0	1	1	2026-08-11 00:13:05.238317+00	2026-08-11 00:13:05.238317+00	\N
bcbb0479-e1eb-4177-bc2d-7d3fe2aba8b1	REJECTED	Rejected	\N	0	1	1	2026-08-11 00:13:05.238317+00	2026-08-11 00:13:05.238317+00	\N
\.


--
-- Data for Name: version_metadata; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.version_metadata (id, entity_version_id, key, value, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Name: lifecycle_statuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.lifecycle_statuses_id_seq', 3, true);


--
-- Name: allergen_translations allergen_translations_allergen_language_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allergen_translations
    ADD CONSTRAINT allergen_translations_allergen_language_unique UNIQUE (allergen_id, language_id);


--
-- Name: allergen_translations allergen_translations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allergen_translations
    ADD CONSTRAINT allergen_translations_pkey PRIMARY KEY (id);


--
-- Name: allergen_types allergen_types_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allergen_types
    ADD CONSTRAINT allergen_types_code_unique UNIQUE (code);


--
-- Name: allergen_types allergen_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allergen_types
    ADD CONSTRAINT allergen_types_pkey PRIMARY KEY (id);


--
-- Name: allergens_history allergens_history_entity_version_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allergens_history
    ADD CONSTRAINT allergens_history_entity_version_unique UNIQUE (original_entity_id, version_number);


--
-- Name: allergens_history allergens_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allergens_history
    ADD CONSTRAINT allergens_history_pkey PRIMARY KEY (id);


--
-- Name: allergens allergens_internal_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allergens
    ADD CONSTRAINT allergens_internal_code_unique UNIQUE (internal_code);


--
-- Name: allergens allergens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allergens
    ADD CONSTRAINT allergens_pkey PRIMARY KEY (id);


--
-- Name: audit_context audit_context_operation_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_context
    ADD CONSTRAINT audit_context_operation_unique UNIQUE (correlation_id, transaction_id);


--
-- Name: audit_context audit_context_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_context
    ADD CONSTRAINT audit_context_pkey PRIMARY KEY (id);


--
-- Name: audit_event_types audit_event_types_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_event_types
    ADD CONSTRAINT audit_event_types_code_unique UNIQUE (code);


--
-- Name: audit_event_types audit_event_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_event_types
    ADD CONSTRAINT audit_event_types_pkey PRIMARY KEY (id);


--
-- Name: audit_events audit_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_events
    ADD CONSTRAINT audit_events_pkey PRIMARY KEY (id);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: barcode_types barcode_types_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.barcode_types
    ADD CONSTRAINT barcode_types_code_unique UNIQUE (code);


--
-- Name: barcode_types barcode_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.barcode_types
    ADD CONSTRAINT barcode_types_pkey PRIMARY KEY (id);


--
-- Name: barcodes barcodes_barcode_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.barcodes
    ADD CONSTRAINT barcodes_barcode_unique UNIQUE (barcode);


--
-- Name: barcodes_history barcodes_history_entity_version_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.barcodes_history
    ADD CONSTRAINT barcodes_history_entity_version_unique UNIQUE (original_entity_id, version_number);


--
-- Name: barcodes_history barcodes_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.barcodes_history
    ADD CONSTRAINT barcodes_history_pkey PRIMARY KEY (id);


--
-- Name: barcodes barcodes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.barcodes
    ADD CONSTRAINT barcodes_pkey PRIMARY KEY (id);


--
-- Name: brand_search_index brand_search_index_brand_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.brand_search_index
    ADD CONSTRAINT brand_search_index_brand_id_unique UNIQUE (brand_id);


--
-- Name: brand_search_index brand_search_index_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.brand_search_index
    ADD CONSTRAINT brand_search_index_pkey PRIMARY KEY (id);


--
-- Name: brand_translations brand_translations_brand_language_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.brand_translations
    ADD CONSTRAINT brand_translations_brand_language_unique UNIQUE (brand_id, language_id);


--
-- Name: brand_translations brand_translations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.brand_translations
    ADD CONSTRAINT brand_translations_pkey PRIMARY KEY (id);


--
-- Name: brands_history brands_history_entity_version_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.brands_history
    ADD CONSTRAINT brands_history_entity_version_unique UNIQUE (original_entity_id, version_number);


--
-- Name: brands_history brands_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.brands_history
    ADD CONSTRAINT brands_history_pkey PRIMARY KEY (id);


--
-- Name: brands brands_internal_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.brands
    ADD CONSTRAINT brands_internal_code_unique UNIQUE (internal_code);


--
-- Name: brands brands_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.brands
    ADD CONSTRAINT brands_pkey PRIMARY KEY (id);


--
-- Name: change_sets change_sets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.change_sets
    ADD CONSTRAINT change_sets_pkey PRIMARY KEY (id);


--
-- Name: companies_history companies_history_entity_version_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.companies_history
    ADD CONSTRAINT companies_history_entity_version_unique UNIQUE (original_entity_id, version_number);


--
-- Name: companies_history companies_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.companies_history
    ADD CONSTRAINT companies_history_pkey PRIMARY KEY (id);


--
-- Name: companies companies_internal_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_internal_code_unique UNIQUE (internal_code);


--
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (id);


--
-- Name: company_search_index company_search_index_company_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_search_index
    ADD CONSTRAINT company_search_index_company_id_unique UNIQUE (company_id);


--
-- Name: company_search_index company_search_index_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_search_index
    ADD CONSTRAINT company_search_index_pkey PRIMARY KEY (id);


--
-- Name: company_translations company_translations_company_language_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_translations
    ADD CONSTRAINT company_translations_company_language_unique UNIQUE (company_id, language_id);


--
-- Name: company_translations company_translations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_translations
    ADD CONSTRAINT company_translations_pkey PRIMARY KEY (id);


--
-- Name: condition_nutrition_rules condition_nutrition_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.condition_nutrition_rules
    ADD CONSTRAINT condition_nutrition_rules_pkey PRIMARY KEY (id);


--
-- Name: countries countries_alpha_3_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.countries
    ADD CONSTRAINT countries_alpha_3_unique UNIQUE (alpha_3);


--
-- Name: countries countries_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.countries
    ADD CONSTRAINT countries_code_unique UNIQUE (code);


--
-- Name: countries countries_numeric_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.countries
    ADD CONSTRAINT countries_numeric_code_unique UNIQUE (numeric_code);


--
-- Name: countries countries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.countries
    ADD CONSTRAINT countries_pkey PRIMARY KEY (id);


--
-- Name: coverage_snapshots coverage_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coverage_snapshots
    ADD CONSTRAINT coverage_snapshots_pkey PRIMARY KEY (id);


--
-- Name: data_conflicts data_conflicts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.data_conflicts
    ADD CONSTRAINT data_conflicts_pkey PRIMARY KEY (id);


--
-- Name: data_sources data_sources_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.data_sources
    ADD CONSTRAINT data_sources_code_unique UNIQUE (code);


--
-- Name: data_sources data_sources_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.data_sources
    ADD CONSTRAINT data_sources_pkey PRIMARY KEY (id);


--
-- Name: data_versions data_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.data_versions
    ADD CONSTRAINT data_versions_pkey PRIMARY KEY (id);


--
-- Name: discovery_candidates discovery_candidates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discovery_candidates
    ADD CONSTRAINT discovery_candidates_pkey PRIMARY KEY (id);


--
-- Name: entity_relationships entity_relationships_edge_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entity_relationships
    ADD CONSTRAINT entity_relationships_edge_unique UNIQUE (subject_entity_type, subject_id, relationship_type_id, object_entity_type, object_id);


--
-- Name: entity_relationships entity_relationships_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entity_relationships
    ADD CONSTRAINT entity_relationships_pkey PRIMARY KEY (id);


--
-- Name: entity_versions entity_versions_entity_version_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entity_versions
    ADD CONSTRAINT entity_versions_entity_version_unique UNIQUE (entity_type, entity_id, version_number);


--
-- Name: entity_versions entity_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entity_versions
    ADD CONSTRAINT entity_versions_pkey PRIMARY KEY (id);


--
-- Name: evidence_types evidence_types_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evidence_types
    ADD CONSTRAINT evidence_types_code_unique UNIQUE (code);


--
-- Name: evidence_types evidence_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evidence_types
    ADD CONSTRAINT evidence_types_pkey PRIMARY KEY (id);


--
-- Name: halal_evidence halal_evidence_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.halal_evidence
    ADD CONSTRAINT halal_evidence_pkey PRIMARY KEY (id);


--
-- Name: health_conditions health_conditions_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_conditions
    ADD CONSTRAINT health_conditions_code_key UNIQUE (code);


--
-- Name: health_conditions health_conditions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_conditions
    ADD CONSTRAINT health_conditions_pkey PRIMARY KEY (id);


--
-- Name: health_flag_translations health_flag_translations_health_flag_language_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_flag_translations
    ADD CONSTRAINT health_flag_translations_health_flag_language_unique UNIQUE (health_flag_id, language_id);


--
-- Name: health_flag_translations health_flag_translations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_flag_translations
    ADD CONSTRAINT health_flag_translations_pkey PRIMARY KEY (id);


--
-- Name: health_flag_types health_flag_types_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_flag_types
    ADD CONSTRAINT health_flag_types_code_unique UNIQUE (code);


--
-- Name: health_flag_types health_flag_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_flag_types
    ADD CONSTRAINT health_flag_types_pkey PRIMARY KEY (id);


--
-- Name: health_flags_history health_flags_history_entity_version_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_flags_history
    ADD CONSTRAINT health_flags_history_entity_version_unique UNIQUE (original_entity_id, version_number);


--
-- Name: health_flags_history health_flags_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_flags_history
    ADD CONSTRAINT health_flags_history_pkey PRIMARY KEY (id);


--
-- Name: health_flags health_flags_internal_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_flags
    ADD CONSTRAINT health_flags_internal_code_unique UNIQUE (internal_code);


--
-- Name: health_flags health_flags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_flags
    ADD CONSTRAINT health_flags_pkey PRIMARY KEY (id);


--
-- Name: image_types image_types_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.image_types
    ADD CONSTRAINT image_types_code_unique UNIQUE (code);


--
-- Name: image_types image_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.image_types
    ADD CONSTRAINT image_types_pkey PRIMARY KEY (id);


--
-- Name: images images_content_hash_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.images
    ADD CONSTRAINT images_content_hash_unique UNIQUE (content_hash);


--
-- Name: images_history images_history_entity_version_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.images_history
    ADD CONSTRAINT images_history_entity_version_unique UNIQUE (original_entity_id, version_number);


--
-- Name: images_history images_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.images_history
    ADD CONSTRAINT images_history_pkey PRIMARY KEY (id);


--
-- Name: images images_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.images
    ADD CONSTRAINT images_pkey PRIMARY KEY (id);


--
-- Name: images images_storage_uri_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.images
    ADD CONSTRAINT images_storage_uri_unique UNIQUE (storage_uri);


--
-- Name: ingredient_aliases ingredient_aliases_ingredient_alias_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_aliases
    ADD CONSTRAINT ingredient_aliases_ingredient_alias_unique UNIQUE (ingredient_id, alias);


--
-- Name: ingredient_aliases ingredient_aliases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_aliases
    ADD CONSTRAINT ingredient_aliases_pkey PRIMARY KEY (id);


--
-- Name: ingredient_allergens ingredient_allergens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_allergens
    ADD CONSTRAINT ingredient_allergens_pkey PRIMARY KEY (id);


--
-- Name: ingredient_allergens ingredient_allergens_subject_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_allergens
    ADD CONSTRAINT ingredient_allergens_subject_unique UNIQUE (ingredient_id, allergen_id, relationship_type_id);


--
-- Name: ingredient_categories ingredient_categories_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_categories
    ADD CONSTRAINT ingredient_categories_code_unique UNIQUE (code);


--
-- Name: ingredient_categories_history ingredient_categories_history_entity_version_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_categories_history
    ADD CONSTRAINT ingredient_categories_history_entity_version_unique UNIQUE (original_entity_id, version_number);


--
-- Name: ingredient_categories_history ingredient_categories_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_categories_history
    ADD CONSTRAINT ingredient_categories_history_pkey PRIMARY KEY (id);


--
-- Name: ingredient_categories ingredient_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_categories
    ADD CONSTRAINT ingredient_categories_pkey PRIMARY KEY (id);


--
-- Name: ingredient_health_flags ingredient_health_flags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_health_flags
    ADD CONSTRAINT ingredient_health_flags_pkey PRIMARY KEY (id);


--
-- Name: ingredient_health_flags ingredient_health_flags_subject_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_health_flags
    ADD CONSTRAINT ingredient_health_flags_subject_unique UNIQUE (ingredient_id, health_flag_id, relationship_type_id);


--
-- Name: ingredient_search_index ingredient_search_index_ingredient_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_search_index
    ADD CONSTRAINT ingredient_search_index_ingredient_id_unique UNIQUE (ingredient_id);


--
-- Name: ingredient_search_index ingredient_search_index_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_search_index
    ADD CONSTRAINT ingredient_search_index_pkey PRIMARY KEY (id);


--
-- Name: ingredient_translations ingredient_translations_ingredient_language_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_translations
    ADD CONSTRAINT ingredient_translations_ingredient_language_unique UNIQUE (ingredient_id, language_id);


--
-- Name: ingredient_translations ingredient_translations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_translations
    ADD CONSTRAINT ingredient_translations_pkey PRIMARY KEY (id);


--
-- Name: ingredients_history ingredients_history_entity_version_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredients_history
    ADD CONSTRAINT ingredients_history_entity_version_unique UNIQUE (original_entity_id, version_number);


--
-- Name: ingredients_history ingredients_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredients_history
    ADD CONSTRAINT ingredients_history_pkey PRIMARY KEY (id);


--
-- Name: ingredients ingredients_internal_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredients
    ADD CONSTRAINT ingredients_internal_code_unique UNIQUE (internal_code);


--
-- Name: ingredients ingredients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredients
    ADD CONSTRAINT ingredients_pkey PRIMARY KEY (id);


--
-- Name: languages languages_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.languages
    ADD CONSTRAINT languages_code_unique UNIQUE (code);


--
-- Name: languages languages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.languages
    ADD CONSTRAINT languages_pkey PRIMARY KEY (id);


--
-- Name: lifecycle_statuses lifecycle_statuses_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lifecycle_statuses
    ADD CONSTRAINT lifecycle_statuses_code_unique UNIQUE (code);


--
-- Name: lifecycle_statuses lifecycle_statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lifecycle_statuses
    ADD CONSTRAINT lifecycle_statuses_pkey PRIMARY KEY (id);


--
-- Name: measurement_bases measurement_bases_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.measurement_bases
    ADD CONSTRAINT measurement_bases_code_unique UNIQUE (code);


--
-- Name: measurement_bases measurement_bases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.measurement_bases
    ADD CONSTRAINT measurement_bases_pkey PRIMARY KEY (id);


--
-- Name: nutrition_type_translations nutrition_type_translations_nutrition_type_language_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nutrition_type_translations
    ADD CONSTRAINT nutrition_type_translations_nutrition_type_language_unique UNIQUE (nutrition_type_id, language_id);


--
-- Name: nutrition_type_translations nutrition_type_translations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nutrition_type_translations
    ADD CONSTRAINT nutrition_type_translations_pkey PRIMARY KEY (id);


--
-- Name: nutrition_types nutrition_types_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nutrition_types
    ADD CONSTRAINT nutrition_types_code_unique UNIQUE (code);


--
-- Name: nutrition_types_history nutrition_types_history_entity_version_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nutrition_types_history
    ADD CONSTRAINT nutrition_types_history_entity_version_unique UNIQUE (original_entity_id, version_number);


--
-- Name: nutrition_types_history nutrition_types_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nutrition_types_history
    ADD CONSTRAINT nutrition_types_history_pkey PRIMARY KEY (id);


--
-- Name: nutrition_types nutrition_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nutrition_types
    ADD CONSTRAINT nutrition_types_pkey PRIMARY KEY (id);


--
-- Name: package_types package_types_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.package_types
    ADD CONSTRAINT package_types_code_unique UNIQUE (code);


--
-- Name: package_types package_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.package_types
    ADD CONSTRAINT package_types_pkey PRIMARY KEY (id);


--
-- Name: permission_types permission_types_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permission_types
    ADD CONSTRAINT permission_types_code_unique UNIQUE (code);


--
-- Name: permission_types permission_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permission_types
    ADD CONSTRAINT permission_types_pkey PRIMARY KEY (id);


--
-- Name: product_allergens product_allergens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_allergens
    ADD CONSTRAINT product_allergens_pkey PRIMARY KEY (id);


--
-- Name: product_allergens product_allergens_subject_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_allergens
    ADD CONSTRAINT product_allergens_subject_unique UNIQUE (product_id, allergen_id, relationship_type_id);


--
-- Name: product_barcodes product_barcodes_association_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_barcodes
    ADD CONSTRAINT product_barcodes_association_unique UNIQUE (product_id, barcode_id, relationship_type_id);


--
-- Name: product_barcodes_history product_barcodes_history_entity_version_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_barcodes_history
    ADD CONSTRAINT product_barcodes_history_entity_version_unique UNIQUE (original_entity_id, version_number);


--
-- Name: product_barcodes_history product_barcodes_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_barcodes_history
    ADD CONSTRAINT product_barcodes_history_pkey PRIMARY KEY (id);


--
-- Name: product_barcodes product_barcodes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_barcodes
    ADD CONSTRAINT product_barcodes_pkey PRIMARY KEY (id);


--
-- Name: product_categories product_categories_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_categories
    ADD CONSTRAINT product_categories_code_unique UNIQUE (code);


--
-- Name: product_categories_history product_categories_history_entity_version_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_categories_history
    ADD CONSTRAINT product_categories_history_entity_version_unique UNIQUE (original_entity_id, version_number);


--
-- Name: product_categories_history product_categories_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_categories_history
    ADD CONSTRAINT product_categories_history_pkey PRIMARY KEY (id);


--
-- Name: product_categories product_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_categories
    ADD CONSTRAINT product_categories_pkey PRIMARY KEY (id);


--
-- Name: product_category_translations product_category_translations_category_language_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_category_translations
    ADD CONSTRAINT product_category_translations_category_language_unique UNIQUE (product_category_id, language_id);


--
-- Name: product_category_translations product_category_translations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_category_translations
    ADD CONSTRAINT product_category_translations_pkey PRIMARY KEY (id);


--
-- Name: product_health_evaluations product_health_evaluations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_health_evaluations
    ADD CONSTRAINT product_health_evaluations_pkey PRIMARY KEY (id);


--
-- Name: product_health_flags product_health_flags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_health_flags
    ADD CONSTRAINT product_health_flags_pkey PRIMARY KEY (id);


--
-- Name: product_health_flags product_health_flags_subject_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_health_flags
    ADD CONSTRAINT product_health_flags_subject_unique UNIQUE (product_id, health_flag_id, relationship_type_id);


--
-- Name: product_images product_images_attachment_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_images
    ADD CONSTRAINT product_images_attachment_unique UNIQUE (product_id, image_id, relationship_type_id);


--
-- Name: product_images_history product_images_history_entity_version_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_images_history
    ADD CONSTRAINT product_images_history_entity_version_unique UNIQUE (original_entity_id, version_number);


--
-- Name: product_images_history product_images_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_images_history
    ADD CONSTRAINT product_images_history_pkey PRIMARY KEY (id);


--
-- Name: product_images product_images_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_images
    ADD CONSTRAINT product_images_pkey PRIMARY KEY (id);


--
-- Name: product_ingredients product_ingredients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_ingredients
    ADD CONSTRAINT product_ingredients_pkey PRIMARY KEY (id);


--
-- Name: product_ingredients product_ingredients_subject_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_ingredients
    ADD CONSTRAINT product_ingredients_subject_unique UNIQUE (product_id, ingredient_id, relationship_type_id);


--
-- Name: product_nutrition_values product_nutrition_values_fact_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_nutrition_values
    ADD CONSTRAINT product_nutrition_values_fact_unique UNIQUE (product_id, nutrition_type_id, relationship_type_id, measurement_basis_id);


--
-- Name: product_nutrition_values product_nutrition_values_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_nutrition_values
    ADD CONSTRAINT product_nutrition_values_pkey PRIMARY KEY (id);


--
-- Name: product_search_index product_search_index_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_search_index
    ADD CONSTRAINT product_search_index_pkey PRIMARY KEY (id);


--
-- Name: product_search_index product_search_index_product_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_search_index
    ADD CONSTRAINT product_search_index_product_id_unique UNIQUE (product_id);


--
-- Name: product_translations product_translations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_translations
    ADD CONSTRAINT product_translations_pkey PRIMARY KEY (id);


--
-- Name: product_translations product_translations_product_language_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_translations
    ADD CONSTRAINT product_translations_product_language_unique UNIQUE (product_id, language_id);


--
-- Name: products_history products_history_entity_version_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products_history
    ADD CONSTRAINT products_history_entity_version_unique UNIQUE (original_entity_id, version_number);


--
-- Name: products_history products_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products_history
    ADD CONSTRAINT products_history_pkey PRIMARY KEY (id);


--
-- Name: products products_internal_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_internal_code_unique UNIQUE (internal_code);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: regions regions_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.regions
    ADD CONSTRAINT regions_code_unique UNIQUE (code);


--
-- Name: regions regions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.regions
    ADD CONSTRAINT regions_pkey PRIMARY KEY (id);


--
-- Name: regulatory_authorities regulatory_authorities_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.regulatory_authorities
    ADD CONSTRAINT regulatory_authorities_code_unique UNIQUE (code);


--
-- Name: regulatory_authorities regulatory_authorities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.regulatory_authorities
    ADD CONSTRAINT regulatory_authorities_pkey PRIMARY KEY (id);


--
-- Name: relationship_types relationship_types_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relationship_types
    ADD CONSTRAINT relationship_types_code_unique UNIQUE (code);


--
-- Name: relationship_types relationship_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relationship_types
    ADD CONSTRAINT relationship_types_pkey PRIMARY KEY (id);


--
-- Name: role_types role_types_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_types
    ADD CONSTRAINT role_types_code_unique UNIQUE (code);


--
-- Name: role_types role_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_types
    ADD CONSTRAINT role_types_pkey PRIMARY KEY (id);


--
-- Name: scan_job_items scan_job_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scan_job_items
    ADD CONSTRAINT scan_job_items_pkey PRIMARY KEY (id);


--
-- Name: scan_jobs scan_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scan_jobs
    ADD CONSTRAINT scan_jobs_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: source_priorities source_priorities_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.source_priorities
    ADD CONSTRAINT source_priorities_code_unique UNIQUE (code);


--
-- Name: source_priorities source_priorities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.source_priorities
    ADD CONSTRAINT source_priorities_pkey PRIMARY KEY (id);


--
-- Name: source_priorities source_priorities_rank_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.source_priorities
    ADD CONSTRAINT source_priorities_rank_unique UNIQUE (rank);


--
-- Name: source_types source_types_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.source_types
    ADD CONSTRAINT source_types_code_unique UNIQUE (code);


--
-- Name: source_types source_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.source_types
    ADD CONSTRAINT source_types_pkey PRIMARY KEY (id);


--
-- Name: unit_conversions unit_conversions_from_unit_id_to_unit_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unit_conversions
    ADD CONSTRAINT unit_conversions_from_unit_id_to_unit_id_key UNIQUE (from_unit_id, to_unit_id);


--
-- Name: unit_conversions unit_conversions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unit_conversions
    ADD CONSTRAINT unit_conversions_pkey PRIMARY KEY (id);


--
-- Name: units units_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.units
    ADD CONSTRAINT units_code_unique UNIQUE (code);


--
-- Name: units units_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.units
    ADD CONSTRAINT units_pkey PRIMARY KEY (id);


--
-- Name: units units_symbol_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.units
    ADD CONSTRAINT units_symbol_unique UNIQUE (symbol);


--
-- Name: verification_statuses verification_statuses_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.verification_statuses
    ADD CONSTRAINT verification_statuses_code_unique UNIQUE (code);


--
-- Name: verification_statuses verification_statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.verification_statuses
    ADD CONSTRAINT verification_statuses_pkey PRIMARY KEY (id);


--
-- Name: version_metadata version_metadata_key_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.version_metadata
    ADD CONSTRAINT version_metadata_key_unique UNIQUE (entity_version_id, key);


--
-- Name: version_metadata version_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.version_metadata
    ADD CONSTRAINT version_metadata_pkey PRIMARY KEY (id);


--
-- Name: allergen_translations_allergen_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX allergen_translations_allergen_id_idx ON public.allergen_translations USING btree (allergen_id);


--
-- Name: allergen_translations_language_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX allergen_translations_language_id_idx ON public.allergen_translations USING btree (language_id);


--
-- Name: allergen_types_status_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX allergen_types_status_id_idx ON public.allergen_types USING btree (status_id);


--
-- Name: allergens_allergen_type_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX allergens_allergen_type_id_idx ON public.allergens USING btree (allergen_type_id);


--
-- Name: allergens_history_allergen_type_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX allergens_history_allergen_type_id_idx ON public.allergens_history USING btree (allergen_type_id);


--
-- Name: allergens_history_change_set_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX allergens_history_change_set_id_idx ON public.allergens_history USING btree (change_set_id);


--
-- Name: allergens_history_original_entity_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX allergens_history_original_entity_id_idx ON public.allergens_history USING btree (original_entity_id);


--
-- Name: allergens_history_previous_version_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX allergens_history_previous_version_id_idx ON public.allergens_history USING btree (previous_version_id);


--
-- Name: allergens_history_source_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX allergens_history_source_id_idx ON public.allergens_history USING btree (source_id);


--
-- Name: allergens_history_status_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX allergens_history_status_id_idx ON public.allergens_history USING btree (status_id);


--
-- Name: allergens_source_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX allergens_source_id_idx ON public.allergens USING btree (source_id);


--
-- Name: audit_context_role_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_context_role_id_idx ON public.audit_context USING btree (role_id);


--
-- Name: audit_event_types_status_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_event_types_status_id_idx ON public.audit_event_types USING btree (status_id);


--
-- Name: audit_events_audit_log_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_events_audit_log_id_idx ON public.audit_events USING btree (audit_log_id);


--
-- Name: audit_events_event_type_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_events_event_type_id_idx ON public.audit_events USING btree (event_type_id);


--
-- Name: audit_log_change_set_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_log_change_set_id_idx ON public.audit_log USING btree (change_set_id);


--
-- Name: audit_log_event_type_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_log_event_type_id_idx ON public.audit_log USING btree (event_type_id);


--
-- Name: audit_log_role_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_log_role_id_idx ON public.audit_log USING btree (role_id);


--
-- Name: barcode_types_status_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX barcode_types_status_id_idx ON public.barcode_types USING btree (status_id);


--
-- Name: barcodes_barcode_type_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX barcodes_barcode_type_id_idx ON public.barcodes USING btree (barcode_type_id);


--
-- Name: barcodes_history_barcode_type_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX barcodes_history_barcode_type_id_idx ON public.barcodes_history USING btree (barcode_type_id);


--
-- Name: barcodes_history_change_set_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX barcodes_history_change_set_id_idx ON public.barcodes_history USING btree (change_set_id);


--
-- Name: barcodes_history_issued_country_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX barcodes_history_issued_country_id_idx ON public.barcodes_history USING btree (issued_country_id);


--
-- Name: barcodes_history_original_entity_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX barcodes_history_original_entity_id_idx ON public.barcodes_history USING btree (original_entity_id);


--
-- Name: barcodes_history_previous_version_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX barcodes_history_previous_version_id_idx ON public.barcodes_history USING btree (previous_version_id);


--
-- Name: barcodes_history_source_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX barcodes_history_source_id_idx ON public.barcodes_history USING btree (source_id);


--
-- Name: barcodes_history_status_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX barcodes_history_status_id_idx ON public.barcodes_history USING btree (status_id);


--
-- Name: barcodes_history_verification_status_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX barcodes_history_verification_status_id_idx ON public.barcodes_history USING btree (verification_status_id);


--
-- Name: barcodes_issued_country_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX barcodes_issued_country_id_idx ON public.barcodes USING btree (issued_country_id);


--
-- Name: barcodes_source_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX barcodes_source_id_idx ON public.barcodes USING btree (source_id);


--
-- Name: barcodes_status_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX barcodes_status_id_idx ON public.barcodes USING btree (status_id);


--
-- Name: barcodes_verification_status_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX barcodes_verification_status_id_idx ON public.barcodes USING btree (verification_status_id);


--
-- Name: brand_search_index_search_name_trgm_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX brand_search_index_search_name_trgm_idx ON public.brand_search_index USING gin (search_name public.gin_trgm_ops);


--
-- Name: brand_search_index_search_rank_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX brand_search_index_search_rank_idx ON public.brand_search_index USING btree (search_rank DESC);


--
-- Name: brand_search_index_search_text_trgm_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX brand_search_index_search_text_trgm_idx ON public.brand_search_index USING gin (search_text public.gin_trgm_ops);


--
-- Name: brand_search_index_search_tokens_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX brand_search_index_search_tokens_idx ON public.brand_search_index USING gin (search_tokens);


--
-- Name: brand_translations_brand_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX brand_translations_brand_id_idx ON public.brand_translations USING btree (brand_id);


--
-- Name: brand_translations_language_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX brand_translations_language_id_idx ON public.brand_translations USING btree (language_id);


--
-- Name: brands_company_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX brands_company_id_idx ON public.brands USING btree (company_id);


--
-- Name: brands_history_change_set_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX brands_history_change_set_id_idx ON public.brands_history USING btree (change_set_id);


--
-- Name: brands_history_company_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX brands_history_company_id_idx ON public.brands_history USING btree (company_id);


--
-- Name: brands_history_original_entity_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX brands_history_original_entity_id_idx ON public.brands_history USING btree (original_entity_id);


--
-- Name: brands_history_previous_version_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX brands_history_previous_version_id_idx ON public.brands_history USING btree (previous_version_id);


--
-- Name: brands_history_source_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX brands_history_source_id_idx ON public.brands_history USING btree (source_id);


--
-- Name: brands_history_status_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX brands_history_status_id_idx ON public.brands_history USING btree (status_id);


--
-- Name: brands_source_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX brands_source_id_idx ON public.brands USING btree (source_id);


--
-- Name: change_sets_correlation_id_transaction_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX change_sets_correlation_id_transaction_id_idx ON public.change_sets USING btree (correlation_id, transaction_id);


--
-- Name: companies_history_change_set_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX companies_history_change_set_id_idx ON public.companies_history USING btree (change_set_id);


--
-- Name: companies_history_original_entity_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX companies_history_original_entity_id_idx ON public.companies_history USING btree (original_entity_id);


--
-- Name: companies_history_previous_version_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX companies_history_previous_version_id_idx ON public.companies_history USING btree (previous_version_id);


--
-- Name: companies_history_source_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX companies_history_source_id_idx ON public.companies_history USING btree (source_id);


--
-- Name: companies_history_status_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX companies_history_status_id_idx ON public.companies_history USING btree (status_id);


--
-- Name: companies_source_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX companies_source_id_idx ON public.companies USING btree (source_id);


--
-- Name: company_search_index_search_name_trgm_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX company_search_index_search_name_trgm_idx ON public.company_search_index USING gin (search_name public.gin_trgm_ops);


--
-- Name: company_search_index_search_rank_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX company_search_index_search_rank_idx ON public.company_search_index USING btree (search_rank DESC);


--
-- Name: company_search_index_search_text_trgm_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX company_search_index_search_text_trgm_idx ON public.company_search_index USING gin (search_text public.gin_trgm_ops);


--
-- Name: company_search_index_search_tokens_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX company_search_index_search_tokens_idx ON public.company_search_index USING gin (search_tokens);


--
-- Name: company_translations_company_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX company_translations_company_id_idx ON public.company_translations USING btree (company_id);


--
-- Name: company_translations_language_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX company_translations_language_id_idx ON public.company_translations USING btree (language_id);


--
-- Name: countries_status_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX countries_status_id_idx ON public.countries USING btree (status_id);


--
-- Name: data_sources_country_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX data_sources_country_id_idx ON public.data_sources USING btree (country_id) WHERE (country_id IS NOT NULL);


--
-- Name: data_sources_priority_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX data_sources_priority_id_idx ON public.data_sources USING btree (priority_id);


--
-- Name: data_sources_source_type_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX data_sources_source_type_id_idx ON public.data_sources USING btree (source_type_id);


--
-- Name: data_sources_status_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX data_sources_status_id_idx ON public.data_sources USING btree (status_id);


--
-- Name: entity_relationships_evidence_type_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX entity_relationships_evidence_type_id_idx ON public.entity_relationships USING btree (evidence_type_id);


--
-- Name: entity_relationships_relationship_type_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX entity_relationships_relationship_type_id_idx ON public.entity_relationships USING btree (relationship_type_id);


--
-- Name: entity_relationships_source_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX entity_relationships_source_id_idx ON public.entity_relationships USING btree (source_id);


--
-- Name: entity_relationships_status_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX entity_relationships_status_id_idx ON public.entity_relationships USING btree (status_id);


--
-- Name: entity_versions_change_set_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX entity_versions_change_set_id_idx ON public.entity_versions USING btree (change_set_id);


--
-- Name: entity_versions_previous_version_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX entity_versions_previous_version_id_idx ON public.entity_versions USING btree (previous_version_id);


--
-- Name: evidence_types_status_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX evidence_types_status_id_idx ON public.evidence_types USING btree (status_id);


--
-- Name: health_flag_translations_health_flag_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX health_flag_translations_health_flag_id_idx ON public.health_flag_translations USING btree (health_flag_id);


--
-- Name: health_flag_translations_language_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX health_flag_translations_language_id_idx ON public.health_flag_translations USING btree (language_id);


--
-- Name: health_flag_types_status_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX health_flag_types_status_id_idx ON public.health_flag_types USING btree (status_id);


--
-- Name: health_flags_health_flag_type_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX health_flags_health_flag_type_id_idx ON public.health_flags USING btree (health_flag_type_id);


--
-- Name: health_flags_history_change_set_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX health_flags_history_change_set_id_idx ON public.health_flags_history USING btree (change_set_id);


--
-- Name: health_flags_history_health_flag_type_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX health_flags_history_health_flag_type_id_idx ON public.health_flags_history USING btree (health_flag_type_id);


--
-- Name: health_flags_history_original_entity_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX health_flags_history_original_entity_id_idx ON public.health_flags_history USING btree (original_entity_id);


--
-- Name: health_flags_history_previous_version_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX health_flags_history_previous_version_id_idx ON public.health_flags_history USING btree (previous_version_id);


--
-- Name: health_flags_history_source_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX health_flags_history_source_id_idx ON public.health_flags_history USING btree (source_id);


--
-- Name: health_flags_history_status_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX health_flags_history_status_id_idx ON public.health_flags_history USING btree (status_id);


--
-- Name: health_flags_source_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX health_flags_source_id_idx ON public.health_flags USING btree (source_id);


--
-- Name: idx_conflicts_entity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_conflicts_entity ON public.data_conflicts USING btree (entity_type, entity_id);


--
-- Name: idx_conflicts_resolution; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_conflicts_resolution ON public.data_conflicts USING btree (resolution);


--
-- Name: idx_conflicts_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_conflicts_status ON public.data_conflicts USING btree (status);


--
-- Name: idx_coverage_company; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_coverage_company ON public.coverage_snapshots USING btree (company_id);


--
-- Name: idx_data_versions_entity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_data_versions_entity ON public.data_versions USING btree (entity_type, entity_id);


--
-- Name: idx_discovery_barcode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_discovery_barcode ON public.discovery_candidates USING btree (barcode);


--
-- Name: idx_discovery_company; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_discovery_company ON public.discovery_candidates USING btree (company_id);


--
-- Name: idx_discovery_scan_job; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_discovery_scan_job ON public.discovery_candidates USING btree (scan_job_id);


--
-- Name: idx_discovery_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_discovery_status ON public.discovery_candidates USING btree (status);


--
-- Name: idx_halal_current; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_halal_current ON public.halal_evidence USING btree (product_id, is_current);


--
-- Name: idx_halal_product; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_halal_product ON public.halal_evidence USING btree (product_id);


--
-- Name: idx_health_eval_condition; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_health_eval_condition ON public.product_health_evaluations USING btree (condition_id);


--
-- Name: idx_health_eval_product; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_health_eval_product ON public.product_health_evaluations USING btree (product_id);


--
-- Name: idx_scan_job_items_job; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_scan_job_items_job ON public.scan_job_items USING btree (scan_job_id);


--
-- Name: idx_scan_job_items_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_scan_job_items_status ON public.scan_job_items USING btree (status);


--
-- Name: idx_scan_jobs_company; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_scan_jobs_company ON public.scan_jobs USING btree (company_id);


--
-- Name: idx_scan_jobs_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_scan_jobs_status ON public.scan_jobs USING btree (status);


--
-- Name: idx_unit_conv_from; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_unit_conv_from ON public.unit_conversions USING btree (from_unit_id);


--
-- Name: image_types_status_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX image_types_status_id_idx ON public.image_types USING btree (status_id);


--
-- Name: images_history_change_set_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX images_history_change_set_id_idx ON public.images_history USING btree (change_set_id);


--
-- Name: images_history_image_type_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX images_history_image_type_id_idx ON public.images_history USING btree (image_type_id);


--
-- Name: images_history_language_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX images_history_language_id_idx ON public.images_history USING btree (language_id);


--
-- Name: images_history_original_entity_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX images_history_original_entity_id_idx ON public.images_history USING btree (original_entity_id);


--
-- Name: images_history_previous_version_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX images_history_previous_version_id_idx ON public.images_history USING btree (previous_version_id);


--
-- Name: images_history_source_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX images_history_source_id_idx ON public.images_history USING btree (source_id);


--
-- Name: images_history_status_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX images_history_status_id_idx ON public.images_history USING btree (status_id);


--
-- Name: images_image_type_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX images_image_type_id_idx ON public.images USING btree (image_type_id);


--
-- Name: images_language_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX images_language_id_idx ON public.images USING btree (language_id);


--
-- Name: images_source_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX images_source_id_idx ON public.images USING btree (source_id);


--
-- Name: images_status_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX images_status_id_idx ON public.images USING btree (status_id);


--
-- Name: ingredient_aliases_evidence_type_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ingredient_aliases_evidence_type_id_idx ON public.ingredient_aliases USING btree (evidence_type_id);


--
-- Name: ingredient_aliases_ingredient_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ingredient_aliases_ingredient_id_idx ON public.ingredient_aliases USING btree (ingredient_id);


--
-- Name: ingredient_aliases_language_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ingredient_aliases_language_id_idx ON public.ingredient_aliases USING btree (language_id);


--
-- Name: ingredient_aliases_relationship_type_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ingredient_aliases_relationship_type_id_idx ON public.ingredient_aliases USING btree (relationship_type_id);


--
-- Name: ingredient_aliases_source_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ingredient_aliases_source_id_idx ON public.ingredient_aliases USING btree (source_id);


--
-- Name: ingredient_aliases_status_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ingredient_aliases_status_id_idx ON public.ingredient_aliases USING btree (status_id);


--
-- Name: ingredient_allergens_allergen_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ingredient_allergens_allergen_id_idx ON public.ingredient_allergens USING btree (allergen_id);


--
-- Name: ingredient_allergens_evidence_type_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ingredient_allergens_evidence_type_id_idx ON public.ingredient_allergens USING btree (evidence_type_id);


--
-- Name: ingredient_allergens_ingredient_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ingredient_allergens_ingredient_id_idx ON public.ingredient_allergens USING btree (ingredient_id);


--
-- Name: ingredient_allergens_relationship_type_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ingredient_allergens_relationship_type_id_idx ON public.ingredient_allergens USING btree (relationship_type_id);


--
-- Name: ingredient_allergens_source_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ingredient_allergens_source_id_idx ON public.ingredient_allergens USING btree (source_id);


--
-- Name: ingredient_allergens_status_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ingredient_allergens_status_id_idx ON public.ingredient_allergens USING btree (status_id);


--
-- Name: ingredient_categories_history_change_set_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ingredient_categories_history_change_set_id_idx ON public.ingredient_categories_history USING btree (change_set_id);


--
-- Name: ingredient_categories_history_original_entity_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ingredient_categories_history_original_entity_id_idx ON public.ingredient_categories_history USING btree (original_entity_id);


--
-- Name: ingredient_categories_history_parent_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ingredient_categories_history_parent_id_idx ON public.ingredient_categories_history USING btree (parent_id);


--
-- Name: ingredient_categories_history_previous_version_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ingredient_categories_history_previous_version_id_idx ON public.ingredient_categories_history USING btree (previous_version_id);


--
-- Name: ingredient_categories_history_source_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ingredient_categories_history_source_id_idx ON public.ingredient_categories_history USING btree (source_id);


--
-- Name: ingredient_categories_history_status_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ingredient_categories_history_status_id_idx ON public.ingredient_categories_history USING btree (status_id);


--
-- Name: ingredient_categories_parent_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ingredient_categories_parent_id_idx ON public.ingredient_categories USING btree (parent_id);


--
-- Name: ingredient_categories_status_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ingredient_categories_status_id_idx ON public.ingredient_categories USING btree (status_id);


--
-- Name: ingredient_health_flags_evidence_type_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ingredient_health_flags_evidence_type_id_idx ON public.ingredient_health_flags USING btree (evidence_type_id);


--
-- Name: ingredient_health_flags_health_flag_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ingredient_health_flags_health_flag_id_idx ON public.ingredient_health_flags USING btree (health_flag_id);


--
-- Name: ingredient_health_flags_ingredient_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ingredient_health_flags_ingredient_id_idx ON public.ingredient_health_flags USING btree (ingredient_id);


--
-- Name: ingredient_health_flags_relationship_type_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ingredient_health_flags_relationship_type_id_idx ON public.ingredient_health_flags USING btree (relationship_type_id);


--
-- Name: ingredient_health_flags_source_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ingredient_health_flags_source_id_idx ON public.ingredient_health_flags USING btree (source_id);


--
-- Name: ingredient_health_flags_status_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ingredient_health_flags_status_id_idx ON public.ingredient_health_flags USING btree (status_id);


--
-- Name: ingredient_search_index_search_name_trgm_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ingredient_search_index_search_name_trgm_idx ON public.ingredient_search_index USING gin (search_name public.gin_trgm_ops);


--
-- Name: ingredient_search_index_search_rank_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ingredient_search_index_search_rank_idx ON public.ingredient_search_index USING btree (search_rank DESC);


--
-- Name: ingredient_search_index_search_text_trgm_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ingredient_search_index_search_text_trgm_idx ON public.ingredient_search_index USING gin (search_text public.gin_trgm_ops);


--
-- Name: ingredient_search_index_search_tokens_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ingredient_search_index_search_tokens_idx ON public.ingredient_search_index USING gin (search_tokens);


--
-- Name: ingredient_translations_ingredient_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ingredient_translations_ingredient_id_idx ON public.ingredient_translations USING btree (ingredient_id);


--
-- Name: ingredient_translations_language_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ingredient_translations_language_id_idx ON public.ingredient_translations USING btree (language_id);


--
-- Name: ingredients_history_change_set_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ingredients_history_change_set_id_idx ON public.ingredients_history USING btree (change_set_id);


--
-- Name: ingredients_history_original_entity_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ingredients_history_original_entity_id_idx ON public.ingredients_history USING btree (original_entity_id);


--
-- Name: ingredients_history_previous_version_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ingredients_history_previous_version_id_idx ON public.ingredients_history USING btree (previous_version_id);


--
-- Name: ingredients_history_source_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ingredients_history_source_id_idx ON public.ingredients_history USING btree (source_id);


--
-- Name: ingredients_history_status_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ingredients_history_status_id_idx ON public.ingredients_history USING btree (status_id);


--
-- Name: ingredients_source_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ingredients_source_id_idx ON public.ingredients USING btree (source_id);


--
-- Name: languages_status_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX languages_status_id_idx ON public.languages USING btree (status_id);


--
-- Name: measurement_bases_status_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX measurement_bases_status_id_idx ON public.measurement_bases USING btree (status_id);


--
-- Name: nutrition_type_translations_language_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX nutrition_type_translations_language_id_idx ON public.nutrition_type_translations USING btree (language_id);


--
-- Name: nutrition_type_translations_nutrition_type_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX nutrition_type_translations_nutrition_type_id_idx ON public.nutrition_type_translations USING btree (nutrition_type_id);


--
-- Name: nutrition_types_history_change_set_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX nutrition_types_history_change_set_id_idx ON public.nutrition_types_history USING btree (change_set_id);


--
-- Name: nutrition_types_history_original_entity_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX nutrition_types_history_original_entity_id_idx ON public.nutrition_types_history USING btree (original_entity_id);


--
-- Name: nutrition_types_history_previous_version_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX nutrition_types_history_previous_version_id_idx ON public.nutrition_types_history USING btree (previous_version_id);


--
-- Name: nutrition_types_history_source_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX nutrition_types_history_source_id_idx ON public.nutrition_types_history USING btree (source_id);


--
-- Name: nutrition_types_history_status_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX nutrition_types_history_status_id_idx ON public.nutrition_types_history USING btree (status_id);


--
-- Name: nutrition_types_status_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX nutrition_types_status_id_idx ON public.nutrition_types USING btree (status_id);


--
-- Name: package_types_status_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX package_types_status_id_idx ON public.package_types USING btree (status_id);


--
-- Name: permission_types_status_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX permission_types_status_id_idx ON public.permission_types USING btree (status_id);


--
-- Name: product_allergens_allergen_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_allergens_allergen_id_idx ON public.product_allergens USING btree (allergen_id);


--
-- Name: product_allergens_evidence_type_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_allergens_evidence_type_id_idx ON public.product_allergens USING btree (evidence_type_id);


--
-- Name: product_allergens_product_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_allergens_product_id_idx ON public.product_allergens USING btree (product_id);


--
-- Name: product_allergens_relationship_type_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_allergens_relationship_type_id_idx ON public.product_allergens USING btree (relationship_type_id);


--
-- Name: product_allergens_source_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_allergens_source_id_idx ON public.product_allergens USING btree (source_id);


--
-- Name: product_allergens_status_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_allergens_status_id_idx ON public.product_allergens USING btree (status_id);


--
-- Name: product_barcodes_barcode_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_barcodes_barcode_id_idx ON public.product_barcodes USING btree (barcode_id);


--
-- Name: product_barcodes_evidence_type_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_barcodes_evidence_type_id_idx ON public.product_barcodes USING btree (evidence_type_id);


--
-- Name: product_barcodes_history_barcode_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_barcodes_history_barcode_id_idx ON public.product_barcodes_history USING btree (barcode_id);


--
-- Name: product_barcodes_history_change_set_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_barcodes_history_change_set_id_idx ON public.product_barcodes_history USING btree (change_set_id);


--
-- Name: product_barcodes_history_evidence_type_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_barcodes_history_evidence_type_id_idx ON public.product_barcodes_history USING btree (evidence_type_id);


--
-- Name: product_barcodes_history_original_entity_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_barcodes_history_original_entity_id_idx ON public.product_barcodes_history USING btree (original_entity_id);


--
-- Name: product_barcodes_history_previous_version_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_barcodes_history_previous_version_id_idx ON public.product_barcodes_history USING btree (previous_version_id);


--
-- Name: product_barcodes_history_product_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_barcodes_history_product_id_idx ON public.product_barcodes_history USING btree (product_id);


--
-- Name: product_barcodes_history_relationship_type_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_barcodes_history_relationship_type_id_idx ON public.product_barcodes_history USING btree (relationship_type_id);


--
-- Name: product_barcodes_history_source_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_barcodes_history_source_id_idx ON public.product_barcodes_history USING btree (source_id);


--
-- Name: product_barcodes_history_status_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_barcodes_history_status_id_idx ON public.product_barcodes_history USING btree (status_id);


--
-- Name: product_barcodes_product_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_barcodes_product_id_idx ON public.product_barcodes USING btree (product_id);


--
-- Name: product_barcodes_relationship_type_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_barcodes_relationship_type_id_idx ON public.product_barcodes USING btree (relationship_type_id);


--
-- Name: product_barcodes_source_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_barcodes_source_id_idx ON public.product_barcodes USING btree (source_id);


--
-- Name: product_barcodes_status_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_barcodes_status_id_idx ON public.product_barcodes USING btree (status_id);


--
-- Name: product_categories_history_change_set_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_categories_history_change_set_id_idx ON public.product_categories_history USING btree (change_set_id);


--
-- Name: product_categories_history_original_entity_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_categories_history_original_entity_id_idx ON public.product_categories_history USING btree (original_entity_id);


--
-- Name: product_categories_history_parent_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_categories_history_parent_id_idx ON public.product_categories_history USING btree (parent_id);


--
-- Name: product_categories_history_previous_version_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_categories_history_previous_version_id_idx ON public.product_categories_history USING btree (previous_version_id);


--
-- Name: product_categories_history_source_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_categories_history_source_id_idx ON public.product_categories_history USING btree (source_id);


--
-- Name: product_categories_history_status_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_categories_history_status_id_idx ON public.product_categories_history USING btree (status_id);


--
-- Name: product_categories_parent_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_categories_parent_id_idx ON public.product_categories USING btree (parent_id);


--
-- Name: product_categories_status_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_categories_status_id_idx ON public.product_categories USING btree (status_id);


--
-- Name: product_category_translations_language_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_category_translations_language_id_idx ON public.product_category_translations USING btree (language_id);


--
-- Name: product_category_translations_product_category_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_category_translations_product_category_id_idx ON public.product_category_translations USING btree (product_category_id);


--
-- Name: product_health_flags_evidence_type_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_health_flags_evidence_type_id_idx ON public.product_health_flags USING btree (evidence_type_id);


--
-- Name: product_health_flags_health_flag_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_health_flags_health_flag_id_idx ON public.product_health_flags USING btree (health_flag_id);


--
-- Name: product_health_flags_product_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_health_flags_product_id_idx ON public.product_health_flags USING btree (product_id);


--
-- Name: product_health_flags_relationship_type_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_health_flags_relationship_type_id_idx ON public.product_health_flags USING btree (relationship_type_id);


--
-- Name: product_health_flags_source_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_health_flags_source_id_idx ON public.product_health_flags USING btree (source_id);


--
-- Name: product_health_flags_status_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_health_flags_status_id_idx ON public.product_health_flags USING btree (status_id);


--
-- Name: product_images_evidence_type_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_images_evidence_type_id_idx ON public.product_images USING btree (evidence_type_id);


--
-- Name: product_images_history_change_set_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_images_history_change_set_id_idx ON public.product_images_history USING btree (change_set_id);


--
-- Name: product_images_history_evidence_type_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_images_history_evidence_type_id_idx ON public.product_images_history USING btree (evidence_type_id);


--
-- Name: product_images_history_image_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_images_history_image_id_idx ON public.product_images_history USING btree (image_id);


--
-- Name: product_images_history_original_entity_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_images_history_original_entity_id_idx ON public.product_images_history USING btree (original_entity_id);


--
-- Name: product_images_history_previous_version_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_images_history_previous_version_id_idx ON public.product_images_history USING btree (previous_version_id);


--
-- Name: product_images_history_product_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_images_history_product_id_idx ON public.product_images_history USING btree (product_id);


--
-- Name: product_images_history_relationship_type_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_images_history_relationship_type_id_idx ON public.product_images_history USING btree (relationship_type_id);


--
-- Name: product_images_history_source_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_images_history_source_id_idx ON public.product_images_history USING btree (source_id);


--
-- Name: product_images_history_status_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_images_history_status_id_idx ON public.product_images_history USING btree (status_id);


--
-- Name: product_images_image_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_images_image_id_idx ON public.product_images USING btree (image_id);


--
-- Name: product_images_product_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_images_product_id_idx ON public.product_images USING btree (product_id);


--
-- Name: product_images_relationship_type_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_images_relationship_type_id_idx ON public.product_images USING btree (relationship_type_id);


--
-- Name: product_images_source_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_images_source_id_idx ON public.product_images USING btree (source_id);


--
-- Name: product_images_status_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_images_status_id_idx ON public.product_images USING btree (status_id);


--
-- Name: product_ingredients_evidence_type_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_ingredients_evidence_type_id_idx ON public.product_ingredients USING btree (evidence_type_id);


--
-- Name: product_ingredients_ingredient_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_ingredients_ingredient_id_idx ON public.product_ingredients USING btree (ingredient_id);


--
-- Name: product_ingredients_product_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_ingredients_product_id_idx ON public.product_ingredients USING btree (product_id);


--
-- Name: product_ingredients_relationship_type_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_ingredients_relationship_type_id_idx ON public.product_ingredients USING btree (relationship_type_id);


--
-- Name: product_ingredients_source_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_ingredients_source_id_idx ON public.product_ingredients USING btree (source_id);


--
-- Name: product_ingredients_status_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_ingredients_status_id_idx ON public.product_ingredients USING btree (status_id);


--
-- Name: product_ingredients_unit_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_ingredients_unit_id_idx ON public.product_ingredients USING btree (unit_id);


--
-- Name: product_nutrition_values_evidence_type_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_nutrition_values_evidence_type_id_idx ON public.product_nutrition_values USING btree (evidence_type_id);


--
-- Name: product_nutrition_values_measurement_basis_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_nutrition_values_measurement_basis_id_idx ON public.product_nutrition_values USING btree (measurement_basis_id);


--
-- Name: product_nutrition_values_nutrition_type_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_nutrition_values_nutrition_type_id_idx ON public.product_nutrition_values USING btree (nutrition_type_id);


--
-- Name: product_nutrition_values_product_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_nutrition_values_product_id_idx ON public.product_nutrition_values USING btree (product_id);


--
-- Name: product_nutrition_values_relationship_type_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_nutrition_values_relationship_type_id_idx ON public.product_nutrition_values USING btree (relationship_type_id);


--
-- Name: product_nutrition_values_source_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_nutrition_values_source_id_idx ON public.product_nutrition_values USING btree (source_id);


--
-- Name: product_nutrition_values_status_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_nutrition_values_status_id_idx ON public.product_nutrition_values USING btree (status_id);


--
-- Name: product_nutrition_values_unit_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_nutrition_values_unit_id_idx ON public.product_nutrition_values USING btree (unit_id);


--
-- Name: product_search_index_search_name_trgm_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_search_index_search_name_trgm_idx ON public.product_search_index USING gin (search_name public.gin_trgm_ops);


--
-- Name: product_search_index_search_rank_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_search_index_search_rank_idx ON public.product_search_index USING btree (search_rank DESC);


--
-- Name: product_search_index_search_text_trgm_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_search_index_search_text_trgm_idx ON public.product_search_index USING gin (search_text public.gin_trgm_ops);


--
-- Name: product_search_index_search_tokens_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_search_index_search_tokens_idx ON public.product_search_index USING gin (search_tokens);


--
-- Name: product_translations_language_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_translations_language_id_idx ON public.product_translations USING btree (language_id);


--
-- Name: product_translations_product_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_translations_product_id_idx ON public.product_translations USING btree (product_id);


--
-- Name: products_brand_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_brand_id_idx ON public.products USING btree (brand_id);


--
-- Name: products_history_brand_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_history_brand_id_idx ON public.products_history USING btree (brand_id);


--
-- Name: products_history_change_set_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_history_change_set_id_idx ON public.products_history USING btree (change_set_id);


--
-- Name: products_history_original_entity_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_history_original_entity_id_idx ON public.products_history USING btree (original_entity_id);


--
-- Name: products_history_previous_version_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_history_previous_version_id_idx ON public.products_history USING btree (previous_version_id);


--
-- Name: products_history_product_category_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_history_product_category_id_idx ON public.products_history USING btree (product_category_id);


--
-- Name: products_history_source_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_history_source_id_idx ON public.products_history USING btree (source_id);


--
-- Name: products_history_status_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_history_status_id_idx ON public.products_history USING btree (status_id);


--
-- Name: products_product_category_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_product_category_id_idx ON public.products USING btree (product_category_id);


--
-- Name: products_source_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_source_id_idx ON public.products USING btree (source_id);


--
-- Name: regions_status_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX regions_status_id_idx ON public.regions USING btree (status_id);


--
-- Name: regulatory_authorities_status_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX regulatory_authorities_status_id_idx ON public.regulatory_authorities USING btree (status_id);


--
-- Name: relationship_types_inverse_type_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX relationship_types_inverse_type_id_idx ON public.relationship_types USING btree (inverse_type_id) WHERE (inverse_type_id IS NOT NULL);


--
-- Name: relationship_types_status_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX relationship_types_status_id_idx ON public.relationship_types USING btree (status_id);


--
-- Name: role_types_status_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX role_types_status_id_idx ON public.role_types USING btree (status_id);


--
-- Name: source_priorities_status_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX source_priorities_status_id_idx ON public.source_priorities USING btree (status_id);


--
-- Name: source_types_status_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX source_types_status_id_idx ON public.source_types USING btree (status_id);


--
-- Name: units_one_base_unit_per_dimension_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX units_one_base_unit_per_dimension_idx ON public.units USING btree (dimension) WHERE is_base_unit;


--
-- Name: units_status_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX units_status_id_idx ON public.units USING btree (status_id);


--
-- Name: verification_statuses_status_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX verification_statuses_status_id_idx ON public.verification_statuses USING btree (status_id);


--
-- Name: version_metadata_entity_version_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX version_metadata_entity_version_id_idx ON public.version_metadata USING btree (entity_version_id);


--
-- Name: allergen_translations allergen_translations_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER allergen_translations_set_updated_at BEFORE UPDATE ON public.allergen_translations FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: allergen_types allergen_types_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER allergen_types_set_updated_at BEFORE UPDATE ON public.allergen_types FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: allergens allergens_capture_history; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER allergens_capture_history BEFORE INSERT OR UPDATE ON public.allergens FOR EACH ROW EXECUTE FUNCTION public.capture_entity_history();


--
-- Name: allergens_history allergens_history_prevent_mutation; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER allergens_history_prevent_mutation BEFORE DELETE OR UPDATE ON public.allergens_history FOR EACH ROW EXECUTE FUNCTION public.prevent_history_mutation();


--
-- Name: allergens allergens_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER allergens_set_updated_at BEFORE UPDATE ON public.allergens FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: audit_context audit_context_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER audit_context_set_updated_at BEFORE UPDATE ON public.audit_context FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: audit_event_types audit_event_types_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER audit_event_types_set_updated_at BEFORE UPDATE ON public.audit_event_types FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: audit_events audit_events_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER audit_events_set_updated_at BEFORE UPDATE ON public.audit_events FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: audit_log audit_log_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER audit_log_set_updated_at BEFORE UPDATE ON public.audit_log FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: barcode_types barcode_types_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER barcode_types_set_updated_at BEFORE UPDATE ON public.barcode_types FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: barcodes barcodes_capture_history; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER barcodes_capture_history BEFORE INSERT OR UPDATE ON public.barcodes FOR EACH ROW EXECUTE FUNCTION public.capture_entity_history();


--
-- Name: barcodes_history barcodes_history_prevent_mutation; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER barcodes_history_prevent_mutation BEFORE DELETE OR UPDATE ON public.barcodes_history FOR EACH ROW EXECUTE FUNCTION public.prevent_history_mutation();


--
-- Name: barcodes barcodes_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER barcodes_set_updated_at BEFORE UPDATE ON public.barcodes FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: brand_translations brand_translations_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER brand_translations_set_updated_at BEFORE UPDATE ON public.brand_translations FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: brands brands_capture_history; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER brands_capture_history AFTER INSERT OR UPDATE ON public.brands DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.capture_entity_history();


--
-- Name: brands_history brands_history_prevent_mutation; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER brands_history_prevent_mutation BEFORE DELETE OR UPDATE ON public.brands_history FOR EACH ROW EXECUTE FUNCTION public.prevent_history_mutation();


--
-- Name: brands brands_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER brands_set_updated_at BEFORE UPDATE ON public.brands FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: change_sets change_sets_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER change_sets_set_updated_at BEFORE UPDATE ON public.change_sets FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: companies companies_capture_history; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER companies_capture_history BEFORE INSERT OR UPDATE ON public.companies FOR EACH ROW EXECUTE FUNCTION public.capture_entity_history();


--
-- Name: companies_history companies_history_prevent_mutation; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER companies_history_prevent_mutation BEFORE DELETE OR UPDATE ON public.companies_history FOR EACH ROW EXECUTE FUNCTION public.prevent_history_mutation();


--
-- Name: companies companies_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER companies_set_updated_at BEFORE UPDATE ON public.companies FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: company_translations company_translations_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER company_translations_set_updated_at BEFORE UPDATE ON public.company_translations FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: countries countries_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER countries_set_updated_at BEFORE UPDATE ON public.countries FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: data_sources data_sources_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER data_sources_set_updated_at BEFORE UPDATE ON public.data_sources FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: entity_relationships entity_relationships_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER entity_relationships_set_updated_at BEFORE UPDATE ON public.entity_relationships FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: entity_relationships entity_relationships_validate_endpoints; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER entity_relationships_validate_endpoints BEFORE INSERT OR UPDATE ON public.entity_relationships FOR EACH ROW EXECUTE FUNCTION public.validate_entity_relationship_endpoints();


--
-- Name: entity_versions entity_versions_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER entity_versions_set_updated_at BEFORE UPDATE ON public.entity_versions FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: evidence_types evidence_types_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER evidence_types_set_updated_at BEFORE UPDATE ON public.evidence_types FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: health_flag_translations health_flag_translations_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER health_flag_translations_set_updated_at BEFORE UPDATE ON public.health_flag_translations FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: health_flag_types health_flag_types_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER health_flag_types_set_updated_at BEFORE UPDATE ON public.health_flag_types FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: health_flags health_flags_capture_history; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER health_flags_capture_history BEFORE INSERT OR UPDATE ON public.health_flags FOR EACH ROW EXECUTE FUNCTION public.capture_entity_history();


--
-- Name: health_flags_history health_flags_history_prevent_mutation; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER health_flags_history_prevent_mutation BEFORE DELETE OR UPDATE ON public.health_flags_history FOR EACH ROW EXECUTE FUNCTION public.prevent_history_mutation();


--
-- Name: health_flags health_flags_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER health_flags_set_updated_at BEFORE UPDATE ON public.health_flags FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: image_types image_types_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER image_types_set_updated_at BEFORE UPDATE ON public.image_types FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: images images_capture_history; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER images_capture_history BEFORE INSERT OR UPDATE ON public.images FOR EACH ROW EXECUTE FUNCTION public.capture_entity_history();


--
-- Name: images_history images_history_prevent_mutation; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER images_history_prevent_mutation BEFORE DELETE OR UPDATE ON public.images_history FOR EACH ROW EXECUTE FUNCTION public.prevent_history_mutation();


--
-- Name: images images_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER images_set_updated_at BEFORE UPDATE ON public.images FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: ingredient_aliases ingredient_aliases_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER ingredient_aliases_set_updated_at BEFORE UPDATE ON public.ingredient_aliases FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: ingredient_allergens ingredient_allergens_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER ingredient_allergens_set_updated_at BEFORE UPDATE ON public.ingredient_allergens FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: ingredient_categories ingredient_categories_capture_history; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER ingredient_categories_capture_history BEFORE INSERT OR UPDATE ON public.ingredient_categories FOR EACH ROW EXECUTE FUNCTION public.capture_entity_history();


--
-- Name: ingredient_categories_history ingredient_categories_history_prevent_mutation; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER ingredient_categories_history_prevent_mutation BEFORE DELETE OR UPDATE ON public.ingredient_categories_history FOR EACH ROW EXECUTE FUNCTION public.prevent_history_mutation();


--
-- Name: ingredient_categories ingredient_categories_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER ingredient_categories_set_updated_at BEFORE UPDATE ON public.ingredient_categories FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: ingredient_health_flags ingredient_health_flags_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER ingredient_health_flags_set_updated_at BEFORE UPDATE ON public.ingredient_health_flags FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: ingredient_translations ingredient_translations_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER ingredient_translations_set_updated_at BEFORE UPDATE ON public.ingredient_translations FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: ingredients ingredients_capture_history; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER ingredients_capture_history BEFORE INSERT OR UPDATE ON public.ingredients FOR EACH ROW EXECUTE FUNCTION public.capture_entity_history();


--
-- Name: ingredients_history ingredients_history_prevent_mutation; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER ingredients_history_prevent_mutation BEFORE DELETE OR UPDATE ON public.ingredients_history FOR EACH ROW EXECUTE FUNCTION public.prevent_history_mutation();


--
-- Name: ingredients ingredients_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER ingredients_set_updated_at BEFORE UPDATE ON public.ingredients FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: languages languages_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER languages_set_updated_at BEFORE UPDATE ON public.languages FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: lifecycle_statuses lifecycle_statuses_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER lifecycle_statuses_set_updated_at BEFORE UPDATE ON public.lifecycle_statuses FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: measurement_bases measurement_bases_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER measurement_bases_set_updated_at BEFORE UPDATE ON public.measurement_bases FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: nutrition_type_translations nutrition_type_translations_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER nutrition_type_translations_set_updated_at BEFORE UPDATE ON public.nutrition_type_translations FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: nutrition_types nutrition_types_capture_history; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER nutrition_types_capture_history BEFORE INSERT OR UPDATE ON public.nutrition_types FOR EACH ROW EXECUTE FUNCTION public.capture_entity_history();


--
-- Name: nutrition_types_history nutrition_types_history_prevent_mutation; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER nutrition_types_history_prevent_mutation BEFORE DELETE OR UPDATE ON public.nutrition_types_history FOR EACH ROW EXECUTE FUNCTION public.prevent_history_mutation();


--
-- Name: nutrition_types nutrition_types_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER nutrition_types_set_updated_at BEFORE UPDATE ON public.nutrition_types FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: package_types package_types_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER package_types_set_updated_at BEFORE UPDATE ON public.package_types FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: permission_types permission_types_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER permission_types_set_updated_at BEFORE UPDATE ON public.permission_types FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: product_allergens product_allergens_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER product_allergens_set_updated_at BEFORE UPDATE ON public.product_allergens FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: product_barcodes product_barcodes_capture_history; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER product_barcodes_capture_history BEFORE INSERT OR UPDATE ON public.product_barcodes FOR EACH ROW EXECUTE FUNCTION public.capture_entity_history();


--
-- Name: product_barcodes_history product_barcodes_history_prevent_mutation; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER product_barcodes_history_prevent_mutation BEFORE DELETE OR UPDATE ON public.product_barcodes_history FOR EACH ROW EXECUTE FUNCTION public.prevent_history_mutation();


--
-- Name: product_barcodes product_barcodes_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER product_barcodes_set_updated_at BEFORE UPDATE ON public.product_barcodes FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: product_categories product_categories_capture_history; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER product_categories_capture_history BEFORE INSERT OR UPDATE ON public.product_categories FOR EACH ROW EXECUTE FUNCTION public.capture_entity_history();


--
-- Name: product_categories_history product_categories_history_prevent_mutation; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER product_categories_history_prevent_mutation BEFORE DELETE OR UPDATE ON public.product_categories_history FOR EACH ROW EXECUTE FUNCTION public.prevent_history_mutation();


--
-- Name: product_categories product_categories_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER product_categories_set_updated_at BEFORE UPDATE ON public.product_categories FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: product_category_translations product_category_translations_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER product_category_translations_set_updated_at BEFORE UPDATE ON public.product_category_translations FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: product_health_flags product_health_flags_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER product_health_flags_set_updated_at BEFORE UPDATE ON public.product_health_flags FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: product_images product_images_capture_history; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER product_images_capture_history BEFORE INSERT OR UPDATE ON public.product_images FOR EACH ROW EXECUTE FUNCTION public.capture_entity_history();


--
-- Name: product_images_history product_images_history_prevent_mutation; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER product_images_history_prevent_mutation BEFORE DELETE OR UPDATE ON public.product_images_history FOR EACH ROW EXECUTE FUNCTION public.prevent_history_mutation();


--
-- Name: product_images product_images_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER product_images_set_updated_at BEFORE UPDATE ON public.product_images FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: product_ingredients product_ingredients_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER product_ingredients_set_updated_at BEFORE UPDATE ON public.product_ingredients FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: product_nutrition_values product_nutrition_values_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER product_nutrition_values_set_updated_at BEFORE UPDATE ON public.product_nutrition_values FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: product_translations product_translations_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER product_translations_set_updated_at BEFORE UPDATE ON public.product_translations FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: products products_capture_history; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER products_capture_history BEFORE INSERT OR UPDATE ON public.products FOR EACH ROW EXECUTE FUNCTION public.capture_entity_history();


--
-- Name: products_history products_history_prevent_mutation; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER products_history_prevent_mutation BEFORE DELETE OR UPDATE ON public.products_history FOR EACH ROW EXECUTE FUNCTION public.prevent_history_mutation();


--
-- Name: products products_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER products_set_updated_at BEFORE UPDATE ON public.products FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: regions regions_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER regions_set_updated_at BEFORE UPDATE ON public.regions FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: regulatory_authorities regulatory_authorities_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER regulatory_authorities_set_updated_at BEFORE UPDATE ON public.regulatory_authorities FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: relationship_types relationship_types_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER relationship_types_set_updated_at BEFORE UPDATE ON public.relationship_types FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: role_types role_types_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER role_types_set_updated_at BEFORE UPDATE ON public.role_types FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: source_priorities source_priorities_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER source_priorities_set_updated_at BEFORE UPDATE ON public.source_priorities FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: source_types source_types_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER source_types_set_updated_at BEFORE UPDATE ON public.source_types FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: units units_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER units_set_updated_at BEFORE UPDATE ON public.units FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: verification_statuses verification_statuses_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER verification_statuses_set_updated_at BEFORE UPDATE ON public.verification_statuses FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: version_metadata version_metadata_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER version_metadata_set_updated_at BEFORE UPDATE ON public.version_metadata FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: allergen_translations allergen_translations_allergen_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allergen_translations
    ADD CONSTRAINT allergen_translations_allergen_id_fk FOREIGN KEY (allergen_id) REFERENCES public.allergens(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: allergen_translations allergen_translations_language_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allergen_translations
    ADD CONSTRAINT allergen_translations_language_id_fk FOREIGN KEY (language_id) REFERENCES public.languages(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: allergen_types allergen_types_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allergen_types
    ADD CONSTRAINT allergen_types_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: allergens allergens_allergen_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allergens
    ADD CONSTRAINT allergens_allergen_type_id_fk FOREIGN KEY (allergen_type_id) REFERENCES public.allergen_types(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: allergens_history allergens_history_allergen_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allergens_history
    ADD CONSTRAINT allergens_history_allergen_type_id_fk FOREIGN KEY (allergen_type_id) REFERENCES public.allergen_types(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: allergens_history allergens_history_change_set_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allergens_history
    ADD CONSTRAINT allergens_history_change_set_id_fk FOREIGN KEY (change_set_id) REFERENCES public.change_sets(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: allergens_history allergens_history_original_entity_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allergens_history
    ADD CONSTRAINT allergens_history_original_entity_id_fk FOREIGN KEY (original_entity_id) REFERENCES public.allergens(id) ON UPDATE RESTRICT ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: allergens_history allergens_history_previous_version_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allergens_history
    ADD CONSTRAINT allergens_history_previous_version_id_fk FOREIGN KEY (previous_version_id) REFERENCES public.allergens_history(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: allergens_history allergens_history_source_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allergens_history
    ADD CONSTRAINT allergens_history_source_id_fk FOREIGN KEY (source_id) REFERENCES public.data_sources(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: allergens_history allergens_history_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allergens_history
    ADD CONSTRAINT allergens_history_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: allergens allergens_source_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allergens
    ADD CONSTRAINT allergens_source_id_fk FOREIGN KEY (source_id) REFERENCES public.data_sources(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: allergens allergens_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allergens
    ADD CONSTRAINT allergens_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: audit_context audit_context_role_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_context
    ADD CONSTRAINT audit_context_role_id_fk FOREIGN KEY (role_id) REFERENCES public.role_types(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: audit_event_types audit_event_types_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_event_types
    ADD CONSTRAINT audit_event_types_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: audit_events audit_events_audit_log_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_events
    ADD CONSTRAINT audit_events_audit_log_id_fk FOREIGN KEY (audit_log_id) REFERENCES public.audit_log(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: audit_events audit_events_event_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_events
    ADD CONSTRAINT audit_events_event_type_id_fk FOREIGN KEY (event_type_id) REFERENCES public.audit_event_types(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: audit_log audit_log_change_set_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_change_set_id_fk FOREIGN KEY (change_set_id) REFERENCES public.change_sets(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: audit_log audit_log_event_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_event_type_id_fk FOREIGN KEY (event_type_id) REFERENCES public.audit_event_types(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: audit_log audit_log_role_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_role_id_fk FOREIGN KEY (role_id) REFERENCES public.role_types(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: barcode_types barcode_types_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.barcode_types
    ADD CONSTRAINT barcode_types_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: barcodes barcodes_barcode_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.barcodes
    ADD CONSTRAINT barcodes_barcode_type_id_fk FOREIGN KEY (barcode_type_id) REFERENCES public.barcode_types(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: barcodes_history barcodes_history_barcode_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.barcodes_history
    ADD CONSTRAINT barcodes_history_barcode_type_id_fk FOREIGN KEY (barcode_type_id) REFERENCES public.barcode_types(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: barcodes_history barcodes_history_change_set_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.barcodes_history
    ADD CONSTRAINT barcodes_history_change_set_id_fk FOREIGN KEY (change_set_id) REFERENCES public.change_sets(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: barcodes_history barcodes_history_issued_country_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.barcodes_history
    ADD CONSTRAINT barcodes_history_issued_country_id_fk FOREIGN KEY (issued_country_id) REFERENCES public.countries(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: barcodes_history barcodes_history_original_entity_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.barcodes_history
    ADD CONSTRAINT barcodes_history_original_entity_id_fk FOREIGN KEY (original_entity_id) REFERENCES public.barcodes(id) ON UPDATE RESTRICT ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: barcodes_history barcodes_history_previous_version_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.barcodes_history
    ADD CONSTRAINT barcodes_history_previous_version_id_fk FOREIGN KEY (previous_version_id) REFERENCES public.barcodes_history(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: barcodes_history barcodes_history_source_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.barcodes_history
    ADD CONSTRAINT barcodes_history_source_id_fk FOREIGN KEY (source_id) REFERENCES public.data_sources(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: barcodes_history barcodes_history_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.barcodes_history
    ADD CONSTRAINT barcodes_history_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: barcodes_history barcodes_history_verification_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.barcodes_history
    ADD CONSTRAINT barcodes_history_verification_status_id_fk FOREIGN KEY (verification_status_id) REFERENCES public.verification_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: barcodes barcodes_issued_country_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.barcodes
    ADD CONSTRAINT barcodes_issued_country_id_fk FOREIGN KEY (issued_country_id) REFERENCES public.countries(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: barcodes barcodes_source_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.barcodes
    ADD CONSTRAINT barcodes_source_id_fk FOREIGN KEY (source_id) REFERENCES public.data_sources(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: barcodes barcodes_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.barcodes
    ADD CONSTRAINT barcodes_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: barcodes barcodes_verification_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.barcodes
    ADD CONSTRAINT barcodes_verification_status_id_fk FOREIGN KEY (verification_status_id) REFERENCES public.verification_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: brand_translations brand_translations_brand_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.brand_translations
    ADD CONSTRAINT brand_translations_brand_id_fk FOREIGN KEY (brand_id) REFERENCES public.brands(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: brand_translations brand_translations_language_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.brand_translations
    ADD CONSTRAINT brand_translations_language_id_fk FOREIGN KEY (language_id) REFERENCES public.languages(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: brands brands_company_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.brands
    ADD CONSTRAINT brands_company_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: brands_history brands_history_change_set_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.brands_history
    ADD CONSTRAINT brands_history_change_set_id_fk FOREIGN KEY (change_set_id) REFERENCES public.change_sets(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: brands_history brands_history_company_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.brands_history
    ADD CONSTRAINT brands_history_company_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: brands_history brands_history_original_entity_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.brands_history
    ADD CONSTRAINT brands_history_original_entity_id_fk FOREIGN KEY (original_entity_id) REFERENCES public.brands(id) ON UPDATE RESTRICT ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: brands_history brands_history_previous_version_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.brands_history
    ADD CONSTRAINT brands_history_previous_version_id_fk FOREIGN KEY (previous_version_id) REFERENCES public.brands_history(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: brands_history brands_history_source_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.brands_history
    ADD CONSTRAINT brands_history_source_id_fk FOREIGN KEY (source_id) REFERENCES public.data_sources(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: brands_history brands_history_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.brands_history
    ADD CONSTRAINT brands_history_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: brands brands_source_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.brands
    ADD CONSTRAINT brands_source_id_fk FOREIGN KEY (source_id) REFERENCES public.data_sources(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: brands brands_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.brands
    ADD CONSTRAINT brands_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: change_sets change_sets_audit_context_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.change_sets
    ADD CONSTRAINT change_sets_audit_context_fk FOREIGN KEY (correlation_id, transaction_id) REFERENCES public.audit_context(correlation_id, transaction_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: companies_history companies_history_change_set_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.companies_history
    ADD CONSTRAINT companies_history_change_set_id_fk FOREIGN KEY (change_set_id) REFERENCES public.change_sets(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: companies_history companies_history_original_entity_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.companies_history
    ADD CONSTRAINT companies_history_original_entity_id_fk FOREIGN KEY (original_entity_id) REFERENCES public.companies(id) ON UPDATE RESTRICT ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: companies_history companies_history_previous_version_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.companies_history
    ADD CONSTRAINT companies_history_previous_version_id_fk FOREIGN KEY (previous_version_id) REFERENCES public.companies_history(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: companies_history companies_history_source_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.companies_history
    ADD CONSTRAINT companies_history_source_id_fk FOREIGN KEY (source_id) REFERENCES public.data_sources(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: companies_history companies_history_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.companies_history
    ADD CONSTRAINT companies_history_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: companies companies_source_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_source_id_fk FOREIGN KEY (source_id) REFERENCES public.data_sources(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: companies companies_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: company_translations company_translations_company_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_translations
    ADD CONSTRAINT company_translations_company_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: company_translations company_translations_language_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_translations
    ADD CONSTRAINT company_translations_language_id_fk FOREIGN KEY (language_id) REFERENCES public.languages(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: condition_nutrition_rules condition_nutrition_rules_condition_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.condition_nutrition_rules
    ADD CONSTRAINT condition_nutrition_rules_condition_id_fkey FOREIGN KEY (condition_id) REFERENCES public.health_conditions(id);


--
-- Name: countries countries_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.countries
    ADD CONSTRAINT countries_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: coverage_snapshots coverage_snapshots_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coverage_snapshots
    ADD CONSTRAINT coverage_snapshots_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: coverage_snapshots coverage_snapshots_scan_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coverage_snapshots
    ADD CONSTRAINT coverage_snapshots_scan_job_id_fkey FOREIGN KEY (scan_job_id) REFERENCES public.scan_jobs(id);


--
-- Name: data_sources data_sources_country_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.data_sources
    ADD CONSTRAINT data_sources_country_id_fk FOREIGN KEY (country_id) REFERENCES public.countries(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: data_sources data_sources_priority_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.data_sources
    ADD CONSTRAINT data_sources_priority_id_fk FOREIGN KEY (priority_id) REFERENCES public.source_priorities(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: data_sources data_sources_source_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.data_sources
    ADD CONSTRAINT data_sources_source_type_id_fk FOREIGN KEY (source_type_id) REFERENCES public.source_types(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: data_sources data_sources_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.data_sources
    ADD CONSTRAINT data_sources_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: discovery_candidates discovery_candidates_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discovery_candidates
    ADD CONSTRAINT discovery_candidates_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: discovery_candidates discovery_candidates_matched_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discovery_candidates
    ADD CONSTRAINT discovery_candidates_matched_product_id_fkey FOREIGN KEY (matched_product_id) REFERENCES public.products(id);


--
-- Name: entity_relationships entity_relationships_evidence_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entity_relationships
    ADD CONSTRAINT entity_relationships_evidence_type_id_fk FOREIGN KEY (evidence_type_id) REFERENCES public.evidence_types(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: entity_relationships entity_relationships_relationship_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entity_relationships
    ADD CONSTRAINT entity_relationships_relationship_type_id_fk FOREIGN KEY (relationship_type_id) REFERENCES public.relationship_types(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: entity_relationships entity_relationships_source_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entity_relationships
    ADD CONSTRAINT entity_relationships_source_id_fk FOREIGN KEY (source_id) REFERENCES public.data_sources(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: entity_relationships entity_relationships_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entity_relationships
    ADD CONSTRAINT entity_relationships_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: entity_versions entity_versions_change_set_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entity_versions
    ADD CONSTRAINT entity_versions_change_set_id_fk FOREIGN KEY (change_set_id) REFERENCES public.change_sets(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: entity_versions entity_versions_previous_version_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entity_versions
    ADD CONSTRAINT entity_versions_previous_version_id_fk FOREIGN KEY (previous_version_id) REFERENCES public.entity_versions(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: evidence_types evidence_types_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evidence_types
    ADD CONSTRAINT evidence_types_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: halal_evidence halal_evidence_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.halal_evidence
    ADD CONSTRAINT halal_evidence_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: health_flag_translations health_flag_translations_health_flag_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_flag_translations
    ADD CONSTRAINT health_flag_translations_health_flag_id_fk FOREIGN KEY (health_flag_id) REFERENCES public.health_flags(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: health_flag_translations health_flag_translations_language_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_flag_translations
    ADD CONSTRAINT health_flag_translations_language_id_fk FOREIGN KEY (language_id) REFERENCES public.languages(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: health_flag_types health_flag_types_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_flag_types
    ADD CONSTRAINT health_flag_types_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: health_flags health_flags_health_flag_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_flags
    ADD CONSTRAINT health_flags_health_flag_type_id_fk FOREIGN KEY (health_flag_type_id) REFERENCES public.health_flag_types(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: health_flags_history health_flags_history_change_set_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_flags_history
    ADD CONSTRAINT health_flags_history_change_set_id_fk FOREIGN KEY (change_set_id) REFERENCES public.change_sets(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: health_flags_history health_flags_history_health_flag_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_flags_history
    ADD CONSTRAINT health_flags_history_health_flag_type_id_fk FOREIGN KEY (health_flag_type_id) REFERENCES public.health_flag_types(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: health_flags_history health_flags_history_original_entity_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_flags_history
    ADD CONSTRAINT health_flags_history_original_entity_id_fk FOREIGN KEY (original_entity_id) REFERENCES public.health_flags(id) ON UPDATE RESTRICT ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: health_flags_history health_flags_history_previous_version_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_flags_history
    ADD CONSTRAINT health_flags_history_previous_version_id_fk FOREIGN KEY (previous_version_id) REFERENCES public.health_flags_history(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: health_flags_history health_flags_history_source_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_flags_history
    ADD CONSTRAINT health_flags_history_source_id_fk FOREIGN KEY (source_id) REFERENCES public.data_sources(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: health_flags_history health_flags_history_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_flags_history
    ADD CONSTRAINT health_flags_history_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: health_flags health_flags_source_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_flags
    ADD CONSTRAINT health_flags_source_id_fk FOREIGN KEY (source_id) REFERENCES public.data_sources(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: health_flags health_flags_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.health_flags
    ADD CONSTRAINT health_flags_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: image_types image_types_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.image_types
    ADD CONSTRAINT image_types_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: images_history images_history_change_set_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.images_history
    ADD CONSTRAINT images_history_change_set_id_fk FOREIGN KEY (change_set_id) REFERENCES public.change_sets(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: images_history images_history_image_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.images_history
    ADD CONSTRAINT images_history_image_type_id_fk FOREIGN KEY (image_type_id) REFERENCES public.image_types(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: images_history images_history_language_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.images_history
    ADD CONSTRAINT images_history_language_id_fk FOREIGN KEY (language_id) REFERENCES public.languages(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: images_history images_history_original_entity_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.images_history
    ADD CONSTRAINT images_history_original_entity_id_fk FOREIGN KEY (original_entity_id) REFERENCES public.images(id) ON UPDATE RESTRICT ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: images_history images_history_previous_version_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.images_history
    ADD CONSTRAINT images_history_previous_version_id_fk FOREIGN KEY (previous_version_id) REFERENCES public.images_history(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: images_history images_history_source_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.images_history
    ADD CONSTRAINT images_history_source_id_fk FOREIGN KEY (source_id) REFERENCES public.data_sources(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: images_history images_history_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.images_history
    ADD CONSTRAINT images_history_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: images images_image_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.images
    ADD CONSTRAINT images_image_type_id_fk FOREIGN KEY (image_type_id) REFERENCES public.image_types(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: images images_language_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.images
    ADD CONSTRAINT images_language_id_fk FOREIGN KEY (language_id) REFERENCES public.languages(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: images images_source_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.images
    ADD CONSTRAINT images_source_id_fk FOREIGN KEY (source_id) REFERENCES public.data_sources(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: images images_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.images
    ADD CONSTRAINT images_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: ingredient_aliases ingredient_aliases_evidence_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_aliases
    ADD CONSTRAINT ingredient_aliases_evidence_type_id_fk FOREIGN KEY (evidence_type_id) REFERENCES public.evidence_types(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: ingredient_aliases ingredient_aliases_ingredient_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_aliases
    ADD CONSTRAINT ingredient_aliases_ingredient_id_fk FOREIGN KEY (ingredient_id) REFERENCES public.ingredients(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: ingredient_aliases ingredient_aliases_language_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_aliases
    ADD CONSTRAINT ingredient_aliases_language_id_fk FOREIGN KEY (language_id) REFERENCES public.languages(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: ingredient_aliases ingredient_aliases_relationship_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_aliases
    ADD CONSTRAINT ingredient_aliases_relationship_type_id_fk FOREIGN KEY (relationship_type_id) REFERENCES public.relationship_types(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: ingredient_aliases ingredient_aliases_source_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_aliases
    ADD CONSTRAINT ingredient_aliases_source_id_fk FOREIGN KEY (source_id) REFERENCES public.data_sources(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: ingredient_aliases ingredient_aliases_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_aliases
    ADD CONSTRAINT ingredient_aliases_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: ingredient_allergens ingredient_allergens_allergen_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_allergens
    ADD CONSTRAINT ingredient_allergens_allergen_id_fk FOREIGN KEY (allergen_id) REFERENCES public.allergens(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: ingredient_allergens ingredient_allergens_evidence_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_allergens
    ADD CONSTRAINT ingredient_allergens_evidence_type_id_fk FOREIGN KEY (evidence_type_id) REFERENCES public.evidence_types(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: ingredient_allergens ingredient_allergens_ingredient_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_allergens
    ADD CONSTRAINT ingredient_allergens_ingredient_id_fk FOREIGN KEY (ingredient_id) REFERENCES public.ingredients(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: ingredient_allergens ingredient_allergens_relationship_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_allergens
    ADD CONSTRAINT ingredient_allergens_relationship_type_id_fk FOREIGN KEY (relationship_type_id) REFERENCES public.relationship_types(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: ingredient_allergens ingredient_allergens_source_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_allergens
    ADD CONSTRAINT ingredient_allergens_source_id_fk FOREIGN KEY (source_id) REFERENCES public.data_sources(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: ingredient_allergens ingredient_allergens_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_allergens
    ADD CONSTRAINT ingredient_allergens_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: ingredient_categories_history ingredient_categories_history_change_set_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_categories_history
    ADD CONSTRAINT ingredient_categories_history_change_set_id_fk FOREIGN KEY (change_set_id) REFERENCES public.change_sets(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: ingredient_categories_history ingredient_categories_history_original_entity_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_categories_history
    ADD CONSTRAINT ingredient_categories_history_original_entity_id_fk FOREIGN KEY (original_entity_id) REFERENCES public.ingredient_categories(id) ON UPDATE RESTRICT ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ingredient_categories_history ingredient_categories_history_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_categories_history
    ADD CONSTRAINT ingredient_categories_history_parent_id_fk FOREIGN KEY (parent_id) REFERENCES public.ingredient_categories(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: ingredient_categories_history ingredient_categories_history_previous_version_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_categories_history
    ADD CONSTRAINT ingredient_categories_history_previous_version_id_fk FOREIGN KEY (previous_version_id) REFERENCES public.ingredient_categories_history(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: ingredient_categories_history ingredient_categories_history_source_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_categories_history
    ADD CONSTRAINT ingredient_categories_history_source_id_fk FOREIGN KEY (source_id) REFERENCES public.data_sources(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: ingredient_categories_history ingredient_categories_history_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_categories_history
    ADD CONSTRAINT ingredient_categories_history_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: ingredient_categories ingredient_categories_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_categories
    ADD CONSTRAINT ingredient_categories_parent_id_fk FOREIGN KEY (parent_id) REFERENCES public.ingredient_categories(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: ingredient_categories ingredient_categories_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_categories
    ADD CONSTRAINT ingredient_categories_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: ingredient_health_flags ingredient_health_flags_evidence_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_health_flags
    ADD CONSTRAINT ingredient_health_flags_evidence_type_id_fk FOREIGN KEY (evidence_type_id) REFERENCES public.evidence_types(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: ingredient_health_flags ingredient_health_flags_health_flag_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_health_flags
    ADD CONSTRAINT ingredient_health_flags_health_flag_id_fk FOREIGN KEY (health_flag_id) REFERENCES public.health_flags(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: ingredient_health_flags ingredient_health_flags_ingredient_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_health_flags
    ADD CONSTRAINT ingredient_health_flags_ingredient_id_fk FOREIGN KEY (ingredient_id) REFERENCES public.ingredients(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: ingredient_health_flags ingredient_health_flags_relationship_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_health_flags
    ADD CONSTRAINT ingredient_health_flags_relationship_type_id_fk FOREIGN KEY (relationship_type_id) REFERENCES public.relationship_types(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: ingredient_health_flags ingredient_health_flags_source_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_health_flags
    ADD CONSTRAINT ingredient_health_flags_source_id_fk FOREIGN KEY (source_id) REFERENCES public.data_sources(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: ingredient_health_flags ingredient_health_flags_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_health_flags
    ADD CONSTRAINT ingredient_health_flags_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: ingredient_translations ingredient_translations_ingredient_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_translations
    ADD CONSTRAINT ingredient_translations_ingredient_id_fk FOREIGN KEY (ingredient_id) REFERENCES public.ingredients(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: ingredient_translations ingredient_translations_language_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredient_translations
    ADD CONSTRAINT ingredient_translations_language_id_fk FOREIGN KEY (language_id) REFERENCES public.languages(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: ingredients_history ingredients_history_change_set_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredients_history
    ADD CONSTRAINT ingredients_history_change_set_id_fk FOREIGN KEY (change_set_id) REFERENCES public.change_sets(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: ingredients_history ingredients_history_original_entity_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredients_history
    ADD CONSTRAINT ingredients_history_original_entity_id_fk FOREIGN KEY (original_entity_id) REFERENCES public.ingredients(id) ON UPDATE RESTRICT ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ingredients_history ingredients_history_previous_version_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredients_history
    ADD CONSTRAINT ingredients_history_previous_version_id_fk FOREIGN KEY (previous_version_id) REFERENCES public.ingredients_history(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: ingredients_history ingredients_history_source_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredients_history
    ADD CONSTRAINT ingredients_history_source_id_fk FOREIGN KEY (source_id) REFERENCES public.data_sources(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: ingredients_history ingredients_history_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredients_history
    ADD CONSTRAINT ingredients_history_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: ingredients ingredients_source_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredients
    ADD CONSTRAINT ingredients_source_id_fk FOREIGN KEY (source_id) REFERENCES public.data_sources(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: ingredients ingredients_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredients
    ADD CONSTRAINT ingredients_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: languages languages_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.languages
    ADD CONSTRAINT languages_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: measurement_bases measurement_bases_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.measurement_bases
    ADD CONSTRAINT measurement_bases_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: nutrition_type_translations nutrition_type_translations_language_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nutrition_type_translations
    ADD CONSTRAINT nutrition_type_translations_language_id_fk FOREIGN KEY (language_id) REFERENCES public.languages(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: nutrition_type_translations nutrition_type_translations_nutrition_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nutrition_type_translations
    ADD CONSTRAINT nutrition_type_translations_nutrition_type_id_fk FOREIGN KEY (nutrition_type_id) REFERENCES public.nutrition_types(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: nutrition_types_history nutrition_types_history_change_set_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nutrition_types_history
    ADD CONSTRAINT nutrition_types_history_change_set_id_fk FOREIGN KEY (change_set_id) REFERENCES public.change_sets(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: nutrition_types_history nutrition_types_history_original_entity_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nutrition_types_history
    ADD CONSTRAINT nutrition_types_history_original_entity_id_fk FOREIGN KEY (original_entity_id) REFERENCES public.nutrition_types(id) ON UPDATE RESTRICT ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: nutrition_types_history nutrition_types_history_previous_version_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nutrition_types_history
    ADD CONSTRAINT nutrition_types_history_previous_version_id_fk FOREIGN KEY (previous_version_id) REFERENCES public.nutrition_types_history(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: nutrition_types_history nutrition_types_history_source_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nutrition_types_history
    ADD CONSTRAINT nutrition_types_history_source_id_fk FOREIGN KEY (source_id) REFERENCES public.data_sources(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: nutrition_types_history nutrition_types_history_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nutrition_types_history
    ADD CONSTRAINT nutrition_types_history_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: nutrition_types nutrition_types_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nutrition_types
    ADD CONSTRAINT nutrition_types_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: package_types package_types_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.package_types
    ADD CONSTRAINT package_types_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: permission_types permission_types_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permission_types
    ADD CONSTRAINT permission_types_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_allergens product_allergens_allergen_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_allergens
    ADD CONSTRAINT product_allergens_allergen_id_fk FOREIGN KEY (allergen_id) REFERENCES public.allergens(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_allergens product_allergens_evidence_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_allergens
    ADD CONSTRAINT product_allergens_evidence_type_id_fk FOREIGN KEY (evidence_type_id) REFERENCES public.evidence_types(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_allergens product_allergens_product_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_allergens
    ADD CONSTRAINT product_allergens_product_id_fk FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_allergens product_allergens_relationship_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_allergens
    ADD CONSTRAINT product_allergens_relationship_type_id_fk FOREIGN KEY (relationship_type_id) REFERENCES public.relationship_types(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_allergens product_allergens_source_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_allergens
    ADD CONSTRAINT product_allergens_source_id_fk FOREIGN KEY (source_id) REFERENCES public.data_sources(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_allergens product_allergens_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_allergens
    ADD CONSTRAINT product_allergens_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_barcodes product_barcodes_barcode_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_barcodes
    ADD CONSTRAINT product_barcodes_barcode_id_fk FOREIGN KEY (barcode_id) REFERENCES public.barcodes(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_barcodes product_barcodes_evidence_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_barcodes
    ADD CONSTRAINT product_barcodes_evidence_type_id_fk FOREIGN KEY (evidence_type_id) REFERENCES public.evidence_types(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_barcodes_history product_barcodes_history_barcode_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_barcodes_history
    ADD CONSTRAINT product_barcodes_history_barcode_id_fk FOREIGN KEY (barcode_id) REFERENCES public.barcodes(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_barcodes_history product_barcodes_history_change_set_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_barcodes_history
    ADD CONSTRAINT product_barcodes_history_change_set_id_fk FOREIGN KEY (change_set_id) REFERENCES public.change_sets(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_barcodes_history product_barcodes_history_evidence_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_barcodes_history
    ADD CONSTRAINT product_barcodes_history_evidence_type_id_fk FOREIGN KEY (evidence_type_id) REFERENCES public.evidence_types(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_barcodes_history product_barcodes_history_original_entity_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_barcodes_history
    ADD CONSTRAINT product_barcodes_history_original_entity_id_fk FOREIGN KEY (original_entity_id) REFERENCES public.product_barcodes(id) ON UPDATE RESTRICT ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_barcodes_history product_barcodes_history_previous_version_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_barcodes_history
    ADD CONSTRAINT product_barcodes_history_previous_version_id_fk FOREIGN KEY (previous_version_id) REFERENCES public.product_barcodes_history(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_barcodes_history product_barcodes_history_product_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_barcodes_history
    ADD CONSTRAINT product_barcodes_history_product_id_fk FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_barcodes_history product_barcodes_history_relationship_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_barcodes_history
    ADD CONSTRAINT product_barcodes_history_relationship_type_id_fk FOREIGN KEY (relationship_type_id) REFERENCES public.relationship_types(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_barcodes_history product_barcodes_history_source_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_barcodes_history
    ADD CONSTRAINT product_barcodes_history_source_id_fk FOREIGN KEY (source_id) REFERENCES public.data_sources(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_barcodes_history product_barcodes_history_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_barcodes_history
    ADD CONSTRAINT product_barcodes_history_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_barcodes product_barcodes_product_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_barcodes
    ADD CONSTRAINT product_barcodes_product_id_fk FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_barcodes product_barcodes_relationship_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_barcodes
    ADD CONSTRAINT product_barcodes_relationship_type_id_fk FOREIGN KEY (relationship_type_id) REFERENCES public.relationship_types(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_barcodes product_barcodes_source_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_barcodes
    ADD CONSTRAINT product_barcodes_source_id_fk FOREIGN KEY (source_id) REFERENCES public.data_sources(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_barcodes product_barcodes_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_barcodes
    ADD CONSTRAINT product_barcodes_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_categories_history product_categories_history_change_set_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_categories_history
    ADD CONSTRAINT product_categories_history_change_set_id_fk FOREIGN KEY (change_set_id) REFERENCES public.change_sets(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_categories_history product_categories_history_original_entity_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_categories_history
    ADD CONSTRAINT product_categories_history_original_entity_id_fk FOREIGN KEY (original_entity_id) REFERENCES public.product_categories(id) ON UPDATE RESTRICT ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_categories_history product_categories_history_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_categories_history
    ADD CONSTRAINT product_categories_history_parent_id_fk FOREIGN KEY (parent_id) REFERENCES public.product_categories(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_categories_history product_categories_history_previous_version_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_categories_history
    ADD CONSTRAINT product_categories_history_previous_version_id_fk FOREIGN KEY (previous_version_id) REFERENCES public.product_categories_history(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_categories_history product_categories_history_source_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_categories_history
    ADD CONSTRAINT product_categories_history_source_id_fk FOREIGN KEY (source_id) REFERENCES public.data_sources(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_categories_history product_categories_history_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_categories_history
    ADD CONSTRAINT product_categories_history_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_categories product_categories_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_categories
    ADD CONSTRAINT product_categories_parent_id_fk FOREIGN KEY (parent_id) REFERENCES public.product_categories(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_categories product_categories_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_categories
    ADD CONSTRAINT product_categories_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_category_translations product_category_translations_language_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_category_translations
    ADD CONSTRAINT product_category_translations_language_id_fk FOREIGN KEY (language_id) REFERENCES public.languages(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_category_translations product_category_translations_product_category_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_category_translations
    ADD CONSTRAINT product_category_translations_product_category_id_fk FOREIGN KEY (product_category_id) REFERENCES public.product_categories(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_health_evaluations product_health_evaluations_condition_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_health_evaluations
    ADD CONSTRAINT product_health_evaluations_condition_id_fkey FOREIGN KEY (condition_id) REFERENCES public.health_conditions(id);


--
-- Name: product_health_evaluations product_health_evaluations_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_health_evaluations
    ADD CONSTRAINT product_health_evaluations_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: product_health_flags product_health_flags_evidence_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_health_flags
    ADD CONSTRAINT product_health_flags_evidence_type_id_fk FOREIGN KEY (evidence_type_id) REFERENCES public.evidence_types(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_health_flags product_health_flags_health_flag_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_health_flags
    ADD CONSTRAINT product_health_flags_health_flag_id_fk FOREIGN KEY (health_flag_id) REFERENCES public.health_flags(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_health_flags product_health_flags_product_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_health_flags
    ADD CONSTRAINT product_health_flags_product_id_fk FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_health_flags product_health_flags_relationship_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_health_flags
    ADD CONSTRAINT product_health_flags_relationship_type_id_fk FOREIGN KEY (relationship_type_id) REFERENCES public.relationship_types(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_health_flags product_health_flags_source_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_health_flags
    ADD CONSTRAINT product_health_flags_source_id_fk FOREIGN KEY (source_id) REFERENCES public.data_sources(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_health_flags product_health_flags_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_health_flags
    ADD CONSTRAINT product_health_flags_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_images product_images_evidence_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_images
    ADD CONSTRAINT product_images_evidence_type_id_fk FOREIGN KEY (evidence_type_id) REFERENCES public.evidence_types(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_images_history product_images_history_change_set_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_images_history
    ADD CONSTRAINT product_images_history_change_set_id_fk FOREIGN KEY (change_set_id) REFERENCES public.change_sets(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_images_history product_images_history_evidence_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_images_history
    ADD CONSTRAINT product_images_history_evidence_type_id_fk FOREIGN KEY (evidence_type_id) REFERENCES public.evidence_types(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_images_history product_images_history_image_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_images_history
    ADD CONSTRAINT product_images_history_image_id_fk FOREIGN KEY (image_id) REFERENCES public.images(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_images_history product_images_history_original_entity_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_images_history
    ADD CONSTRAINT product_images_history_original_entity_id_fk FOREIGN KEY (original_entity_id) REFERENCES public.product_images(id) ON UPDATE RESTRICT ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_images_history product_images_history_previous_version_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_images_history
    ADD CONSTRAINT product_images_history_previous_version_id_fk FOREIGN KEY (previous_version_id) REFERENCES public.product_images_history(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_images_history product_images_history_product_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_images_history
    ADD CONSTRAINT product_images_history_product_id_fk FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_images_history product_images_history_relationship_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_images_history
    ADD CONSTRAINT product_images_history_relationship_type_id_fk FOREIGN KEY (relationship_type_id) REFERENCES public.relationship_types(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_images_history product_images_history_source_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_images_history
    ADD CONSTRAINT product_images_history_source_id_fk FOREIGN KEY (source_id) REFERENCES public.data_sources(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_images_history product_images_history_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_images_history
    ADD CONSTRAINT product_images_history_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_images product_images_image_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_images
    ADD CONSTRAINT product_images_image_id_fk FOREIGN KEY (image_id) REFERENCES public.images(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_images product_images_product_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_images
    ADD CONSTRAINT product_images_product_id_fk FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_images product_images_relationship_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_images
    ADD CONSTRAINT product_images_relationship_type_id_fk FOREIGN KEY (relationship_type_id) REFERENCES public.relationship_types(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_images product_images_source_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_images
    ADD CONSTRAINT product_images_source_id_fk FOREIGN KEY (source_id) REFERENCES public.data_sources(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_images product_images_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_images
    ADD CONSTRAINT product_images_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_ingredients product_ingredients_evidence_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_ingredients
    ADD CONSTRAINT product_ingredients_evidence_type_id_fk FOREIGN KEY (evidence_type_id) REFERENCES public.evidence_types(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_ingredients product_ingredients_ingredient_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_ingredients
    ADD CONSTRAINT product_ingredients_ingredient_id_fk FOREIGN KEY (ingredient_id) REFERENCES public.ingredients(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_ingredients product_ingredients_product_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_ingredients
    ADD CONSTRAINT product_ingredients_product_id_fk FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_ingredients product_ingredients_relationship_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_ingredients
    ADD CONSTRAINT product_ingredients_relationship_type_id_fk FOREIGN KEY (relationship_type_id) REFERENCES public.relationship_types(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_ingredients product_ingredients_source_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_ingredients
    ADD CONSTRAINT product_ingredients_source_id_fk FOREIGN KEY (source_id) REFERENCES public.data_sources(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_ingredients product_ingredients_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_ingredients
    ADD CONSTRAINT product_ingredients_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_ingredients product_ingredients_unit_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_ingredients
    ADD CONSTRAINT product_ingredients_unit_id_fk FOREIGN KEY (unit_id) REFERENCES public.units(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_nutrition_values product_nutrition_values_evidence_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_nutrition_values
    ADD CONSTRAINT product_nutrition_values_evidence_type_id_fk FOREIGN KEY (evidence_type_id) REFERENCES public.evidence_types(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_nutrition_values product_nutrition_values_measurement_basis_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_nutrition_values
    ADD CONSTRAINT product_nutrition_values_measurement_basis_id_fk FOREIGN KEY (measurement_basis_id) REFERENCES public.measurement_bases(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_nutrition_values product_nutrition_values_nutrition_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_nutrition_values
    ADD CONSTRAINT product_nutrition_values_nutrition_type_id_fk FOREIGN KEY (nutrition_type_id) REFERENCES public.nutrition_types(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_nutrition_values product_nutrition_values_product_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_nutrition_values
    ADD CONSTRAINT product_nutrition_values_product_id_fk FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_nutrition_values product_nutrition_values_relationship_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_nutrition_values
    ADD CONSTRAINT product_nutrition_values_relationship_type_id_fk FOREIGN KEY (relationship_type_id) REFERENCES public.relationship_types(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_nutrition_values product_nutrition_values_source_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_nutrition_values
    ADD CONSTRAINT product_nutrition_values_source_id_fk FOREIGN KEY (source_id) REFERENCES public.data_sources(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_nutrition_values product_nutrition_values_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_nutrition_values
    ADD CONSTRAINT product_nutrition_values_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_nutrition_values product_nutrition_values_unit_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_nutrition_values
    ADD CONSTRAINT product_nutrition_values_unit_id_fk FOREIGN KEY (unit_id) REFERENCES public.units(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_translations product_translations_language_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_translations
    ADD CONSTRAINT product_translations_language_id_fk FOREIGN KEY (language_id) REFERENCES public.languages(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: product_translations product_translations_product_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_translations
    ADD CONSTRAINT product_translations_product_id_fk FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: products products_brand_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_brand_id_fk FOREIGN KEY (brand_id) REFERENCES public.brands(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: products_history products_history_brand_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products_history
    ADD CONSTRAINT products_history_brand_id_fk FOREIGN KEY (brand_id) REFERENCES public.brands(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: products_history products_history_change_set_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products_history
    ADD CONSTRAINT products_history_change_set_id_fk FOREIGN KEY (change_set_id) REFERENCES public.change_sets(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: products_history products_history_original_entity_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products_history
    ADD CONSTRAINT products_history_original_entity_id_fk FOREIGN KEY (original_entity_id) REFERENCES public.products(id) ON UPDATE RESTRICT ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_history products_history_previous_version_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products_history
    ADD CONSTRAINT products_history_previous_version_id_fk FOREIGN KEY (previous_version_id) REFERENCES public.products_history(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: products_history products_history_product_category_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products_history
    ADD CONSTRAINT products_history_product_category_id_fk FOREIGN KEY (product_category_id) REFERENCES public.product_categories(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: products_history products_history_source_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products_history
    ADD CONSTRAINT products_history_source_id_fk FOREIGN KEY (source_id) REFERENCES public.data_sources(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: products_history products_history_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products_history
    ADD CONSTRAINT products_history_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: products products_product_category_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_product_category_id_fk FOREIGN KEY (product_category_id) REFERENCES public.product_categories(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: products products_source_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_source_id_fk FOREIGN KEY (source_id) REFERENCES public.data_sources(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: products products_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: regions regions_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.regions
    ADD CONSTRAINT regions_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: regulatory_authorities regulatory_authorities_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.regulatory_authorities
    ADD CONSTRAINT regulatory_authorities_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: relationship_types relationship_types_inverse_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relationship_types
    ADD CONSTRAINT relationship_types_inverse_type_id_fk FOREIGN KEY (inverse_type_id) REFERENCES public.relationship_types(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: relationship_types relationship_types_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relationship_types
    ADD CONSTRAINT relationship_types_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: role_types role_types_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_types
    ADD CONSTRAINT role_types_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: scan_job_items scan_job_items_candidate_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scan_job_items
    ADD CONSTRAINT scan_job_items_candidate_id_fkey FOREIGN KEY (candidate_id) REFERENCES public.discovery_candidates(id);


--
-- Name: scan_job_items scan_job_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scan_job_items
    ADD CONSTRAINT scan_job_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: scan_job_items scan_job_items_scan_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scan_job_items
    ADD CONSTRAINT scan_job_items_scan_job_id_fkey FOREIGN KEY (scan_job_id) REFERENCES public.scan_jobs(id);


--
-- Name: scan_jobs scan_jobs_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scan_jobs
    ADD CONSTRAINT scan_jobs_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: source_priorities source_priorities_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.source_priorities
    ADD CONSTRAINT source_priorities_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: source_types source_types_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.source_types
    ADD CONSTRAINT source_types_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: unit_conversions unit_conversions_from_unit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unit_conversions
    ADD CONSTRAINT unit_conversions_from_unit_id_fkey FOREIGN KEY (from_unit_id) REFERENCES public.units(id);


--
-- Name: unit_conversions unit_conversions_to_unit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unit_conversions
    ADD CONSTRAINT unit_conversions_to_unit_id_fkey FOREIGN KEY (to_unit_id) REFERENCES public.units(id);


--
-- Name: units units_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.units
    ADD CONSTRAINT units_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: verification_statuses verification_statuses_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.verification_statuses
    ADD CONSTRAINT verification_statuses_status_id_fk FOREIGN KEY (status_id) REFERENCES public.lifecycle_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: version_metadata version_metadata_entity_version_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.version_metadata
    ADD CONSTRAINT version_metadata_entity_version_id_fk FOREIGN KEY (entity_version_id) REFERENCES public.entity_versions(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict xElkaETu8VG1Nv6myK7LjxD8EtlEBcZuFStWll8HfNB8TIizEfkFf6YQPVWt9Ky

