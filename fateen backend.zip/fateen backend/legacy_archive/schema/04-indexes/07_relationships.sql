-- =============================================================================
-- Indexes: Relationship & Junction Tables
-- -----------------------------------------------------------------------------
-- Purpose:       Correctness-critical indexes only: every foreign-key column on
--                the Mission 04 relationship tables is indexed (PostgreSQL does
--                not index FK columns automatically). No performance/search
--                indexes yet.
-- Work orders:   Mission 04: Relationship & Junction Tables (work orders
--                #001-#008).
-- Dependencies:  Relationship tables (0016) and constraints (0017).
-- Migration:     0018_relationship_indexes.sql
-- Rationale:     FK-supporting indexes are required for referential integrity
--                enforcement and integrity-performance; UNIQUE constraints
--                (pair + relationship type, edge, ingredient alias) create their
--                own indexes and need no duplicate here. entity_relationships
--                subject_id/object_id are polymorphic endpoints with no FK and
--                are therefore not indexed (correctness scope only).
-- =============================================================================
CREATE INDEX product_ingredients_product_id_idx
    ON product_ingredients (product_id);

CREATE INDEX product_ingredients_ingredient_id_idx
    ON product_ingredients (ingredient_id);

CREATE INDEX product_ingredients_relationship_type_id_idx
    ON product_ingredients (relationship_type_id);

CREATE INDEX product_ingredients_source_id_idx
    ON product_ingredients (source_id);

CREATE INDEX product_ingredients_evidence_type_id_idx
    ON product_ingredients (evidence_type_id);

CREATE INDEX product_ingredients_unit_id_idx
    ON product_ingredients (unit_id);

CREATE INDEX product_ingredients_status_id_idx
    ON product_ingredients (status_id);

CREATE INDEX product_allergens_product_id_idx
    ON product_allergens (product_id);

CREATE INDEX product_allergens_allergen_id_idx
    ON product_allergens (allergen_id);

CREATE INDEX product_allergens_relationship_type_id_idx
    ON product_allergens (relationship_type_id);

CREATE INDEX product_allergens_source_id_idx
    ON product_allergens (source_id);

CREATE INDEX product_allergens_evidence_type_id_idx
    ON product_allergens (evidence_type_id);

CREATE INDEX product_allergens_status_id_idx
    ON product_allergens (status_id);

CREATE INDEX product_nutrition_values_product_id_idx
    ON product_nutrition_values (product_id);

CREATE INDEX product_nutrition_values_nutrition_type_id_idx
    ON product_nutrition_values (nutrition_type_id);

CREATE INDEX product_nutrition_values_unit_id_idx
    ON product_nutrition_values (unit_id);

CREATE INDEX product_nutrition_values_relationship_type_id_idx
    ON product_nutrition_values (relationship_type_id);

CREATE INDEX product_nutrition_values_source_id_idx
    ON product_nutrition_values (source_id);

CREATE INDEX product_nutrition_values_evidence_type_id_idx
    ON product_nutrition_values (evidence_type_id);

CREATE INDEX product_nutrition_values_status_id_idx
    ON product_nutrition_values (status_id);

CREATE INDEX product_health_flags_product_id_idx
    ON product_health_flags (product_id);

CREATE INDEX product_health_flags_health_flag_id_idx
    ON product_health_flags (health_flag_id);

CREATE INDEX product_health_flags_relationship_type_id_idx
    ON product_health_flags (relationship_type_id);

CREATE INDEX product_health_flags_source_id_idx
    ON product_health_flags (source_id);

CREATE INDEX product_health_flags_evidence_type_id_idx
    ON product_health_flags (evidence_type_id);

CREATE INDEX product_health_flags_status_id_idx
    ON product_health_flags (status_id);

CREATE INDEX ingredient_allergens_ingredient_id_idx
    ON ingredient_allergens (ingredient_id);

CREATE INDEX ingredient_allergens_allergen_id_idx
    ON ingredient_allergens (allergen_id);

CREATE INDEX ingredient_allergens_relationship_type_id_idx
    ON ingredient_allergens (relationship_type_id);

CREATE INDEX ingredient_allergens_source_id_idx
    ON ingredient_allergens (source_id);

CREATE INDEX ingredient_allergens_evidence_type_id_idx
    ON ingredient_allergens (evidence_type_id);

CREATE INDEX ingredient_allergens_status_id_idx
    ON ingredient_allergens (status_id);

CREATE INDEX ingredient_health_flags_ingredient_id_idx
    ON ingredient_health_flags (ingredient_id);

CREATE INDEX ingredient_health_flags_health_flag_id_idx
    ON ingredient_health_flags (health_flag_id);

CREATE INDEX ingredient_health_flags_relationship_type_id_idx
    ON ingredient_health_flags (relationship_type_id);

CREATE INDEX ingredient_health_flags_source_id_idx
    ON ingredient_health_flags (source_id);

CREATE INDEX ingredient_health_flags_evidence_type_id_idx
    ON ingredient_health_flags (evidence_type_id);

CREATE INDEX ingredient_health_flags_status_id_idx
    ON ingredient_health_flags (status_id);

CREATE INDEX ingredient_aliases_ingredient_id_idx
    ON ingredient_aliases (ingredient_id);

CREATE INDEX ingredient_aliases_language_id_idx
    ON ingredient_aliases (language_id);

CREATE INDEX ingredient_aliases_relationship_type_id_idx
    ON ingredient_aliases (relationship_type_id);

CREATE INDEX ingredient_aliases_source_id_idx
    ON ingredient_aliases (source_id);

CREATE INDEX ingredient_aliases_evidence_type_id_idx
    ON ingredient_aliases (evidence_type_id);

CREATE INDEX ingredient_aliases_status_id_idx
    ON ingredient_aliases (status_id);

CREATE INDEX entity_relationships_relationship_type_id_idx
    ON entity_relationships (relationship_type_id);

CREATE INDEX entity_relationships_source_id_idx
    ON entity_relationships (source_id);

CREATE INDEX entity_relationships_evidence_type_id_idx
    ON entity_relationships (evidence_type_id);

CREATE INDEX entity_relationships_status_id_idx
    ON entity_relationships (status_id);
