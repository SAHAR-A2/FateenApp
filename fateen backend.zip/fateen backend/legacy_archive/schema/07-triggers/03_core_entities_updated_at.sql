-- =============================================================================
-- Triggers: Canonical Core Entities updated_at
-- -----------------------------------------------------------------------------
-- Purpose:       Wire the shared set_updated_at() function to every Mission 03
--                core entity and translation table carrying the audit lifecycle
--                columns.
-- Work orders:   Mission 03: Canonical Core Entities (work orders #001-#008).
-- Dependencies:  Function set_updated_at() (06-functions, 0006). Mission 03
--                tables (0012).
-- Migration:     0015_core_entity_triggers.sql
-- Rationale:     Every table with updated_at must stamp it on UPDATE. Declaring
--                one trigger per table here keeps the rule explicit and auditable.
-- =============================================================================
CREATE TRIGGER companies_set_updated_at
    BEFORE UPDATE ON companies
    FOR EACH ROW
    EXECUTE FUNCTION set_updated_at();

CREATE TRIGGER company_translations_set_updated_at
    BEFORE UPDATE ON company_translations
    FOR EACH ROW
    EXECUTE FUNCTION set_updated_at();

CREATE TRIGGER brands_set_updated_at
    BEFORE UPDATE ON brands
    FOR EACH ROW
    EXECUTE FUNCTION set_updated_at();

CREATE TRIGGER brand_translations_set_updated_at
    BEFORE UPDATE ON brand_translations
    FOR EACH ROW
    EXECUTE FUNCTION set_updated_at();

CREATE TRIGGER products_set_updated_at
    BEFORE UPDATE ON products
    FOR EACH ROW
    EXECUTE FUNCTION set_updated_at();

CREATE TRIGGER product_translations_set_updated_at
    BEFORE UPDATE ON product_translations
    FOR EACH ROW
    EXECUTE FUNCTION set_updated_at();

CREATE TRIGGER ingredients_set_updated_at
    BEFORE UPDATE ON ingredients
    FOR EACH ROW
    EXECUTE FUNCTION set_updated_at();

CREATE TRIGGER ingredient_translations_set_updated_at
    BEFORE UPDATE ON ingredient_translations
    FOR EACH ROW
    EXECUTE FUNCTION set_updated_at();

CREATE TRIGGER allergens_set_updated_at
    BEFORE UPDATE ON allergens
    FOR EACH ROW
    EXECUTE FUNCTION set_updated_at();

CREATE TRIGGER allergen_translations_set_updated_at
    BEFORE UPDATE ON allergen_translations
    FOR EACH ROW
    EXECUTE FUNCTION set_updated_at();

CREATE TRIGGER nutrition_type_translations_set_updated_at
    BEFORE UPDATE ON nutrition_type_translations
    FOR EACH ROW
    EXECUTE FUNCTION set_updated_at();

CREATE TRIGGER product_category_translations_set_updated_at
    BEFORE UPDATE ON product_category_translations
    FOR EACH ROW
    EXECUTE FUNCTION set_updated_at();

CREATE TRIGGER health_flags_set_updated_at
    BEFORE UPDATE ON health_flags
    FOR EACH ROW
    EXECUTE FUNCTION set_updated_at();

CREATE TRIGGER health_flag_translations_set_updated_at
    BEFORE UPDATE ON health_flag_translations
    FOR EACH ROW
    EXECUTE FUNCTION set_updated_at();
